# SwingDesk

A trading journal for Indian swing traders, as a Frappe app. Each user signs up, imports their Zerodha tradebook, and gets
their own journal, stats (after real charges), R-multiples and a risk-first trade planner at `/swing`.

- `swingdesk/engine/` — pure Python: fills → trades (intraday netting, splits/bonus, renames, dedupe), stats, sizing.
- `swingdesk/api.py` — the only door for app users; every query is filtered by the logged-in user.
- `frontend/` — Vue 3 + frappe-ui SPA. Built output is committed in `swingdesk/public/frontend` and `swingdesk/www/swing.html`.

## Tests
    python -m pytest tests          # engine + API on an in-memory fake Frappe (two users, privacy checks)

`tests/fixtures/private/` holds personal tradebooks for the golden tests and is git-ignored. Never commit it.

## Frontend
    cd frontend && npm install && npm run build      # rebuild after any UI change, then commit the build

## Deploy (Frappe Cloud)
1. Push this folder to a private GitHub repo `swingdesk`.
2. Bench → Apps → Add app → from GitHub → `swingdesk`; deploy.
3. New site on that bench, install SwingDesk. Website Settings → enable "Allow sign ups" (users get the SwingDesk User role).
4. Open `https://<site>/swing`.
