"""Engine tests. Scenarios run everywhere; the golden tests need the real tradebooks in tests/fixtures/private/
(git-ignored — personal data) and are skipped without them."""
import glob
import os

import pytest

from swingdesk.engine import (FormatError, daily_charges, daily_turnover, new_fills, parse_zerodha_tradebook, plan,
                              replay, summarize, r_multiple)

HERE = os.path.dirname(__file__)
PRIVATE = sorted(glob.glob(os.path.join(HERE, "fixtures", "private", "tradebook-*.csv")))
HEAD = "symbol,isin,trade_date,exchange,segment,series,trade_type,auction,quantity,price,trade_id,order_id,order_execution_time\n"
_n = [0]


def tb(*rows):
    """rows: (symbol, day, side, qty, price[, hh:mm])"""
    out = HEAD
    for r in rows:
        sym, day, side, qty, price = r[:5]
        hm = r[5] if len(r) > 5 else "10:00"
        _n[0] += 1
        out += f"{sym},INE{sym},{day},NSE,EQ,EQ,{side},false,{qty},{price},T{_n[0]},O{_n[0]},{day}T{hm}:00\n"
    return parse_zerodha_tradebook(out)[0]


def by_sym(res, sym):
    return [t for t in res["trades"] if t["symbol"] == sym]


# ── scenarios ────────────────────────────────────────────────────────────────
def test_simple_swing_with_scale_out():
    r = replay(tb(("AAA", "2026-01-05", "buy", 100, 100), ("AAA", "2026-01-08", "sell", 40, 110),
                  ("AAA", "2026-01-12", "sell", 60, 120)))
    [t] = r["trades"]
    assert t["kind"] == "swing" and t["status"] == "closed" and len(t["exits"]) == 2
    assert t["pnl"] == pytest.approx(40 * 10 + 60 * 20)
    assert t["exit_date"] == "2026-01-12" and t["days"] == 7


def test_add_on_later_day_averages_cost():
    r = replay(tb(("AAA", "2026-01-05", "buy", 100, 100), ("AAA", "2026-01-07", "buy", 100, 110),
                  ("AAA", "2026-01-09", "sell", 200, 120)))
    [t] = r["trades"]
    assert t["adds"] == 1 and t["pnl"] == pytest.approx(200 * 15)


def test_partial_intraday_then_carry():
    """Bought 100, sold 40 the same day, carried 60, sold later."""
    r = replay(tb(("CRY", "2026-02-02", "buy", 100, 50, "09:20"), ("CRY", "2026-02-02", "sell", 40, 53, "13:00"),
                  ("CRY", "2026-02-04", "sell", 60, 58)))
    it, sw = sorted(by_sym(r, "CRY"), key=lambda t: t["kind"])
    assert it["kind"] == "intraday" and it["pnl"] == pytest.approx(40 * 3)
    assert sw["kind"] == "swing" and sw["entry_date"] == "2026-02-02" and sw["pnl"] == pytest.approx(60 * 8)


def test_intraday_short_and_toggle_off():
    fills = tb(("SSS", "2026-02-02", "sell", 20, 500, "09:30"), ("SSS", "2026-02-02", "buy", 20, 490, "11:00"))
    [t] = replay(fills)["trades"]
    assert t["side"] == "short" and t["pnl"] == pytest.approx(200)
    assert replay(fills, include_intraday=False)["trades"] == []


def test_split_bonus_detected_and_adjusted():
    """Held 110 shares; 1:1 bonus; sold 220 @ 1700 → one winning trade, not a −43% loss + an orphan sale."""
    r = replay(tb(("KMW", "2026-03-02", "buy", 100, 3000), ("KMW", "2026-03-10", "buy", 10, 3400),
                  ("KMW", "2026-03-16", "sell", 220, 1700)))
    assert r["splits"] == {"KMW": [("2026-03-16", 2)]}
    [t] = by_sym(r, "KMW")
    assert t["status"] == "closed" and any("split/bonus ×2" in f for f in t["flags"])
    assert t["pnl"] == pytest.approx(220 * 1700 - (100 * 3000 + 10 * 3400))
    assert not r["unmatched"]


def test_sale_before_history_is_unmatched_not_a_trade():
    r = replay(tb(("OLD", "2026-01-05", "sell", 50, 100)))
    assert r["trades"] == [] and r["unmatched"][0]["qty"] == 50


def test_partial_unknown_cost_flagged_and_auto_excluded():
    r = replay(tb(("PRE", "2026-01-05", "buy", 10, 100), ("PRE", "2026-01-09", "sell", 30, 110)))
    [t] = r["trades"]
    assert t.get("auto_exclude") and any("more than the history holds" in f for f in t["flags"])
    s = summarize(r["trades"])
    assert s["n"] == 0 and s["left_out"] == 1
    assert summarize(r["trades"], included=[t["key"]])["n"] == 1


def test_renamed_stock_by_isin():
    a = tb(("OLDNAME", "2026-01-05", "buy", 10, 100))
    b = tb(("NEWNAME", "2026-01-20", "sell", 10, 120))
    for f in a + b:
        f["isin"] = "INE000X"
    [t] = replay(a + b)["trades"]
    assert t["symbol"] == "NEWNAME" and t["pnl"] == pytest.approx(200)


def test_same_trade_from_kite_and_tradebook_counts_once():
    f_tb = tb(("GRW", "2026-11-05", "sell", 26, 7621, "09:58"))[0]
    f_api = dict(f_tb, key="NSE:GRW:999", trade_id="999", source="api", ts="2026-11-05 10:02:11")
    buy = tb(("GRW", "2026-11-02", "buy", 104, 7096.23))
    assert new_fills([f_tb], [f_api] + buy) == []                       # import skips it
    r = replay(buy + [f_api, f_tb])                                     # both stored already → counted once
    [t] = r["trades"]
    assert t["open_qty"] == 78 and len(t["exits"]) == 1 and r["dropped"] == ["NSE:GRW:999"]


def test_keys_are_stable():
    fills = tb(("AAA", "2026-01-05", "buy", 10, 100), ("AAA", "2026-01-06", "sell", 10, 101),
               ("AAA", "2026-01-05", "sell", 5, 99, "15:00"))
    assert [t["key"] for t in replay(fills)["trades"]] == [t["key"] for t in replay(list(reversed(fills)))["trades"]]


def test_r_multiple():
    [t] = replay(tb(("AAA", "2026-01-05", "buy", 100, 100), ("AAA", "2026-01-09", "sell", 100, 106)))["trades"]
    assert r_multiple(t, 98) == pytest.approx(3.0)
    assert summarize([t], stops={t["key"]: 98})["r"]["avg"] == pytest.approx(3.0)


def test_charges_spread_by_turnover_and_boundary_day():
    tv = {"2026-01-05": 100.0, "2026-01-06": 300.0, "2026-02-01": 50.0}
    ch = daily_charges([{"from": "2026-01-01", "to": "2026-01-31", "amount": 400}], tv, est_pct=1)
    assert ch["2026-01-05"][0] == pytest.approx(100) and ch["2026-01-06"][0] == pytest.approx(300)
    assert ch["2026-02-01"] == (pytest.approx(0.5), True)


def test_plan_sizing_cap_and_plain_words():
    p = plan(1097, 1088, 1_000_000, 0.25, adr_pct=4.59)
    assert p["capped"] and p["shares"] == 227 and p["verdict"] == "tight" and "¼" in p["plain"]
    p = plan(243.3, 236.4, 1_000_000, 0.25, adr_pct=4.21)
    assert p["shares"] == 362 and p["verdict"] == "ok"
    assert not plan(100, 101, 1e6, 0.25)["ok"]


def test_rejects_wrong_file():
    with pytest.raises(FormatError):
        parse_zerodha_tradebook("date,amount\n2026-01-01,5\n")


# ── golden: the real three years ─────────────────────────────────────────────
@pytest.fixture(scope="module")
def real():
    if len(PRIVATE) < 3:
        pytest.skip("real tradebooks not present")
    fills = []
    for p in PRIVATE:
        fills += parse_zerodha_tradebook(open(p).read())[0]
    return fills, replay(fills)


def test_golden_counts(real):
    fills, r = real
    assert len(fills) == 25748
    assert r["splits"].get("KMEW") == [("2025-12-22", 2)]
    assert len(r["trades"]) > 400


def test_golden_cash_reconciles(real):
    """Every rupee: Σsells − Σbuys = realised P&L − cost of what's still open + value of pre-history sales."""
    fills, r = real
    cash = sum(f["qty"] * f["price"] * (1 if f["side"] == "SELL" else -1) for f in fills)
    realised = sum(t["pnl"] for t in r["trades"])
    open_cost = sum(t["open_qty"] * t["avg_cost"] for t in r["trades"] if t["status"] == "open")
    orphan = sum(u["qty"] * u["price"] for u in r["unmatched"])
    assert cash == pytest.approx(realised - open_cost + orphan, abs=5)


def test_golden_kmew_is_two_wins_not_a_fake_loss(real):
    _, r = real
    k = [t for t in r["trades"] if t["symbol"] == "KMEW" and "2025-12-01" <= t["entry_date"] <= "2026-01-02"]
    assert k and all(t["pnl"] > -50000 for t in k)


def test_golden_intraday_vs_swing(real):
    _, r = real
    s = summarize(r["trades"])
    assert s["by_kind"]["intraday"]["pnl"] == pytest.approx(-1520868, abs=5)
    assert s["by_kind"]["swing"]["pnl"] > 2_000_000
