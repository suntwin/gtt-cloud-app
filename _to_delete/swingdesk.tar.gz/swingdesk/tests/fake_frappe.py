"""A small in-memory stand-in for the parts of Frappe swingdesk.api uses — enough to run the API end to end without a
bench. install() puts it in sys.modules["frappe"]; tests switch users with login(email)."""
import copy
import re
import sys
import types
import uuid
from datetime import date, datetime


class ValidationError(Exception):
    pass


class PermissionError_(Exception):
    pass


class DoesNotExistError(Exception):
    pass


def _cmp_val(v):
    if isinstance(v, (date, datetime)):
        return v.isoformat()
    return v


def _match(row, filters):
    for k, cond in (filters or {}).items():
        v = row.get(k)
        if isinstance(cond, (list, tuple)) and len(cond) == 2 and isinstance(cond[0], str) and cond[0] in ("in", "!=", "between", "not in"):
            op, arg = cond
            if op == "in" and v not in arg:
                return False
            if op == "not in" and v in arg:
                return False
            if op == "!=" and v == arg:
                return False
            if op == "between" and not (v is not None and str(arg[0]) <= str(_cmp_val(v)).replace("T", " ") <= str(arg[1])):
                return False
        elif v != cond:
            return False
    return True


class Doc(dict):
    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        return self.get(k)

    def insert(self, ignore_permissions=False):
        db = sys.modules["frappe"]._db
        self.setdefault("name", uuid.uuid4().hex[:12])
        self.setdefault("creation", datetime.now().isoformat())
        row = {k: v for k, v in self.items() if k != "doctype"}
        db.t(self["doctype"]).append(row)
        return self


class DB:
    def __init__(self):
        self.tables = {}

    def t(self, dt):
        return self.tables.setdefault(dt, [])

    def get_all(self, dt, filters=None, fields=None, order_by=None, limit_page_length=None, **k):
        rows = [r for r in self.t(dt) if _match(r, filters)]
        if order_by:
            col, *d = order_by.split()
            rows = sorted(rows, key=lambda r: (r.get(col) is None, str(_cmp_val(r.get(col)))), reverse=bool(d and d[0] == "desc"))
        if limit_page_length:
            rows = rows[:limit_page_length]
        fields = fields or ["name"]
        return [Doc({f: copy.deepcopy(r.get(f)) for f in fields}) for r in rows]

    def get_value(self, dt, filters, field="name"):
        rows = [r for r in self.t(dt) if (r.get("name") == filters if isinstance(filters, str) else _match(r, filters))]
        if not rows:
            return None
        return rows[0].get(field) if isinstance(field, str) else [rows[0].get(f) for f in field]

    def exists(self, dt, filters):
        return bool(self.get_value(dt, filters))

    def set_value(self, dt, name, field, value=None, update_modified=True):
        for r in self.t(dt):
            if r.get("name") == name:
                r.update(field if isinstance(field, dict) else {field: value})

    def delete(self, dt, filters):
        self.tables[dt] = [r for r in self.t(dt) if not _match(r, filters)]

    def bulk_insert(self, dt, fields, values, ignore_duplicates=False, chunk_size=10000):
        for v in values:
            self.t(dt).append(dict(zip(fields, v)))

    def sql(self, q, params=(), as_dict=False):
        q1 = " ".join(q.split())
        if q1.startswith("update `tabSD Fill` set status='duplicate'"):
            user, keys = params
            for r in self.t("SD Fill"):
                if r["user"] == user and r["key"] in keys:
                    r["status"] = "duplicate"
            return []
        if q1.startswith("update `tabSD Fill` set status='dismissed'"):
            user, sym, day = params
            for r in self.t("SD Fill"):
                if r["user"] == user and r["symbol"] == sym and r["side"] == "SELL" and str(r["ts"])[:10] == day and r["status"] == "active":
                    r["status"] = "dismissed"
            return []
        if q1.startswith("select date(ts) d, sum(qty*price) v from `tabSD Fill`"):
            (user,) = params
            out = {}
            for r in self.t("SD Fill"):
                if r["user"] == user and r["status"] == "active":
                    d = str(r["ts"])[:10]
                    out[d] = out.get(d, 0) + float(r["qty"]) * float(r["price"])
            return [{"d": date.fromisoformat(d), "v": v} for d, v in out.items()]
        raise NotImplementedError(q1[:80])

    def commit(self):
        pass


class Cache:
    def __init__(self):
        self.d = {}

    def get_value(self, k):
        return copy.deepcopy(self.d.get(k))

    def set_value(self, k, v, expires_in_sec=None):
        self.d[k] = copy.deepcopy(v)

    def delete_value(self, k):
        self.d.pop(k, None)


def install():
    f = types.ModuleType("frappe")
    f._db = DB()
    f.db = f._db
    _cache = Cache()
    f.cache = lambda: _cache
    f.session = types.SimpleNamespace(user="Guest")
    f.local = types.SimpleNamespace(flags=types.SimpleNamespace())
    f.ValidationError, f.PermissionError, f.DoesNotExistError = ValidationError, PermissionError_, DoesNotExistError

    def throw(msg, exc=ValidationError, **k):
        raise exc(msg)
    f.throw = throw

    def whitelist(*a, **k):
        if a and callable(a[0]):
            return a[0]
        return lambda fn: fn
    f.whitelist = whitelist
    f.get_all = f._db.get_all
    f.generate_hash = lambda length=10: uuid.uuid4().hex[:length]
    f.log_error = lambda *a, **k: None

    def get_doc(dt, name=None):
        if isinstance(dt, dict):
            return Doc(dt)
        rows = [r for r in f._db.t(dt) if r.get("name") == name]
        if not rows:
            raise DoesNotExistError(name)
        return Doc({**rows[0], "doctype": dt})
    f.get_doc = get_doc

    def delete_doc(dt, name, ignore_permissions=False):
        f._db.tables[dt] = [r for r in f._db.t(dt) if r.get("name") != name]
    f.delete_doc = delete_doc

    def enqueue(method, queue=None, timeout=None, **kw):
        mod, fn = method.rsplit(".", 1)
        import importlib
        getattr(importlib.import_module(mod), fn)(**kw)
    f.enqueue = enqueue
    sys.modules["frappe"] = f
    return f


def login(user):
    sys.modules["frappe"].session.user = user
