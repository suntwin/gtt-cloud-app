"""The API end to end on the fake Frappe, with two users. The privacy tests are the important ones."""
import glob
import os

import pytest

from tests import fake_frappe

frappe = fake_frappe.install()
from swingdesk import api  # noqa: E402

HERE = os.path.dirname(__file__)
PRIVATE = sorted(glob.glob(os.path.join(HERE, "fixtures", "private", "tradebook-*.csv")))
HEAD = "symbol,isin,trade_date,exchange,segment,series,trade_type,auction,quantity,price,trade_id,order_id,order_execution_time\n"
A, B = "alice@example.com", "bob@example.com"


def small_csv(tag=""):
    rows = [("AAA", "2026-01-05", "buy", 100, 100), ("AAA", "2026-01-09", "sell", 100, 106),
            ("BBB", "2026-01-06", "buy", 50, 200), ("BBB", "2026-01-06", "sell", 50, 198),
            ("CCC", "2026-02-02", "buy", 10, 1000)]
    out = HEAD
    for i, (s, d, side, q, p) in enumerate(rows):
        out += f"{s},INE{s},{d},NSE,EQ,EQ,{side},false,{q},{p},{tag}T{i},O{i},{d}T10:0{i}:00\n"
    return out


@pytest.fixture(autouse=True)
def fresh():
    frappe._db.tables.clear()
    frappe.cache().d.clear()
    yield


def as_(user):
    fake_frappe.login(user)


def test_guest_is_refused():
    as_("Guest")
    with pytest.raises(frappe.PermissionError):
        api.dashboard()


def test_import_then_dashboard():
    as_(A)
    api.import_tradebook(small_csv())
    j = api.job_status()
    assert j["state"] == "done" and j["new"] == 5, j
    d = api.dashboard()
    s = d["summary"]
    assert s["n"] == 2 and s["by_kind"]["intraday"]["n"] == 1 and s["by_kind"]["swing"]["pnl"] == pytest.approx(600)
    assert [o["symbol"] for o in d["open"]] == ["CCC"] and d["no_stop"] == ["CCC"]
    # same file again → nothing new, same result
    api.import_tradebook(small_csv())
    assert api.job_status()["new"] == 0 and api.dashboard()["summary"]["n"] == 2


def test_wrong_file_is_rejected_up_front():
    as_(A)
    with pytest.raises(frappe.ValidationError):
        api.import_tradebook("date,amount\n2026-01-01,5\n")


def test_annotation_survives_rebuild_and_gives_r():
    as_(A)
    api.import_tradebook(small_csv())
    key = next(r["key"] for r in api.trades()["rows"] if r["symbol"] == "AAA")
    api.annotate(key, {"setup": "Range breakout", "stop": 98})
    api.save_playbook({"include_intraday": 0})                     # forces a rebuild
    row = next(r for r in api.trades()["rows"] if r["key"] == key)
    assert row["setup"] == "Range breakout" and row["r"] == pytest.approx(3.0)
    assert api.dashboard()["summary"]["by_kind"]["intraday"]["n"] == 0


def test_exclude_and_period():
    as_(A)
    api.import_tradebook(small_csv())
    key = next(r["key"] for r in api.trades()["rows"] if r["symbol"] == "AAA")
    api.annotate(key, {"stats": "exclude"})
    assert api.dashboard()["summary"]["n"] == 1
    assert api.dashboard("Custom range", "2026-01-07", "2026-01-31")["summary"]["n"] == 0


def test_plan_needs_account_then_sizes_by_risk():
    as_(A)
    with pytest.raises(frappe.ValidationError):
        api.plan_calc("X", 100, 98)
    api.save_playbook({"account_size": 1_000_000, "risk_pct": 0.25})
    p = api.plan_calc("PPLPHARMA", 243.3, 236.4, 4.21)
    assert p["shares"] == 362 and p["verdict"] == "ok"
    r = api.save_plan("nse:pplpharma", 243.3, 236.4, 4.21, "Hourly flag", 1)
    assert api.plans()["rows"][0]["symbol"] == "PPLPHARMA" and r["plan"]["shares"] == 362


def test_charges_validate_and_count():
    as_(A)
    api.import_tradebook(small_csv())
    with pytest.raises(frappe.ValidationError):
        api.save_charges([{"from": "2026-01-01", "to": "2026-02-28", "amount": 100}, {"from": "2026-02-01", "to": "2026-03-01", "amount": 5}])
    api.save_charges([{"from": "2026-01-01", "to": "2026-01-31", "amount": 300}])
    s = api.dashboard()["summary"]
    assert s["charges_recorded"] == pytest.approx(300) and s["net_after_charges"] == pytest.approx(s["net_realised"] - 300 - s["charges_estimated"])


# ── privacy ──────────────────────────────────────────────────────────────────
def test_users_never_see_each_other():
    as_(A)
    api.import_tradebook(small_csv("A"))
    api.save_playbook({"account_size": 500000})
    api.save_plan("AAA", 100, 98)
    a_key = api.trades()["rows"][0]["key"]
    a_plan = api.plans()["rows"][0]["name"]

    as_(B)
    assert api.trades()["n"] == 0 and api.dashboard()["summary"]["n"] == 0 and api.plans()["rows"] == []
    assert api.boot()["playbook"]["account_size"] in (None, 0) and api.charges()["rows"] == []
    with pytest.raises(frappe.DoesNotExistError):
        api.annotate(a_key, {"note": "hijack"})                     # same key format, but not B's trade
    with pytest.raises(frappe.DoesNotExistError):
        api.trade(a_key)
    with pytest.raises(frappe.DoesNotExistError):
        api.set_plan_status(a_plan, "deleted")
    assert api.export_my_data()["fills"] == []
    api.delete_my_data("DELETE")

    as_(A)                                                          # A untouched by anything B did
    assert api.trades()["n"] == 3 and len(api.plans()["rows"]) == 1
    assert all((r["note"] or "") != "hijack" for r in api.trades()["rows"])


def test_same_file_two_users_kept_apart():
    """Two people who traded with each other share exchange trade numbers — each keeps their own copy."""
    for u in (A, B):
        as_(u)
        api.import_tradebook(small_csv("X"))
        assert api.job_status()["new"] == 5
    as_(A)
    assert api.trades()["n"] == 3


# ── the real three years through the API ─────────────────────────────────────
def test_real_tradebooks_through_api():
    if len(PRIVATE) < 3:
        pytest.skip("real tradebooks not present")
    as_(A)
    for p in PRIVATE:
        api.import_tradebook(open(p).read())
        assert api.job_status()["state"] == "done"
    d = api.dashboard()
    s = d["summary"]
    assert s["net_realised"] == pytest.approx(798275, abs=10)
    assert d["build"]["splits"]["KMEW"] == [["2025-12-22", 2]]
    assert d["n_review"] >= 3 and d["lesson"].startswith("Intraday cost")
    api.save_charges([{"from": "2023-04-18", "to": "2024-04-18", "amount": 224000},
                      {"from": "2024-04-18", "to": "2025-04-18", "amount": 88500},
                      {"from": "2025-04-18", "to": "2026-04-18", "amount": 331000}])
    s = api.dashboard()["summary"]
    assert s["charges_recorded"] == pytest.approx(643500, rel=1e-6)
