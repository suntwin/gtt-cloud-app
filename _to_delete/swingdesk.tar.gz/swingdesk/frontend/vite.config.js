import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import frappeui from 'frappe-ui/vite'
import path from 'path'

export default defineConfig({
  plugins: [
    frappeui({
      frontendRoute: '/swing',
      frappeProxy: true,
      jinjaBootData: true,
      lucideIcons: false,
      buildConfig: {
        outDir: path.resolve(__dirname, '../swingdesk/public/frontend'),
        indexHtmlPath: path.resolve(__dirname, '../swingdesk/www/swing.html'),
        baseUrl: '/assets/swingdesk/frontend/',
      },
    }),
    vue(),
  ],
  resolve: { alias: { '@': path.resolve(__dirname, 'src') } },
  build: { chunkSizeWarningLimit: 900, rollupOptions: { output: { manualChunks: { vendor: ['vue', 'vue-router'] } } } },
})
