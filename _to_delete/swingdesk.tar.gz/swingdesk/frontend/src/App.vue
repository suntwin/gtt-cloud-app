<template>
  <div class="min-h-screen bg-[#F7F7F7] text-[#171717]">
    <div class="flex">
      <nav class="sticky top-0 hidden h-screen w-56 shrink-0 flex-col gap-1 border-r border-[#E8E8E8] bg-[#FBFBFB] px-3 py-5 lg:flex" aria-label="Main">
        <div class="mb-4 flex items-center gap-2 px-3">
          <div class="grid size-7 place-items-center rounded-lg bg-[#171717] text-sm font-bold text-white">S</div>
          <span class="text-base font-bold tracking-tight">SwingDesk</span>
        </div>
        <RouterLink v-for="t in tabs" :key="t.to" :to="t.to" class="rounded-lg px-3 py-2 text-sm text-[#404040] hover:bg-[#F0F0F0]"
                    :exact-active-class="'!bg-white font-semibold !text-[#171717] shadow-sm'">{{ t.label }}</RouterLink>
        <div class="flex-1" />
        <div v-if="app.boot" class="px-3 text-xs leading-5 text-[#616161]">
          {{ app.boot.full_name || app.boot.user }}<br />
          <span v-if="app.boot.build?.from">History {{ app.boot.build.from }} → {{ app.boot.build.to }}</span>
          <br /><a href="/logout" class="underline">Log out</a>
        </div>
      </nav>
      <main class="min-w-0 flex-1 px-3 pb-24 pt-4 sm:px-6 lg:pb-10">
        <div v-if="app.error && !app.boot" class="mx-auto max-w-lg rounded-xl border border-[#F5C2C0] bg-[#FDECEC] p-4 text-sm">{{ app.error }}</div>
        <RouterView v-else-if="app.boot" v-slot="{ Component }"><KeepAlive><component :is="Component" /></KeepAlive></RouterView>
        <div v-else class="grid place-items-center p-20 text-sm text-[#616161]">Loading…</div>
      </main>
    </div>
    <nav class="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-[#E8E8E8] bg-white/95 backdrop-blur lg:hidden"
         style="padding-bottom: env(safe-area-inset-bottom)" aria-label="Main">
      <RouterLink v-for="t in tabs" :key="t.to" :to="t.to" class="py-3 text-center text-xs text-[#616161]"
                  exact-active-class="!text-[#171717] font-semibold">{{ t.short }}</RouterLink>
    </nav>
    <ToastProvider />
  </div>
</template>
<script setup>
import { onMounted } from 'vue'
import { ToastProvider } from 'frappe-ui'
import { app, loadBoot } from '@/lib/store'
const tabs = [
  { to: '/swing', label: 'Home', short: 'Home' }, { to: '/swing/plan', label: 'Plan', short: 'Plan' },
  { to: '/swing/journal', label: 'Journal', short: 'Journal' }, { to: '/swing/import', label: 'Import', short: 'Import' },
  { to: '/swing/playbook', label: 'Playbook', short: 'Playbook' },
]
onMounted(loadBoot)
</script>
