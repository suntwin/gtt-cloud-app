import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import App from './App.vue'
import './index.css'

const routes = [
  { path: '/swing', name: 'home', component: () => import('./pages/Home.vue'), meta: { title: 'Home' } },
  { path: '/swing/plan', name: 'plan', component: () => import('./pages/Plan.vue'), meta: { title: 'Plan' } },
  { path: '/swing/journal', name: 'journal', component: () => import('./pages/Journal.vue'), meta: { title: 'Journal' } },
  { path: '/swing/import', name: 'import', component: () => import('./pages/Import.vue'), meta: { title: 'Import' } },
  { path: '/swing/playbook', name: 'playbook', component: () => import('./pages/Playbook.vue'), meta: { title: 'Playbook' } },
  { path: '/:p(.*)*', redirect: '/swing' },
]
const router = createRouter({ history: createWebHistory(), routes, scrollBehavior: (to, from, saved) => saved || { top: 0 } })
router.afterEach((to) => { document.title = `${to.meta.title || 'SwingDesk'} · SwingDesk` })
router.isReady().then(() => setTimeout(() => routes.forEach((r) => typeof r.component === 'function' && r.component()), 1200))

createApp(App).use(router).mount('#app')
