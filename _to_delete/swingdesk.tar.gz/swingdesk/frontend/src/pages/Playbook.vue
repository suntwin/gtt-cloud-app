<template>
  <div class="mx-auto flex max-w-3xl flex-col gap-4">
    <h1 class="text-xl font-bold">Playbook</h1>

    <section class="flex flex-col gap-3 rounded-xl border border-[#EBEBEB] bg-white p-4">
      <h2 class="text-sm font-semibold">Risk</h2>
      <div class="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Field label="Account size (₹)" v-model="f.account_size" step="1000" />
        <Field label="Risk per trade (% of account)" v-model="f.risk_pct" step="0.05" />
        <Field label="Max position (% of account)" v-model="f.cap_pct" step="1" />
        <Field label="Widest stop allowed (%)" v-model="f.max_stop_pct" step="0.5" />
        <Field label="Tight stop = up to (× day's move)" v-model="f.ideal_stop_adr" step="0.05" />
        <Field label="OK stop = up to (× day's move)" v-model="f.max_stop_adr" step="0.05" />
        <Field label="Max new trades a day" v-model="f.max_trades_day" step="1" />
      </div>
      <div v-if="f.account_size && f.risk_pct" class="text-sm text-[#616161]">
        You risk <b class="text-[#171717]">{{ inr(f.account_size * f.risk_pct / 100, { lakh: false }) }}</b> on every trade.
        Ten losers in a row costs {{ pct(10 * f.risk_pct, 1) }} of the account.</div>
      <label class="flex flex-col gap-1 text-xs text-[#616161]">My rules, in one line
        <input v-model="f.goal" placeholder="e.g. Only A+ setups. Enter on 1-min ORH. Stop under the low of the day." class="h-9 rounded-lg border border-[#E0E0E0] px-3 text-sm text-[#171717]" /></label>
    </section>

    <section class="flex flex-col gap-3 rounded-xl border border-[#EBEBEB] bg-white p-4">
      <h2 class="text-sm font-semibold">Stats</h2>
      <label class="flex items-center gap-2 text-sm"><input v-model="intraday" type="checkbox" class="size-4" />
        Count intraday trades <span class="text-xs text-[#616161]">(changing this rebuilds your trades)</span></label>
      <div class="flex flex-wrap items-center gap-2 text-sm"><span class="text-[#616161]">Default period on open</span>
        <PeriodPicker v-model="per" /></div>
    </section>

    <div class="flex items-center gap-3">
      <button class="h-10 rounded-lg bg-[#171717] px-4 text-sm font-semibold text-white disabled:opacity-40" :disabled="saving" @click="save">Save playbook</button>
      <span class="text-sm text-[#616161]">{{ msg }}</span>
    </div>

    <section class="flex flex-col gap-3 rounded-xl border border-[#EBEBEB] bg-white p-4">
      <div><h2 class="text-sm font-semibold">Charges you actually paid</h2>
        <p class="text-xs text-[#616161]">From Console → Reports → P&amp;L → Charges, one row per span (e.g. each financial year). Spread over the days you traded in that span, by turnover.
          Days with no row use the estimate below.</p></div>
      <div v-for="(c, i) in rows" :key="i" class="flex flex-wrap items-center gap-2">
        <input v-model="c.from" type="date" aria-label="From" class="h-9 rounded-lg border border-[#E0E0E0] px-2 text-sm" />
        <span class="text-[#616161]">→</span>
        <input v-model="c.to" type="date" aria-label="To" class="h-9 rounded-lg border border-[#E0E0E0] px-2 text-sm" />
        <input v-model.number="c.amount" type="number" placeholder="₹" aria-label="Amount" class="h-9 w-32 rounded-lg border border-[#E0E0E0] px-2 text-sm tabular-nums" />
        <button class="text-xs text-[#B42318] underline" @click="rows.splice(i, 1)">Remove</button>
      </div>
      <div class="flex flex-wrap items-center gap-3 text-sm">
        <button class="underline" @click="addRow">+ Add span</button>
        <span class="text-[#616161]">Total {{ inr(rows.reduce((a, c) => a + (+c.amount || 0), 0)) }}</span>
        <div class="flex-1" />
        <label class="flex items-center gap-2 text-xs text-[#616161]">Estimate where not entered (% of turnover)
          <input v-model.number="f.est_charges_pct" type="number" step="0.01" class="h-9 w-20 rounded-lg border border-[#E0E0E0] px-2 text-sm text-[#171717]" /></label>
      </div>
      <div class="flex items-center gap-3">
        <button class="h-9 rounded-lg border border-[#171717] px-3 text-sm font-semibold" @click="saveCharges">Save charges</button>
        <span class="text-sm" :class="cerr ? 'text-[#B42318]' : 'text-[#616161]'">{{ cmsg }}</span></div>
    </section>

    <section class="flex flex-col gap-3 rounded-xl border border-[#EBEBEB] bg-white p-4">
      <h2 class="text-sm font-semibold">Your data</h2>
      <p class="text-xs text-[#616161]">Only you can see it. Download a full copy any time, or delete everything.</p>
      <div class="flex flex-wrap items-center gap-3">
        <button class="h-9 rounded-lg border border-[#E0E0E0] px-3 text-sm" @click="exportData">Download my data (JSON)</button>
        <input v-model="confirmText" placeholder="Type DELETE" class="h-9 w-32 rounded-lg border border-[#E0E0E0] px-2 text-sm" />
        <button class="h-9 rounded-lg bg-[#B42318] px-3 text-sm font-semibold text-white disabled:opacity-30" :disabled="confirmText !== 'DELETE'" @click="wipe">Delete everything</button>
      </div>
    </section>
  </div>
</template>
<script setup>
import { h, reactive, ref, onActivated } from 'vue'
import { get, post } from '@/lib/api'
import { app, changed, loadBoot, inr, pct } from '@/lib/store'
import PeriodPicker from '@/components/PeriodPicker.vue'

const Field = (p, { emit }) => h('label', { class: 'flex flex-col gap-1 text-xs text-[#616161]' }, [p.label,
  h('input', { type: 'number', step: p.step, value: p.modelValue ?? '', class: 'h-9 rounded-lg border border-[#E0E0E0] px-3 text-sm tabular-nums text-[#171717]',
    onInput: (e) => emit('update:modelValue', e.target.value === '' ? null : +e.target.value) })])
Field.props = ['label', 'modelValue', 'step']
Field.emits = ['update:modelValue']

const NUM = ['account_size', 'risk_pct', 'cap_pct', 'max_stop_pct', 'max_stop_adr', 'ideal_stop_adr', 'max_trades_day', 'est_charges_pct']
const f = reactive({}), intraday = ref(true), per = ref({ per: 'All', from: '', to: '' })
const rows = ref([]), msg = ref(''), cmsg = ref(''), cerr = ref(false), saving = ref(false), confirmText = ref('')

function fill() {
  const p = app.boot?.playbook || {}
  for (const k of [...NUM, 'goal']) f[k] = p[k] ?? null
  intraday.value = !!+p.include_intraday
  per.value = { per: p.stats_period || 'All', from: p.stats_from || '', to: p.stats_to || '' }
}
async function loadCharges() {
  rows.value = (await get('charges')).rows.map((r) => ({ from: r.from || r.from_date, to: r.to || r.to_date, amount: +r.amount }))
}
onActivated(() => { fill(); loadCharges() })
fill(); loadCharges()

async function save() {
  saving.value = true; msg.value = ''
  try {
    const fields = { ...f, include_intraday: intraday.value ? 1 : 0, stats_period: per.value.per,
                     stats_from: per.value.from || null, stats_to: per.value.to || null }
    if (+!!+app.boot.playbook.include_intraday !== fields.include_intraday) msg.value = 'Rebuilding…'
    const r = await post('save_playbook', { fields })
    app.boot.playbook = { ...app.boot.playbook, ...r.playbook }
    await loadBoot(); changed()
    msg.value = 'Saved.'
  } catch (e) { msg.value = e.message } finally { saving.value = false }
}
function addRow() {
  const last = rows.value[rows.value.length - 1]
  rows.value.push({ from: last?.to || '', to: '', amount: null })
}
async function saveCharges() {
  cerr.value = false
  try {
    const r = await post('save_charges', { rows: rows.value })
    cmsg.value = `Saved — ${inr(r.total)} recorded.`; changed(); await loadCharges()
  } catch (e) { cerr.value = true; cmsg.value = e.message }
}
async function exportData() {
  const d = await get('export_my_data')
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob([JSON.stringify(d, null, 1)], { type: 'application/json' }))
  a.download = `swingdesk-${d.exported.slice(0, 10)}.json`
  a.click(); URL.revokeObjectURL(a.href)
}
async function wipe() {
  await post('delete_my_data', { confirm: 'DELETE' })
  confirmText.value = ''
  await loadBoot(); changed(); fill(); loadCharges()
}
</script>
