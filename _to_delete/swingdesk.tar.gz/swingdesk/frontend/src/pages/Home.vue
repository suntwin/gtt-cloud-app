<template>
  <div class="mx-auto flex max-w-6xl flex-col gap-4">
    <div class="flex flex-wrap items-end gap-3">
      <h1 class="text-xl font-bold">Home</h1>
      <div class="flex-1" />
      <PeriodPicker v-model="period" />
      <RouterLink to="/swing/plan" class="flex h-9 items-center rounded-lg bg-[#171717] px-3 text-sm font-semibold text-white">+ Plan a trade</RouterLink>
    </div>

    <div v-if="err" class="rounded-xl border border-[#F5C2C0] bg-[#FDECEC] p-3 text-sm">{{ err }}</div>
    <div v-if="!d && !err" class="p-10 text-center text-sm text-[#616161]">Loading…</div>

    <div v-else-if="d && !d.summary.n && !d.open.length" class="rounded-2xl border border-dashed border-[#D4D4D4] bg-white p-8 text-center">
      <div class="text-lg font-semibold">Bring in your trades</div>
      <p class="mx-auto mt-1 max-w-md text-sm text-[#616161]">Drop your Zerodha tradebook (Console → Reports → Tradebook → Equity → CSV). Splits, intraday and carried positions are worked out for you.</p>
      <RouterLink to="/swing/import" class="mt-4 inline-flex h-10 items-center rounded-lg bg-[#171717] px-4 text-sm font-semibold text-white">Import tradebook</RouterLink>
    </div>

    <template v-else-if="d">
      <div class="text-xs text-[#616161]">Showing <b>{{ d.period.label }}</b> — trades closed in this period{{ s.left_out ? ` · ${s.left_out} left out of the stats` : '' }}</div>
      <div class="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <Tile label="Net after charges" :value="inr(s.net_after_charges, { sign: true })" :cls="tone(s.net_after_charges)"
              :sub="`realised ${inr(s.net_realised, { sign: true })} − charges ${inr(s.charges)}${s.charges_estimated > 0.5 ? ' (part est.)' : ''}`" />
        <Tile label="Win rate" :value="pct(s.win_rate * 100, 0)"
              :sub="s.breakeven_win_rate ? `break-even ${pct(s.breakeven_win_rate * 100, 1)} · ${s.win_rate >= s.breakeven_win_rate ? 'above it ✓' : 'below it'}` : ''"
              :subcls="s.breakeven_win_rate && s.win_rate >= s.breakeven_win_rate ? 'text-[#1E7B34]' : 'text-[#B42318]'" />
        <Tile label="Payoff" :value="s.payoff ? s.payoff.toFixed(2) : '—'" sub="avg win ÷ avg loss" />
        <Tile label="Expectancy" :value="inr(s.expectancy, { sign: true, lakh: false })" sub="per trade, before charges" />
        <Tile label="Average R" :value="s.r.avg !== null ? s.r.avg.toFixed(2) + 'R' : '—'"
              :sub="s.r.n ? `${s.r.n} trade${s.r.n === 1 ? '' : 's'} with a stop` : 'add initial stops in the Journal'" />
        <Tile label="Max drawdown" :value="inr(s.max_drawdown)" sub="after charges, by exit day" />
      </div>

      <section class="rounded-xl border border-[#EBEBEB] bg-white p-4">
        <div class="mb-2 flex items-baseline gap-2"><h2 class="text-sm font-semibold">Equity after charges</h2>
          <span class="text-xs text-[#616161]">cumulative ₹ by exit day</span></div>
        <div v-if="curve" class="relative">
          <span class="absolute left-1 top-0 text-xs text-[#616161]">{{ inr(curve.max) }}</span>
          <svg :viewBox="`0 0 1000 ${H}`" preserveAspectRatio="none" width="100%" :height="H" role="img" aria-label="Equity curve" class="block">
            <line x1="0" :y1="curve.zero" x2="1000" :y2="curve.zero" stroke="#E5E5E5" vector-effect="non-scaling-stroke" />
            <polyline fill="none" stroke="#171717" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke" :points="curve.pts" />
          </svg>
          <div class="flex justify-between text-xs text-[#616161]"><span>{{ curve.first }}</span><span>{{ curve.last }}</span></div>
        </div>
        <div v-else class="py-8 text-center text-sm text-[#616161]">No closed trades in this period.</div>
      </section>

      <div class="grid gap-3 md:grid-cols-2">
        <section class="flex flex-col gap-3 rounded-xl border border-[#EBEBEB] bg-white p-4">
          <h2 class="text-sm font-semibold">Swing vs intraday</h2>
          <div v-for="k in ['swing', 'intraday']" :key="k" class="flex flex-col gap-1">
            <div class="flex justify-between text-sm"><span><b class="capitalize">{{ k }}</b> · {{ s.by_kind[k].n }} trades
              <span v-if="s.by_kind[k].win_rate !== null" class="text-[#616161]">· {{ pct(s.by_kind[k].win_rate * 100, 0) }} wins</span></span>
              <b :class="tone(s.by_kind[k].pnl)">{{ inr(s.by_kind[k].pnl, { sign: true }) }}</b></div>
            <div class="h-2.5 rounded-full bg-[#F0F0F0]"><div class="h-2.5 rounded-full" :style="{ width: bar(k), background: s.by_kind[k].pnl >= 0 ? '#2E8B57' : '#D9534F' }" /></div>
          </div>
          <div v-if="s.avg_days_swing !== null" class="text-xs text-[#616161]">Swing trades held {{ s.avg_days_swing.toFixed(1) }} days on average.</div>
        </section>
        <section class="flex flex-col gap-2 rounded-xl border border-[#F3DDB0] bg-[#FFF8EB] p-4">
          <h2 class="text-sm font-semibold">The lesson</h2>
          <p class="text-sm leading-relaxed">{{ d.lesson || 'Import more history to get a lesson.' }}</p>
          <RouterLink v-if="d.n_review" to="/swing/journal?check=1" class="text-sm font-semibold underline">{{ d.n_review }} trades to check →</RouterLink>
        </section>
      </div>

      <section v-if="d.open.length" class="rounded-xl border border-[#EBEBEB] bg-white p-4">
        <div class="mb-2 flex flex-wrap items-baseline gap-2"><h2 class="text-sm font-semibold">Open positions</h2>
          <span class="text-xs text-[#616161]">risk to stops {{ inr(d.open_risk) }}<span v-if="d.open_risk_pct !== null"> · {{ pct(d.open_risk_pct, 2) }} of account</span></span>
          <span v-if="d.no_stop.length" class="text-xs font-medium text-[#9A4A00]">· no stop entered: {{ d.no_stop.join(', ') }}</span></div>
        <div class="overflow-x-auto"><table class="w-full min-w-[560px] text-sm">
          <thead><tr class="text-left text-xs text-[#616161]"><th class="py-1.5 font-medium">Symbol</th><th class="font-medium">Since</th>
            <th class="text-right font-medium">Shares</th><th class="text-right font-medium">Avg cost</th><th class="text-right font-medium">Stop</th>
            <th class="text-right font-medium">Risk to stop</th><th class="text-right font-medium">Booked</th></tr></thead>
          <tbody><tr v-for="o in d.open" :key="o.key" class="border-t border-[#F3F3F3]">
            <td class="py-2 font-semibold">{{ o.symbol }}</td><td>{{ o.entry_date }}</td><td class="text-right">{{ o.open_qty }}</td>
            <td class="text-right">{{ num(o.avg_cost) }}</td><td class="text-right">{{ o.stop ? num(o.stop) : '—' }}</td>
            <td class="text-right">{{ o.risk !== null ? inr(o.risk, { lakh: false }) : '—' }}</td>
            <td class="text-right" :class="tone(o.booked)">{{ o.booked ? inr(o.booked, { sign: true, lakh: false }) : '—' }}</td></tr></tbody>
        </table></div>
      </section>

      <section class="rounded-xl border border-[#EBEBEB] bg-white p-4">
        <div class="mb-2 flex items-baseline"><h2 class="text-sm font-semibold">Recent trades</h2><div class="flex-1" />
          <RouterLink to="/swing/journal" class="text-sm font-medium underline">Open journal →</RouterLink></div>
        <TradeTable :rows="d.recent" />
      </section>
    </template>
  </div>
</template>
<script setup>
import { computed, ref, watch, onActivated, h } from 'vue'
import { get } from '@/lib/api'
import { app, inr, pct, num, tone } from '@/lib/store'
import PeriodPicker from '@/components/PeriodPicker.vue'
import TradeTable from '@/components/TradeTable.vue'

const Tile = (p) => h('div', { class: 'flex flex-col gap-1 rounded-xl border border-[#EBEBEB] bg-white px-4 py-3' }, [
  h('span', { class: 'text-xs text-[#616161]' }, p.label), h('span', { class: ['text-xl font-bold tabular-nums', p.cls] }, p.value),
  p.sub ? h('span', { class: ['text-xs', p.subcls || 'text-[#616161]'] }, p.sub) : null])
Tile.props = ['label', 'value', 'sub', 'cls', 'subcls']

const d = ref(null), err = ref(''), period = ref(null), H = 180
const s = computed(() => d.value?.summary)
let ver = -1
async function load() {
  err.value = ''
  try {
    const p = period.value
    d.value = await get('dashboard', p ? { period: p.per, date_from: p.from || undefined, date_to: p.to || undefined } : {})
    if (!period.value) period.value = { per: d.value.period.per, from: d.value.period.from, to: d.value.period.to }
    ver = app.version
  } catch (e) { err.value = e.message }
}
watch(period, (n, o) => { if (o) load() }, { deep: true })
onActivated(() => { if (!d.value || ver !== app.version) load() })
load()

const curve = computed(() => {
  const c = s.value?.curve || []
  if (c.length < 2) return null
  const ys = c.map((p) => p[1]), lo = Math.min(0, ...ys), hi = Math.max(0, ...ys), span = hi - lo || 1
  const y = (v) => 20 + (H - 26) * (1 - (v - lo) / span)
  return { pts: c.map((p, i) => `${(i / (c.length - 1)) * 1000},${y(p[1]).toFixed(1)}`).join(' '), zero: y(0),
           first: c[0][0], last: c[c.length - 1][0], max: hi }
})
const bar = (k) => {
  const a = Math.abs(s.value.by_kind.swing.pnl), b = Math.abs(s.value.by_kind.intraday.pnl), m = Math.max(a, b) || 1
  return `${Math.round(Math.abs(s.value.by_kind[k].pnl) / m * 100)}%`
}
</script>
