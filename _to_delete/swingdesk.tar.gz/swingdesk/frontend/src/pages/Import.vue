<template>
  <div class="mx-auto flex max-w-3xl flex-col gap-4">
    <h1 class="text-xl font-bold">Import</h1>

    <label class="flex cursor-pointer flex-col items-center gap-2 rounded-2xl border-2 border-dashed p-8 text-center transition"
           :class="over ? 'border-[#171717] bg-white' : 'border-[#D4D4D4] bg-white/60'"
           @dragover.prevent="over = true" @dragleave="over = false" @drop.prevent="drop">
      <input type="file" accept=".csv,text/csv" multiple class="hidden" :disabled="busy" @change="pick" />
      <div class="text-base font-semibold">{{ busy ? 'Importing…' : 'Drop Zerodha tradebook CSVs here' }}</div>
      <div class="max-w-md text-sm text-[#616161]">Console → Reports → Tradebook → Equity → pick a date range (one year max) → download CSV.
        Drop several years at once. Files that overlap are fine — nothing is counted twice.</div>
      <span v-if="!busy" class="mt-1 inline-flex h-9 items-center rounded-lg bg-[#171717] px-4 text-sm font-semibold text-white">Choose files</span>
    </label>

    <section v-if="log.length" class="flex flex-col gap-1.5 rounded-xl border border-[#EBEBEB] bg-white p-4 text-sm">
      <div v-for="(l, i) in log" :key="i" class="flex gap-2">
        <span :class="l.state === 'error' ? 'text-[#B42318]' : l.state === 'done' ? 'text-[#1E7B34]' : 'text-[#616161]'">{{ l.state === 'error' ? '✕' : l.state === 'done' ? '✓' : '…' }}</span>
        <span><b>{{ l.name }}</b> — {{ l.message }}</span></div>
    </section>

    <section v-if="b && b.fills" class="flex flex-col gap-3 rounded-xl border border-[#EBEBEB] bg-white p-4">
      <h2 class="text-sm font-semibold">What we worked out</h2>
      <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div><div class="text-xs text-[#616161]">History</div><div class="text-sm font-semibold">{{ b.from }} → {{ b.to }}</div></div>
        <div><div class="text-xs text-[#616161]">Executions</div><div class="text-sm font-semibold tabular-nums">{{ b.fills.toLocaleString('en-IN') }}</div></div>
        <div><div class="text-xs text-[#616161]">Trades</div><div class="text-sm font-semibold tabular-nums">{{ b.closed }} closed · {{ b.open }} open</div></div>
        <div><div class="text-xs text-[#616161]">Duplicates skipped</div><div class="text-sm font-semibold tabular-nums">{{ b.duplicates }}</div></div>
      </div>
      <div v-if="Object.keys(b.splits || {}).length" class="text-sm">
        <span class="font-medium">Splits / bonus found:</span>
        <span v-for="(v, k) in b.splits" :key="k" class="ml-2">{{ k }} {{ v.map((x) => `×${x[1]} on ${x[0]}`).join(', ') }}</span>
      </div>
      <div v-if="b.n_unmatched" class="flex flex-col gap-1 text-sm">
        <div class="font-medium">{{ b.n_unmatched }} sales with no matching buy
          <span class="font-normal text-[#616161]">— usually shares bought before the history you imported. Import the earlier year, or leave them out.</span></div>
        <div v-for="u in b.unmatched.slice(0, showAll ? 300 : 8)" :key="u.symbol + u.date + u.qty" class="flex flex-wrap items-center gap-x-3 border-t border-[#F3F3F3] py-1.5">
          <b class="w-28">{{ u.symbol }}</b><span class="tabular-nums">{{ u.date }}</span><span class="tabular-nums">{{ u.qty }} @ {{ num(u.price) }}</span>
          <span class="min-w-40 flex-1 text-xs text-[#616161]">{{ u.why }}</span>
          <button class="text-xs underline" @click="dismiss(u)">Leave out</button></div>
        <button v-if="b.unmatched.length > 8 && !showAll" class="self-start text-xs underline" @click="showAll = true">Show all</button>
      </div>
      <RouterLink to="/swing" class="self-start text-sm font-semibold underline">See your numbers →</RouterLink>
    </section>
  </div>
</template>
<script setup>
import { computed, ref } from 'vue'
import { get, post } from '@/lib/api'
import { app, changed, loadBoot, num } from '@/lib/store'

const over = ref(false), busy = ref(false), log = ref([]), showAll = ref(false)
const b = computed(() => app.boot?.build)
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const pick = (e) => run([...e.target.files]).finally(() => { e.target.value = '' })
const drop = (e) => { over.value = false; run([...e.dataTransfer.files]) }

async function run(files) {
  if (busy.value || !files.length) return
  busy.value = true
  files.sort((x, y) => x.name.localeCompare(y.name))
  try {
    for (const f of files) {
      const l = { name: f.name, state: 'running', message: 'uploading' }
      log.value.push(l)
      const row = log.value[log.value.length - 1]
      try {
        await post('import_tradebook', { csv_text: await f.text() })
        for (;;) {
          await sleep(900)
          const j = await get('job_status')
          if (j.state === 'done' || j.state === 'error') { row.state = j.state; row.message = j.message; break }
          row.message = j.step || 'waiting to start'
        }
      } catch (e) { row.state = 'error'; row.message = e.message }
    }
  } finally {
    busy.value = false
    await loadBoot(); changed()
  }
}
async function dismiss(u) {
  if (!confirm(`Leave out the ${u.symbol} sale on ${u.date}? It stays stored but won't count.`)) return
  const s = await post('dismiss_unmatched', { symbol: u.symbol, date: u.date })
  app.boot.build = s; changed()
}
</script>
