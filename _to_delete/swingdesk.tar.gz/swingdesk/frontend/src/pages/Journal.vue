<template>
  <div class="mx-auto flex max-w-6xl flex-col gap-4">
    <div class="flex flex-wrap items-end gap-3">
      <h1 class="text-xl font-bold">Journal</h1>
      <div class="flex-1" />
      <PeriodPicker v-model="period" />
    </div>
    <div class="flex flex-wrap items-center gap-2 text-sm">
      <input v-model="q" placeholder="Symbol" class="h-9 w-36 rounded-lg border border-[#E0E0E0] bg-white px-3 py-0 text-sm uppercase" />
      <select v-model="kind" class="h-9 rounded-lg border border-[#E0E0E0] bg-white px-2 py-0 pr-8 text-sm" aria-label="Kind">
        <option value="">Swing + intraday</option><option value="swing">Swing</option><option value="intraday">Intraday</option></select>
      <select v-model="st" class="h-9 rounded-lg border border-[#E0E0E0] bg-white px-2 py-0 pr-8 text-sm" aria-label="Status">
        <option value="">Closed + open</option><option value="closed">Closed</option><option value="open">Open</option></select>
      <select v-model="setup" class="h-9 rounded-lg border border-[#E0E0E0] bg-white px-2 py-0 pr-8 text-sm" aria-label="Setup">
        <option value="">Any setup</option><option v-for="s in setups" :key="s" :value="s">{{ s }}</option></select>
      <label class="flex items-center gap-1.5"><input v-model="check" type="checkbox" class="size-4" /> Only trades to check</label>
      <div class="flex-1" />
      <span class="text-xs text-[#616161]">{{ d ? `${d.n} trades · ${d.period.label}` : '' }}</span>
    </div>
    <div v-if="err" class="rounded-xl border border-[#F5C2C0] bg-[#FDECEC] p-3 text-sm">{{ err }}</div>
    <section class="rounded-xl border border-[#EBEBEB] bg-white p-4">
      <div v-if="!d" class="py-6 text-center text-sm text-[#616161]">Loading…</div>
      <TradeTable v-else :rows="shown" :empty="check ? 'Nothing to check — all clear.' : 'No trades match.'" @open="openTrade" />
      <button v-if="d && d.rows.length > shown.length" class="mt-3 text-sm underline" @click="limit += 200">Show more</button>
    </section>

    <div v-if="sel" class="fixed inset-0 z-50 flex justify-end bg-black/30" @click.self="sel = null">
      <aside class="flex h-full w-full max-w-md flex-col gap-4 overflow-y-auto bg-white p-5 shadow-xl" role="dialog" aria-label="Trade">
        <div class="flex items-start gap-2">
          <div><div class="text-lg font-bold">{{ sel.symbol }} <span class="text-sm font-normal capitalize text-[#616161]">{{ sel.kind }}</span></div>
            <div class="text-xs text-[#616161]">{{ sel.entry_date }} → {{ sel.exit_date || 'open' }} · {{ sel.days ?? '' }}{{ sel.days !== null && sel.days !== undefined ? ' days' : '' }}</div></div>
          <div class="flex-1" /><button class="text-sm text-[#616161]" aria-label="Close" @click="sel = null">✕</button>
        </div>
        <div class="grid grid-cols-3 gap-2 text-sm">
          <div><div class="text-xs text-[#616161]">P&amp;L</div><b :class="tone(sel.pnl)">{{ inr(sel.pnl, { sign: true, lakh: false }) }}</b></div>
          <div><div class="text-xs text-[#616161]">Return</div><b>{{ pct(sel.return_pct, 1, true) }}</b></div>
          <div><div class="text-xs text-[#616161]">R</div><b>{{ sel.r !== null && sel.r !== undefined ? sel.r.toFixed(2) + 'R' : '—' }}</b></div>
          <div><div class="text-xs text-[#616161]">First buy</div>{{ sel.first_qty }} @ {{ num(sel.first_price) }}</div>
          <div><div class="text-xs text-[#616161]">Avg cost</div>{{ num(sel.avg_cost) }}</div>
          <div><div class="text-xs text-[#616161]">Adds / exits</div>{{ sel.adds }} / {{ sel.exits }}</div>
        </div>
        <div v-if="sel.flags?.length" class="rounded-lg bg-[#FFF8EB] p-3 text-sm">
          <div class="mb-1 font-semibold">Worth a look</div>
          <div v-for="fl in sel.flags" :key="fl">• {{ fl }}</div>
        </div>
        <div v-if="sel.exits_detail?.length" class="text-sm">
          <div class="mb-1 text-xs text-[#616161]">Exits</div>
          <div v-for="(x, i) in sel.exits_detail" :key="i" class="flex justify-between border-t border-[#F3F3F3] py-1 tabular-nums">
            <span>{{ x.date }}</span><span>{{ x.qty }} @ {{ num(x.price) }}</span><span :class="tone(x.pnl)">{{ inr(x.pnl, { sign: true, lakh: false }) }}</span></div>
        </div>

        <div class="flex flex-col gap-3 border-t border-[#EBEBEB] pt-4 text-sm">
          <label class="flex flex-col gap-1 text-xs text-[#616161]">Setup
            <select v-model="a.setup" class="h-9 rounded-lg border border-[#E0E0E0] px-2 text-sm text-[#171717]"><option value="">—</option>
              <option v-for="s in setups" :key="s" :value="s">{{ s }}</option></select></label>
          <label class="flex flex-col gap-1 text-xs text-[#616161]">Initial stop (gives you R)
            <input v-model="a.stop" type="number" step="0.05" inputmode="decimal" class="h-9 rounded-lg border border-[#E0E0E0] px-3 text-sm text-[#171717]" /></label>
          <label class="flex flex-col gap-1 text-xs text-[#616161]">In the stats?
            <select v-model="a.stats" class="h-9 rounded-lg border border-[#E0E0E0] px-2 text-sm text-[#171717]">
              <option value="">{{ sel.auto_exclude ? 'Automatic (left out — looks wrong)' : 'Automatic (counted)' }}</option>
              <option value="include">Always count it</option><option value="exclude">Leave it out</option></select></label>
          <label class="flex flex-col gap-1 text-xs text-[#616161]">Followed my rules?
            <select v-model="a.rules_ok" class="h-9 rounded-lg border border-[#E0E0E0] px-2 text-sm text-[#171717]"><option value="">—</option>
              <option>Yes</option><option>No</option></select></label>
          <label class="flex flex-col gap-1 text-xs text-[#616161]">Note
            <textarea v-model="a.note" rows="3" class="rounded-lg border border-[#E0E0E0] p-2 text-sm text-[#171717]" /></label>
          <div class="flex items-center gap-3">
            <button class="h-10 rounded-lg bg-[#171717] px-4 text-sm font-semibold text-white disabled:opacity-40" :disabled="saving" @click="saveA">Save</button>
            <span class="text-sm text-[#616161]">{{ amsg }}</span></div>
        </div>
      </aside>
    </div>
  </div>
</template>
<script setup>
import { computed, reactive, ref, watch, onActivated } from 'vue'
import { useRoute } from 'vue-router'
import { get, post } from '@/lib/api'
import { app, changed, inr, pct, num, tone } from '@/lib/store'
import PeriodPicker from '@/components/PeriodPicker.vue'
import TradeTable from '@/components/TradeTable.vue'

const route = useRoute()
const setups = computed(() => app.boot?.setups || [])
const d = ref(null), err = ref(''), period = ref(null), q = ref(''), kind = ref(''), st = ref(''), setup = ref(''), check = ref(false), limit = ref(200)
const sel = ref(null), a = reactive({ setup: '', stop: '', stats: '', rules_ok: '', note: '' }), saving = ref(false), amsg = ref('')
const shown = computed(() => (d.value?.rows || []).slice(0, limit.value))
let ver = -1, seq = 0

async function load() {
  err.value = ''
  const mine = ++seq
  try {
    const p = period.value
    const r = await get('trades', { ...(p ? { period: p.per, date_from: p.from || undefined, date_to: p.to || undefined } : {}),
      kind: kind.value || undefined, status: st.value || undefined, setup: setup.value || undefined, only_check: check.value ? 1 : undefined, q: q.value || undefined })
    if (mine !== seq) return
    d.value = r
    if (!period.value) period.value = { per: r.period.per, from: '', to: '' }
    ver = app.version
  } catch (e) { err.value = e.message }
}
let t
watch([q, kind, st, setup, check], () => { clearTimeout(t); t = setTimeout(load, 200) })
watch(period, (n, o) => { if (o) load() }, { deep: true })
watch(() => route.query.check, (c) => { if (route.name === 'journal') check.value = c === '1' }, { immediate: true })
onActivated(() => { if (!d.value || ver !== app.version) load() })
load()

async function openTrade(r) {
  amsg.value = ''
  const x = await get('trade', { key: r.key })
  sel.value = x
  Object.assign(a, { setup: x.setup || '', stop: x.stop ?? '', stats: x.stats || '', rules_ok: x.rules_ok || '', note: x.note || '' })
}
async function saveA() {
  saving.value = true
  try {
    await post('annotate', { trade_key: sel.value.key, fields: { ...a } })
    amsg.value = 'Saved.'
    changed(); await load()
    sel.value = null
  } catch (e) { amsg.value = e.message } finally { saving.value = false }
}
</script>
