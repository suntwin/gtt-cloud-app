<template>
  <div class="mx-auto flex max-w-3xl flex-col gap-4">
    <h1 class="text-xl font-bold">Plan a trade</h1>

    <section v-if="!acct" class="flex flex-col gap-3 rounded-xl border border-[#F3DDB0] bg-[#FFF8EB] p-4">
      <div class="text-sm font-semibold">First, how big is your account?</div>
      <p class="text-sm text-[#616161]">Every plan is sized from this: you risk a small, fixed slice of it on each trade.</p>
      <div class="flex flex-wrap items-end gap-3">
        <label class="flex flex-col gap-1 text-xs text-[#616161]">Account size (₹)
          <input v-model.number="setup0.account_size" type="number" inputmode="numeric" class="h-10 w-44 rounded-lg border border-[#E0E0E0] bg-white px-3 text-sm text-[#171717]" /></label>
        <label class="flex flex-col gap-1 text-xs text-[#616161]">Risk per trade (%)
          <input v-model.number="setup0.risk_pct" type="number" step="0.05" class="h-10 w-28 rounded-lg border border-[#E0E0E0] bg-white px-3 text-sm text-[#171717]" /></label>
        <button class="h-10 rounded-lg bg-[#171717] px-4 text-sm font-semibold text-white disabled:opacity-40" :disabled="!setup0.account_size" @click="saveAcct">Save</button>
      </div>
    </section>

    <section class="flex flex-col gap-4 rounded-xl border border-[#EBEBEB] bg-white p-4" :class="!acct ? 'pointer-events-none opacity-40' : ''">
      <div class="grid grid-cols-3 gap-3">
        <label class="flex flex-col gap-1 text-xs text-[#616161]">Symbol
          <input ref="symEl" v-model="f.symbol" autocapitalize="characters" placeholder="PPLPHARMA" class="h-11 rounded-lg border border-[#E0E0E0] px-3 text-base font-semibold uppercase text-[#171717]" /></label>
        <label class="flex flex-col gap-1 text-xs text-[#616161]">Entry
          <input v-model="f.entry" type="number" inputmode="decimal" step="0.05" class="h-11 rounded-lg border border-[#E0E0E0] px-3 text-base tabular-nums text-[#171717]" /></label>
        <label class="flex flex-col gap-1 text-xs text-[#616161]">Stop
          <input v-model="f.stop" type="number" inputmode="decimal" step="0.05" class="h-11 rounded-lg border border-[#E0E0E0] px-3 text-base tabular-nums text-[#171717]" @keydown.enter="save" /></label>
      </div>

      <div v-if="calc && calc.ok" class="grid grid-cols-2 gap-3 rounded-xl p-4 sm:grid-cols-4" :class="vbg[calc.verdict]">
        <div><div class="text-xs text-[#616161]">Buy</div><div class="text-2xl font-bold tabular-nums">{{ calc.shares }}</div><div class="text-xs text-[#616161]">shares</div></div>
        <div><div class="text-xs text-[#616161]">Risk if stopped</div><div class="text-2xl font-bold tabular-nums">{{ inr(calc.risk_rs, { lakh: false }) }}</div>
          <div class="text-xs text-[#616161]">budget {{ inr(calc.risk_budget, { lakh: false }) }}</div></div>
        <div><div class="text-xs text-[#616161]">Position</div><div class="text-2xl font-bold tabular-nums">{{ inr(calc.position_rs) }}</div>
          <div class="text-xs" :class="calc.capped ? 'font-medium text-[#9A4A00]' : 'text-[#616161]'">{{ pct(calc.position_pct, 1) }} of account{{ calc.capped ? ' · capped' : '' }}</div></div>
        <div><div class="text-xs text-[#616161]">Stop</div><div class="text-2xl font-bold tabular-nums">{{ pct(calc.stop_pct, 2) }}</div>
          <div class="text-xs text-[#616161]">2R {{ num(calc.t2) }} · 3R {{ num(calc.t3) }}</div></div>
        <div class="col-span-2 text-sm sm:col-span-4"><b class="capitalize">{{ vword[calc.verdict] }}</b>
          <span v-if="calc.plain"> — the stop is {{ calc.plain }}.</span>
          <span v-else-if="calc.verdict === 'wide'"> — more than your {{ pb.max_stop_pct || 5 }}% limit.</span></div>
      </div>
      <div v-else-if="calc && !calc.ok" class="text-sm text-[#B42318]">{{ calc.message }}</div>
      <div v-else-if="calcErr" class="text-sm text-[#B42318]">{{ calcErr }}</div>

      <details class="text-sm" :open="!!f.adr_pct">
        <summary class="cursor-pointer text-[#616161]">More (optional): how much it moves, setup, 1-min ORH</summary>
        <div class="mt-3 flex flex-col gap-3">
          <label class="flex items-center gap-2 text-xs text-[#616161]">A normal day's move (ADR %)
            <input v-model="f.adr_pct" type="number" step="0.1" placeholder="e.g. 4.2" class="h-9 w-24 rounded-lg border border-[#E0E0E0] px-2 text-sm text-[#171717]" />
            <span>— lets us say whether the stop is tight for this stock</span></label>
          <div class="flex flex-wrap gap-2">
            <button v-for="s in setups" :key="s" class="h-8 rounded-full border px-3 text-xs"
                    :class="f.setup === s ? 'border-[#171717] bg-[#171717] text-white' : 'border-[#E0E0E0] bg-white'" @click="f.setup = f.setup === s ? '' : s">{{ s }}</button>
          </div>
          <label class="flex items-center gap-2 text-sm"><input v-model="f.orh" type="checkbox" class="size-4" /> Enter on the 1-minute opening-range high</label>
          <input v-model="f.note" placeholder="Note (why this one?)" class="h-9 rounded-lg border border-[#E0E0E0] px-3 text-sm" />
        </div>
      </details>

      <div class="flex items-center gap-3">
        <button class="h-10 rounded-lg bg-[#171717] px-4 text-sm font-semibold text-white disabled:opacity-40" :disabled="!canSave || saving" @click="save">Add to plan</button>
        <span v-if="msg" class="text-sm text-[#616161]">{{ msg }}</span>
      </div>
    </section>

    <section class="rounded-xl border border-[#EBEBEB] bg-white p-4">
      <div class="mb-2 flex flex-wrap items-baseline gap-2"><h2 class="text-sm font-semibold">Planned</h2>
        <span v-if="list.length" class="text-xs text-[#616161]">{{ list.length }} · total risk {{ inr(totalRisk, { lakh: false }) }}
          <span v-if="acct">({{ pct(totalRisk / acct * 100, 2) }} of account if all trigger and stop out)</span></span></div>
      <div v-if="!list.length" class="py-4 text-center text-sm text-[#616161]">Nothing planned yet.</div>
      <div v-for="p in list" :key="p.name" class="flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-[#F3F3F3] py-2.5 text-sm">
        <b class="w-28">{{ p.symbol }}</b>
        <span class="tabular-nums">{{ num(p.entry) }} / {{ num(p.stop) }}</span>
        <span class="tabular-nums">{{ p.shares }} sh · risk {{ inr(p.risk_rs, { lakh: false }) }}</span>
        <span class="rounded px-1.5 py-0.5 text-[11px] font-medium" :class="vbg[p.verdict]">{{ vword[p.verdict] }}</span>
        <span class="text-xs text-[#616161]">{{ [p.setup, p.orh ? '1-min ORH' : '', p.plan_date].filter(Boolean).join(' · ') }}</span>
        <div class="flex-1" />
        <button class="text-xs font-medium underline" @click="status(p, 'triggered')">Triggered</button>
        <button class="text-xs text-[#616161] underline" @click="status(p, 'skipped')">Skip</button>
        <button class="text-xs text-[#B42318] underline" @click="status(p, 'deleted')">Delete</button>
      </div>
    </section>
  </div>
</template>
<script setup>
import { computed, reactive, ref, watch, onActivated } from 'vue'
import { get, post } from '@/lib/api'
import { app, inr, pct, num } from '@/lib/store'

const pb = computed(() => app.boot?.playbook || {})
const acct = computed(() => +pb.value.account_size || 0)
const setups = computed(() => app.boot?.setups || [])
const setup0 = reactive({ account_size: null, risk_pct: 0.25 })
const f = reactive({ symbol: '', entry: '', stop: '', adr_pct: '', setup: '', orh: false, note: '' })
const calc = ref(null), calcErr = ref(''), msg = ref(''), saving = ref(false), list = ref([]), symEl = ref(null)
const vword = { tight: 'Tight stop', ok: 'Stop OK', wide: 'Wide stop' }
const vbg = { tight: 'bg-[#E9F7EE]', ok: 'bg-[#F4F4F4]', wide: 'bg-[#FDECEC]' }
const canSave = computed(() => f.symbol && calc.value?.ok)
const totalRisk = computed(() => list.value.reduce((a, p) => a + (+p.risk_rs || 0), 0))

let timer
watch(() => [f.entry, f.stop, f.adr_pct, acct.value], () => {
  clearTimeout(timer)
  if (!f.entry || !f.stop || !acct.value) { calc.value = null; return }
  timer = setTimeout(async () => {
    try { calcErr.value = ''; calc.value = await get('plan_calc', { entry: f.entry, stop: f.stop, adr_pct: f.adr_pct || undefined }) }
    catch (e) { calc.value = null; calcErr.value = e.message }
  }, 250)
})

async function saveAcct() {
  const r = await post('save_playbook', { fields: { account_size: setup0.account_size, risk_pct: setup0.risk_pct } })
  app.boot.playbook = { ...app.boot.playbook, ...r.playbook }
}
async function save() {
  if (!canSave.value) return
  saving.value = true; msg.value = ''
  try {
    await post('save_plan', { symbol: f.symbol, entry: f.entry, stop: f.stop, adr_pct: f.adr_pct || undefined, setup: f.setup, orh: f.orh ? 1 : 0, note: f.note })
    msg.value = `${f.symbol.toUpperCase()} added.`
    Object.assign(f, { symbol: '', entry: '', stop: '', adr_pct: '', setup: '', orh: false, note: '' })
    symEl.value?.focus()
    await load()
  } catch (e) { msg.value = e.message } finally { saving.value = false }
}
async function status(p, s) {
  await post('set_plan_status', { name: p.name, status: s })
  list.value = list.value.filter((x) => x.name !== p.name)
}
async function load() { list.value = (await get('plans', { status: 'planned' })).rows }
onActivated(load)
load()
</script>
