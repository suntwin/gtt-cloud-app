<template>
  <div class="flex flex-wrap items-center gap-2 text-sm">
    <select :value="v.per" @change="set({ per: $event.target.value })" aria-label="Period"
            class="h-9 rounded-lg border border-[#E0E0E0] bg-white px-2 text-sm">
      <option v-for="p in periods" :key="p" :value="p">{{ p }}</option>
    </select>
    <template v-if="v.per === 'Since date' || v.per === 'Custom range'">
      <input type="date" :value="v.from || ''" @change="set({ from: $event.target.value })" aria-label="From"
             class="h-9 rounded-lg border border-[#E0E0E0] bg-white px-2 text-sm" />
      <template v-if="v.per === 'Custom range'">
        <span class="text-[#616161]">→</span>
        <input type="date" :value="v.to || today" @change="set({ to: $event.target.value })" aria-label="To"
               class="h-9 rounded-lg border border-[#E0E0E0] bg-white px-2 text-sm" />
        <button v-if="v.to && v.to !== today" class="text-xs underline" @click="set({ to: '' })">today</button>
      </template>
    </template>
  </div>
</template>
<script setup>
import { computed } from 'vue'
import { app } from '@/lib/store'
const props = defineProps({ modelValue: Object })
const emit = defineEmits(['update:modelValue'])
const today = new Date().toLocaleDateString('en-CA')
const periods = computed(() => app.boot?.periods || ['All'])
const v = computed(() => props.modelValue || { per: 'All', from: '', to: '' })
function set(x) {
  const n = { ...v.value, ...x }
  if (n.to && n.to >= today) n.to = ''
  emit('update:modelValue', n)
}
</script>
