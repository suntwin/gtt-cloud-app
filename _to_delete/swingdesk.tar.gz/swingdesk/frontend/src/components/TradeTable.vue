<template>
  <div v-if="!rows.length" class="py-6 text-center text-sm text-[#616161]">{{ empty }}</div>
  <div v-else class="overflow-x-auto">
    <table class="w-full min-w-[640px] text-sm">
      <thead><tr class="text-left text-xs text-[#616161]">
        <th class="py-1.5 font-medium">Symbol</th><th class="font-medium">Kind</th><th class="font-medium">Entry → exit</th>
        <th class="text-right font-medium">Qty</th><th class="text-right font-medium">Avg cost</th><th class="text-right font-medium">Avg exit</th>
        <th class="text-right font-medium">P&amp;L</th><th class="text-right font-medium">%</th><th class="text-right font-medium">R</th>
        <th class="pl-3 font-medium">Setup</th></tr></thead>
      <tbody>
        <tr v-for="r in rows" :key="r.key" class="cursor-pointer border-t border-[#F3F3F3] hover:bg-[#FAFAFA]"
            :class="r.excluded ? 'opacity-50' : ''" @click="$emit('open', r)">
          <td class="py-2 font-semibold">{{ r.symbol }}
            <span v-if="r.flags?.length" class="ml-1 rounded bg-[#FFF1DB] px-1.5 py-0.5 text-[11px] font-medium text-[#9A4A00]" :title="r.flags.join('\n')">check</span>
            <span v-if="r.excluded" class="ml-1 rounded bg-[#F0F0F0] px-1.5 py-0.5 text-[11px] text-[#616161]">left out</span></td>
          <td class="capitalize text-[#616161]">{{ r.kind }}</td>
          <td class="whitespace-nowrap text-[#616161]">{{ short(r.entry_date) }}<span v-if="r.exit_date && r.exit_date !== r.entry_date"> → {{ short(r.exit_date) }}</span>
            <span v-if="r.status === 'open'" class="ml-1 text-xs font-medium text-[#1D4ED8]">open</span></td>
          <td class="text-right tabular-nums">{{ r.qty }}</td>
          <td class="text-right tabular-nums">{{ num(r.avg_cost) }}</td>
          <td class="text-right tabular-nums">{{ num(r.avg_exit) }}</td>
          <td class="text-right font-semibold tabular-nums" :class="tone(r.pnl)">{{ inr(r.pnl, { sign: true, lakh: false }) }}</td>
          <td class="text-right tabular-nums" :class="tone(r.return_pct)">{{ r.return_pct !== null && r.return_pct !== undefined ? pct(r.return_pct, 1, true) : '—' }}</td>
          <td class="text-right tabular-nums" :class="tone(r.r)">{{ r.r !== null && r.r !== undefined ? r.r.toFixed(1) + 'R' : '—' }}</td>
          <td class="pl-3 text-[#616161]">{{ r.setup || '' }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script setup>
import { inr, pct, num, tone } from '@/lib/store'
defineProps({ rows: { type: Array, default: () => [] }, empty: { type: String, default: 'No trades.' } })
defineEmits(['open'])
const M = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const short = (d) => (d ? `${+d.slice(8, 10)} ${M[+d.slice(5, 7) - 1]} ${d.slice(2, 4)}` : '')
</script>
