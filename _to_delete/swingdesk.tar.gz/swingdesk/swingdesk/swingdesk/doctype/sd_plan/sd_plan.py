from frappe.model.document import Document


class SDPlan(Document):
    pass
