from frappe.model.document import Document


class SDAnnotation(Document):
    pass
