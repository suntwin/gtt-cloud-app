from frappe.model.document import Document


class SDTrade(Document):
    pass
