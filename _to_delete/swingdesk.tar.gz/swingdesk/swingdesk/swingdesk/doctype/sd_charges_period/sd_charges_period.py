from frappe.model.document import Document


class SDChargesPeriod(Document):
    pass
