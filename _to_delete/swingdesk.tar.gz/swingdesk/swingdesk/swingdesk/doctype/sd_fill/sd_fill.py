from frappe.model.document import Document


class SDFill(Document):
    pass
