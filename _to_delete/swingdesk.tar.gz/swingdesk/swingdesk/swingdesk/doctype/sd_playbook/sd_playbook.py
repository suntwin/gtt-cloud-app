from frappe.model.document import Document


class SDPlaybook(Document):
    pass
