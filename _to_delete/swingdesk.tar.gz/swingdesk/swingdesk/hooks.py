app_name = "swingdesk"
app_title = "SwingDesk"
app_publisher = "Nitesh Chawla"
app_description = "The trading journal for swing traders"
app_email = "nitesh.chawla@atturra.com"
app_license = "Proprietary"

# The Vue app lives at /swing (built into swingdesk/public/frontend + www/swing.html)
website_route_rules = [{"from_route": "/swing/<path:app_path>", "to_route": "swing"}]

after_install = "swingdesk.install.after_install"
after_migrate = "swingdesk.install.after_install"

# every new sign-up (website user) becomes a SwingDesk user with an empty playbook
doc_events = {"User": {"after_insert": "swingdesk.install.on_user_created"}}

add_to_apps_screen = [{"name": "swingdesk", "logo": "/assets/swingdesk/frontend/icon-192.png", "title": "SwingDesk",
                       "route": "/swing"}]
