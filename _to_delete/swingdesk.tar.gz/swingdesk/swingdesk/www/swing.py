from urllib.parse import quote

import frappe

no_cache = 1


def get_context(context):
    """/swing — the Vue app. Any logged-in user (sign-ups are website users); sends the CSRF token for POSTs."""
    if frappe.session.user == "Guest":
        frappe.local.flags.redirect_location = "/login?redirect-to=" + quote(frappe.request.path if frappe.request else "/swing")
        raise frappe.Redirect
    csrf_token = frappe.sessions.get_csrf_token()
    frappe.db.commit()
    context.no_cache = 1
    context.boot = {"csrf_token": csrf_token, "site_name": frappe.local.site}
    return context
