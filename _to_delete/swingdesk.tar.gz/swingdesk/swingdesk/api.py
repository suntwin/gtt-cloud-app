"""SwingDesk API — /api/method/swingdesk.api.<name>.

PRIVACY RULE: every function starts with me() and every read/write is filtered by that user. Nothing here takes a
user from the caller, and anything addressed by name/key is checked to belong to the caller first. (App users have
no DocType permissions at all, so the generic /api/resource REST is closed to them; this module is their only door.)
"""
import json
from datetime import datetime

import frappe

from swingdesk import engine
from swingdesk.engine.periods import PERIODS, period_range

FILL_FIELDS = ["key", "trade_id", "order_id", "exchange", "symbol", "isin", "side", "qty", "price", "ts", "source",
               "product", "status"]
TRADE_FIELDS = ["key", "symbol", "isin", "kind", "side", "status", "entry_date", "exit_date", "entry_ts", "first_qty",
                "first_price", "qty_bought", "buy_value", "avg_cost", "open_qty", "max_qty", "sold_qty", "sold_value",
                "avg_exit", "pnl", "return_pct", "days", "adds", "split_factor", "auto_exclude", "flags", "exits_json"]
ANN_FIELDS = ["trade_key", "setup", "stop", "stats", "rules_ok", "mistake", "tags", "note"]
PB_FIELDS = ["account_size", "risk_pct", "cap_pct", "max_stop_pct", "stop_rule", "max_stop_adr", "ideal_stop_adr",
             "max_trades_day", "include_intraday", "est_charges_pct", "goal", "stats_period", "stats_from", "stats_to"]
SETUPS = ["Range breakout", "Hourly flag", "Episodic pivot", "Pullback", "Other"]


# ── guard & helpers ──────────────────────────────────────────────────────────
def me():
    user = frappe.session.user
    if not user or user == "Guest":
        frappe.throw("Please log in", frappe.PermissionError)
    return user


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")


def _iso(x):
    return x.isoformat() if hasattr(x, "isoformat") else (str(x) if x is not None else None)


def _parse(x, default=None):
    if x is None or x == "":
        return default
    if isinstance(x, str):
        try:
            return json.loads(x)
        except ValueError:
            return x
    return x


def playbook(user):
    name = frappe.db.get_value("SD Playbook", {"user": user}, "name")
    if not name:
        doc = frappe.get_doc({"doctype": "SD Playbook", "user": user, "risk_pct": 0.25, "cap_pct": 25, "max_stop_pct": 5,
                              "stop_rule": "pct", "max_stop_adr": 0.75, "ideal_stop_adr": 0.5, "max_trades_day": 2,
                              "include_intraday": 1, "est_charges_pct": 0.1, "stats_period": "All", "build_version": 0})
        doc.insert(ignore_permissions=True)
        name = doc.name
    return frappe.get_doc("SD Playbook", name)


def _bulk(doctype, user, rows, fields):
    if not rows:
        return
    now = _now()
    cols = ["name", "owner", "modified_by", "creation", "modified", "user"] + fields
    vals = [[frappe.generate_hash(length=12), user, user, now, now, user] + [r.get(f) for f in fields] for r in rows]
    frappe.db.bulk_insert(doctype, cols, vals)


# ── import & rebuild ─────────────────────────────────────────────────────────
def _fills(user, statuses=("active",)):
    rows = frappe.get_all("SD Fill", filters={"user": user, "status": ["in", list(statuses)]}, fields=FILL_FIELDS,
                          limit_page_length=0, order_by="ts asc")
    for r in rows:
        r["ts"] = str(r["ts"])[:19]
        r["qty"], r["price"] = float(r["qty"]), float(r["price"])
    return rows


def rebuild(user):
    """Replay every fill → trades. Annotations are separate, so nothing the user typed is touched."""
    pb = playbook(user)
    fills = _fills(user)
    res = engine.replay(fills, include_intraday=bool(pb.include_intraday))
    frappe.db.delete("SD Trade", {"user": user})
    rows = []
    for t in res["trades"]:
        r = {f: t.get(f) for f in TRADE_FIELDS if f not in ("flags", "exits_json", "auto_exclude")}
        r.update(flags="\n".join(t["flags"]), auto_exclude=1 if t.get("auto_exclude") else 0,
                 exits_json=json.dumps(t["exits"]), split_factor=t.get("split_factor", 1))
        rows.append(r)
    _bulk("SD Trade", user, rows, TRADE_FIELDS)
    if res["dropped"]:
        frappe.db.sql("update `tabSD Fill` set status='duplicate' where user=%s and `key` in %s", (user, tuple(res["dropped"])))
    days = sorted(str(f["ts"])[:10] for f in fills)
    summary = {"built": _now()[:19], "fills": len(fills), "trades": len(res["trades"]),
               "closed": sum(1 for t in res["trades"] if t["status"] == "closed"),
               "open": sum(1 for t in res["trades"] if t["status"] == "open"),
               "from": days[0] if days else None, "to": days[-1] if days else None,
               "splits": {k: [[d, f] for d, f in v] for k, v in res["splits"].items()},
               "unmatched": res["unmatched"][:300], "n_unmatched": len(res["unmatched"]), "duplicates": len(res["dropped"])}
    frappe.db.set_value("SD Playbook", pb.name, {"build_json": json.dumps(summary), "build_version": (pb.build_version or 0) + 1},
                        update_modified=False)
    frappe.db.commit()
    return summary


def _job_key(user):
    return f"sd:job:{user}"


def run_import(user, csv_text):
    """Background job: parse, store new fills, rebuild."""
    k = _job_key(user)
    frappe.cache().set_value(k, {"state": "running", "step": "reading the file"}, expires_in_sec=86400)
    try:
        fills, info = engine.parse_zerodha_tradebook(csv_text)
        frappe.cache().set_value(k, {"state": "running", "step": f"checking {len(fills):,} trades"}, expires_in_sec=86400)
        existing = frappe.get_all("SD Fill", filters={"user": user, "ts": ["between", [info["from"] + " 00:00:00", info["to"] + " 23:59:59"]]},
                                  fields=["key", "symbol", "side", "qty", "price", "ts", "source"], limit_page_length=0)
        for e in existing:
            e["ts"] = str(e["ts"])[:19]
        new = engine.new_fills(fills, existing)
        for f in new:
            f["status"] = "active"
        _bulk("SD Fill", user, new, FILL_FIELDS)
        frappe.db.commit()
        frappe.cache().set_value(k, {"state": "running", "step": "rebuilding your trades"}, expires_in_sec=86400)
        s = rebuild(user)
        msg = f"Imported {info['from']} → {info['to']}: {info['fills']:,} trades in the file, {len(new):,} new."
        frappe.cache().set_value(k, {"state": "done", "message": msg, "summary": s, "new": len(new), "first": not existing and s["fills"] == len(new)},
                                 expires_in_sec=86400)
    except engine.FormatError as e:
        frappe.cache().set_value(k, {"state": "error", "message": str(e)}, expires_in_sec=86400)
    except Exception as e:
        frappe.log_error(title="SwingDesk import")
        frappe.cache().set_value(k, {"state": "error", "message": f"Import failed: {e}"}, expires_in_sec=86400)


@frappe.whitelist(methods=["POST"])
def import_tradebook(csv_text=""):
    user = me()
    if len(csv_text or "") > 30_000_000:
        frappe.throw("File too large (30 MB max) — split it into yearly files.")
    try:
        engine.parse_zerodha_tradebook((csv_text or "")[:200_000].rsplit("\n", 1)[0] + "\n")   # quick format check
    except engine.FormatError as e:
        frappe.throw(str(e))
    j = frappe.cache().get_value(_job_key(user)) or {}
    if j.get("state") in ("queued", "running"):
        frappe.throw("An import is already running — wait for it to finish.")
    frappe.cache().set_value(_job_key(user), {"state": "queued"}, expires_in_sec=86400)
    frappe.enqueue("swingdesk.api.run_import", queue="long", timeout=1800, user=user, csv_text=csv_text)
    return {"ok": True}


@frappe.whitelist()
def job_status():
    return frappe.cache().get_value(_job_key(me())) or {"state": "idle"}


# ── reading ──────────────────────────────────────────────────────────────────
def _trades(user):
    rows = frappe.get_all("SD Trade", filters={"user": user}, fields=TRADE_FIELDS, limit_page_length=0)
    for r in rows:
        r["entry_date"], r["exit_date"] = _iso(r["entry_date"]), _iso(r["exit_date"])
        r["entry_ts"] = str(r["entry_ts"])[:19] if r["entry_ts"] else None
        r["flags"] = [x for x in (r["flags"] or "").split("\n") if x]
        r["exits"] = json.loads(r.pop("exits_json") or "[]")
        for f in ("pnl", "first_price", "first_qty", "open_qty", "avg_cost", "sold_qty", "sold_value"):
            r[f] = float(r[f] or 0)
    return rows


def _annotations(user):
    return {a["trade_key"]: a for a in frappe.get_all("SD Annotation", filters={"user": user}, fields=ANN_FIELDS,
                                                       limit_page_length=0)}


def _charges(user):
    rows = frappe.get_all("SD Charges Period", filters={"user": user}, fields=["name", "from_date", "to_date", "amount", "note"],
                          order_by="from_date asc", limit_page_length=0)
    return [{"name": r["name"], "from": _iso(r["from_date"]), "to": _iso(r["to_date"]), "amount": float(r["amount"]),
             "note": r["note"] or ""} for r in rows]


def _turnover(user):
    rows = frappe.db.sql("""select date(ts) d, sum(qty*price) v from `tabSD Fill`
                            where user=%s and status='active' group by date(ts)""", (user,), as_dict=True)
    return {_iso(r["d"]): float(r["v"]) for r in rows}


def _period(pb, period, date_from, date_to):
    if period in (None, ""):
        period, date_from, date_to = pb.stats_period or "All", _iso(pb.stats_from), _iso(pb.stats_to)
    if period not in PERIODS:
        frappe.throw(f"Unknown period {period}")
    s, e, label = period_range(period, date_from, date_to)
    return period, date_from, date_to, s, e, label


@frappe.whitelist()
def boot():
    user = me()
    pb = playbook(user)
    return {"user": user, "full_name": frappe.db.get_value("User", user, "full_name"),
            "playbook": {f: pb.get(f) for f in PB_FIELDS}, "periods": PERIODS, "setups": SETUPS,
            "build": json.loads(pb.build_json or "null"),
            "has_trades": bool(frappe.db.exists("SD Trade", {"user": user}))}


@frappe.whitelist()
def dashboard(period=None, date_from=None, date_to=None):
    user = me()
    pb = playbook(user)
    period, date_from, date_to, s, e, label = _period(pb, period, date_from, date_to)
    trades = _trades(user)
    ann = _annotations(user)
    excluded = [k for k, a in ann.items() if a["stats"] == "exclude"]
    included = [k for k, a in ann.items() if a["stats"] == "include"]
    stops = {k: float(a["stop"]) for k, a in ann.items() if a["stop"]}
    charges = engine.daily_charges(_charges(user), _turnover(user), float(pb.est_charges_pct or 0))
    sm = engine.summarize(trades, s, e, charges, excluded, included, stops)
    acct = float(pb.account_size or 0)
    open_ = []
    for t in sorted((t for t in trades if t["status"] == "open"), key=lambda t: t["entry_date"]):
        stop = stops.get(t["key"])
        risk = (t["avg_cost"] - stop) * t["open_qty"] if stop else None
        open_.append({"key": t["key"], "symbol": t["symbol"], "entry_date": t["entry_date"], "open_qty": t["open_qty"],
                      "avg_cost": t["avg_cost"], "cost": t["avg_cost"] * t["open_qty"], "stop": stop,
                      "risk": risk, "risk_pct": (risk / acct * 100) if risk is not None and acct else None,
                      "booked": t["pnl"], "flags": t["flags"]})
    closed = [t for t in trades if t["status"] == "closed" and (s is None or t["exit_date"] >= s) and (e is None or t["exit_date"] <= e)]
    closed.sort(key=lambda t: (t["exit_date"], t["key"]), reverse=True)
    recent = [_row(t, ann.get(t["key"])) for t in closed[:8]]
    review = [_row(t, ann.get(t["key"])) for t in closed if t["flags"] and (ann.get(t["key"]) or {}).get("stats") != "include"]
    return {"period": {"per": period, "from": date_from, "to": date_to, "label": label},
            "summary": sm, "open": open_, "open_risk": sum(o["risk"] or 0 for o in open_),
            "open_risk_pct": (sum(o["risk"] or 0 for o in open_) / acct * 100) if acct else None,
            "no_stop": [o["symbol"] for o in open_ if o["stop"] is None],
            "recent": recent, "review": review[:50], "n_review": len(review),
            "build": json.loads(pb.build_json or "null"), "lesson": _lesson(sm)}


def _row(t, a):
    a = a or {}
    stop = float(a["stop"]) if a.get("stop") else None
    excluded = a.get("stats") == "exclude" or (t.get("auto_exclude") and a.get("stats") != "include")
    return {"key": t["key"], "symbol": t["symbol"], "kind": t["kind"], "side": t["side"], "status": t["status"],
            "entry_date": t["entry_date"], "exit_date": t["exit_date"], "days": t["days"],
            "qty": t["sold_qty"] if t["status"] == "closed" else t["open_qty"], "avg_cost": t["avg_cost"],
            "avg_exit": t.get("avg_exit"), "pnl": t["pnl"], "return_pct": t.get("return_pct"),
            "r": engine.r_multiple(t, stop), "exits": len(t["exits"]), "adds": t["adds"],
            "setup": a.get("setup") or "", "stop": stop, "rules_ok": a.get("rules_ok") or "", "note": a.get("note") or "",
            "excluded": bool(excluded), "stats": a.get("stats") or "", "auto_exclude": bool(t.get("auto_exclude")),
            "flags": t["flags"]}


def _lesson(s):
    i, w = s["by_kind"]["intraday"], s["by_kind"]["swing"]
    if i["n"] >= 5 and i["pnl"] < 0 and w["pnl"] > 0:
        return f"Intraday cost ₹{abs(i['pnl']):,.0f} in this period while swing made ₹{w['pnl']:,.0f}."
    if s["charges"] and s["net_realised"] > 0 and s["charges"] > 0.5 * s["net_realised"]:
        return f"Charges took {s['charges'] / s['net_realised'] * 100:.0f}% of what you made — fewer, bigger trades keep more."
    if s["win_rate"] is not None and s["breakeven_win_rate"] is not None:
        gap = (s["win_rate"] - s["breakeven_win_rate"]) * 100
        return (f"You win {s['win_rate'] * 100:.0f}% and need {s['breakeven_win_rate'] * 100:.0f}% to break even — "
                + ("keep losses small and let winners run." if gap >= 0 else "cut losers faster or let winners run longer."))
    return None


@frappe.whitelist()
def trades(period=None, date_from=None, date_to=None, kind=None, status=None, setup=None, only_check=0, q=None):
    user = me()
    pb = playbook(user)
    period, date_from, date_to, s, e, label = _period(pb, period, date_from, date_to)
    ann = _annotations(user)
    out = []
    for t in _trades(user):
        day = t["exit_date"] or datetime.now().date().isoformat()
        if (s and day < s) or (e and day > e):
            continue
        if kind and t["kind"] != kind or status and t["status"] != status or q and q.upper() not in t["symbol"]:
            continue
        r = _row(t, ann.get(t["key"]))
        if setup and r["setup"] != setup or int(only_check or 0) and not r["flags"]:
            continue
        out.append(r)
    out.sort(key=lambda r: (r["exit_date"] or "9999", r["key"]), reverse=True)
    return {"period": {"per": period, "label": label}, "rows": out[:3000], "n": len(out)}


@frappe.whitelist()
def trade(key):
    user = me()
    t = next((t for t in _trades(user) if t["key"] == key), None)
    if not t:
        frappe.throw("Trade not found", frappe.DoesNotExistError)
    return {**_row(t, _annotations(user).get(key)), "exits_detail": t["exits"], "first_price": t["first_price"],
            "first_qty": t["first_qty"], "entry_ts": t["entry_ts"]}


# ── writing ──────────────────────────────────────────────────────────────────
@frappe.whitelist(methods=["POST"])
def annotate(trade_key, fields=None):
    """Setup / initial stop / Exclude / rules / note on one of YOUR trades. Kept through every rebuild."""
    user = me()
    if not frappe.db.exists("SD Trade", {"user": user, "key": trade_key}):
        frappe.throw("Trade not found", frappe.DoesNotExistError)
    f = {k: v for k, v in (_parse(fields, {}) or {}).items() if k in ANN_FIELDS and k != "trade_key"}
    if "stats" in f and f["stats"] not in ("", "exclude", "include", None):
        frappe.throw("stats must be exclude / include")
    if "stop" in f:
        f["stop"] = float(f["stop"]) if f["stop"] not in (None, "") else None
    name = frappe.db.get_value("SD Annotation", {"user": user, "trade_key": trade_key}, "name")
    if name:
        frappe.db.set_value("SD Annotation", name, f)
    else:
        frappe.get_doc({"doctype": "SD Annotation", "user": user, "trade_key": trade_key, **f}).insert(ignore_permissions=True)
    return {"ok": True}


@frappe.whitelist(methods=["POST"])
def save_playbook(fields=None):
    user = me()
    f = {k: v for k, v in (_parse(fields, {}) or {}).items() if k in PB_FIELDS}
    if "stats_period" in f and f["stats_period"] not in PERIODS:
        frappe.throw("Unknown period")
    if f.get("stats_to") and str(f["stats_to"]) >= datetime.now().date().isoformat():
        f["stats_to"] = None                                     # "to today" keeps rolling
    pb = playbook(user)
    old_intraday = bool(pb.include_intraday)
    frappe.db.set_value("SD Playbook", pb.name, f)
    if "include_intraday" in f and bool(int(f["include_intraday"] or 0)) != old_intraday:
        rebuild(user)
    return {"ok": True, "playbook": {k: frappe.db.get_value("SD Playbook", pb.name, k) for k in PB_FIELDS}}


@frappe.whitelist()
def charges():
    return {"rows": _charges(me())}


@frappe.whitelist(methods=["POST"])
def save_charges(rows=None):
    user = me()
    rows = sorted(_parse(rows, []) or [], key=lambda r: str(r.get("from")))
    for r in rows:
        if not (r.get("from") and r.get("to") and r.get("amount") not in (None, "")):
            frappe.throw("Each row needs From, To and Amount.")
        if str(r["to"]) < str(r["from"]):
            frappe.throw(f"To is before From ({r['from']} → {r['to']}).")
    for a, b in zip(rows, rows[1:]):
        if str(b["from"]) < str(a["to"]):
            frappe.throw(f"Charge periods overlap: {a['from']}–{a['to']} and {b['from']}–{b['to']}.")
    frappe.db.delete("SD Charges Period", {"user": user})
    for r in rows:
        frappe.get_doc({"doctype": "SD Charges Period", "user": user, "from_date": r["from"], "to_date": r["to"],
                        "amount": float(r["amount"]), "note": r.get("note") or ""}).insert(ignore_permissions=True)
    return {"ok": True, "total": sum(float(r["amount"]) for r in rows)}


# ── plans ────────────────────────────────────────────────────────────────────
def _size(pb, entry, stop, adr_pct):
    acct = float(pb.account_size or 0)
    if not acct:
        frappe.throw("Set your account size in the Playbook first.")
    adr = float(adr_pct) if adr_pct not in (None, "", 0, "0") else None
    return engine.plan(entry, stop, acct, float(pb.risk_pct or 0.25), float(pb.cap_pct or 25), adr,
                       float(pb.max_stop_pct or 5), float(pb.max_stop_adr or 0.75), float(pb.ideal_stop_adr or 0.5))


@frappe.whitelist()
def plan_calc(symbol="", entry=None, stop=None, adr_pct=None):
    user = me()
    try:
        entry, stop = float(entry), float(stop)
    except (TypeError, ValueError):
        return {"ok": False, "message": "Enter entry and stop."}
    return _size(playbook(user), entry, stop, adr_pct)


@frappe.whitelist(methods=["POST"])
def save_plan(symbol="", entry=None, stop=None, adr_pct=None, setup="", orh=0, note=""):
    user = me()
    sym = engine.fills.clean_symbol(str(symbol).split(":")[-1])
    if not sym:
        frappe.throw("Symbol needed.")
    p = _size(playbook(user), float(entry), float(stop), adr_pct)
    if not p["ok"]:
        frappe.throw(p["message"])
    doc = frappe.get_doc({"doctype": "SD Plan", "user": user, "plan_date": datetime.now().date().isoformat(), "symbol": sym,
                          "entry": float(entry), "stop": float(stop), "adr_pct": float(adr_pct) if adr_pct else None,
                          "setup": setup or "", "orh": 1 if int(orh or 0) else 0, "shares": p["shares"],
                          "risk_rs": p["risk_rs"], "position_rs": p["position_rs"], "verdict": p["verdict"],
                          "status": "planned", "note": note or ""}).insert(ignore_permissions=True)
    return {"ok": True, "name": doc.name, "plan": p}


@frappe.whitelist()
def plans(status="planned"):
    user = me()
    rows = frappe.get_all("SD Plan", filters={"user": user, **({"status": status} if status else {})},
                          fields=["name", "plan_date", "symbol", "entry", "stop", "adr_pct", "setup", "orh", "shares",
                                  "risk_rs", "position_rs", "verdict", "status", "note"], order_by="creation desc",
                          limit_page_length=200)
    for r in rows:
        r["plan_date"] = _iso(r["plan_date"])
    return {"rows": rows}


@frappe.whitelist(methods=["POST"])
def set_plan_status(name, status):
    user = me()
    if status not in ("planned", "triggered", "skipped", "done", "deleted"):
        frappe.throw("Unknown status")
    if frappe.db.get_value("SD Plan", name, "user") != user:
        frappe.throw("Plan not found", frappe.DoesNotExistError)
    if status == "deleted":
        frappe.delete_doc("SD Plan", name, ignore_permissions=True)
    else:
        frappe.db.set_value("SD Plan", name, "status", status)
    return {"ok": True}


# ── your data ────────────────────────────────────────────────────────────────
@frappe.whitelist(methods=["POST"])
def dismiss_unmatched(symbol, date):
    """Leave a pre-history sale out for good (its fills are kept but not replayed)."""
    user = me()
    frappe.db.sql("""update `tabSD Fill` set status='dismissed' where user=%s and symbol=%s and side='SELL'
                     and date(ts)=%s and status='active'""", (user, symbol, date))
    return rebuild(user)


@frappe.whitelist()
def export_my_data():
    user = me()
    return {"exported": _now()[:19], "fills": _fills(user, ("active", "dismissed", "duplicate")),
            "annotations": list(_annotations(user).values()), "charges": _charges(user), "plans": plans(None)["rows"]}


@frappe.whitelist(methods=["POST"])
def delete_my_data(confirm=""):
    user = me()
    if confirm != "DELETE":
        frappe.throw("Type DELETE to confirm.")
    for dt in ("SD Fill", "SD Trade", "SD Annotation", "SD Plan", "SD Charges Period", "SD Playbook"):
        frappe.db.delete(dt, {"user": user})
    frappe.db.commit()
    return {"ok": True}
