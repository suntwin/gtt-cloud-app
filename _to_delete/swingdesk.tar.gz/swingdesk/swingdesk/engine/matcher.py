"""Fills → trades. Pure Python, deterministic: the same fills always give the same trades and keys.

A TRADE is one position from the first buy until it is flat again, with every scale-out as an exit and every
later buy as an add (average cost). Per stock per day, buys and sells that cancel out are an INTRADAY trade at the
day's average buy and sell (how Zerodha nets a day); what is left over is a delivery buy (open / add) or a delivery
sell (reduce / close). That handles "bought 100, sold 40 the same day, carried 60" and MIS→CNC conversions alike.

Splits and bonus issues are not in the tradebook: find_splits() infers them (see there) and open positions are
adjusted (qty × k, price ÷ k) on the day the new price first appears.
"""
from collections import defaultdict
from datetime import date

from .fills import canonical_symbols, dedupe

SPLIT_FACTORS = (1.5, 2, 3, 4, 5, 10)


def _d(ts):
    return date.fromisoformat(str(ts)[:10])


def _day_groups(fills):
    """{(day, symbol): [fills sorted by time]}"""
    g = defaultdict(list)
    for f in fills:
        g[(str(f["ts"])[:10], f["symbol"])].append(f)
    for v in g.values():
        v.sort(key=lambda f: (str(f["ts"]), str(f.get("key"))))
    return g


def find_splits(groups):
    """Evidence for a split/bonus: a sale of more shares than the history holds, after a price gap that is a clean ratio
    (×1.5 = 1:2 bonus, ×2 = 1:1 bonus or 1:2 split, ×3, ×4, ×5, ×10), where the shares held then × (ratio − 1) cover
    the shortfall. Returns {symbol: [(day, factor)]}."""
    per = defaultdict(list)
    for (day, sym), fs in groups.items():
        B = sum(f["qty"] for f in fs if f["side"] == "BUY")
        S = sum(f["qty"] for f in fs if f["side"] == "SELL")
        per[sym].append((day, B, S, fs[0]["price"], fs[-1]["price"]))
    out = {}
    for sym, info in per.items():
        info.sort()
        found = []
        for _ in range(4):
            H, seen_buy, before, short = 0.0, False, [], None
            f = dict(found)
            for i, (day, B, S, p0, p1) in enumerate(info):
                if day in f:
                    H *= f[day]
                before.append(H)
                H += B - S
                seen_buy = seen_buy or B > 0
                if H < -1e-6:
                    if not seen_buy:
                        H = 0.0                                  # held before the history started
                    else:
                        short = (i, -H)
                        break
            if not short:
                break
            i, deficit = short
            hit = None
            for j in range(i, 0, -1):
                r = info[j - 1][4] / info[j][3] if info[j][3] else 0
                k = next((k for k in SPLIT_FACTORS if abs(r / k - 1) < 0.04), None)
                if k and before[j] > 0 and before[j] * (k - 1) >= deficit * 0.98 and info[j][0] not in f:
                    hit = (info[j][0], k)
                    break
            if not hit:
                break
            found.append(hit)
        if found:
            out[sym] = sorted(found)
    return out


def _vwap(fs):
    q = sum(f["qty"] for f in fs)
    return q, (sum(f["qty"] * f["price"] for f in fs) / q if q else 0.0)


def _new_trade(sym, day, kind, isin=None):
    return {"key": None, "symbol": sym, "isin": isin, "kind": kind, "side": "long", "status": "open",
            "entry_date": day, "exit_date": None, "entry_ts": None,
            "qty_bought": 0.0, "buy_value": 0.0, "first_qty": 0.0, "first_price": 0.0,
            "open_qty": 0.0, "avg_cost": 0.0, "max_qty": 0.0,
            "exits": [], "adds": 0, "pnl": 0.0, "sold_value": 0.0, "sold_qty": 0.0, "flags": [], "fill_keys": []}


def _flag(t, why):
    if why not in t["flags"]:
        t["flags"].append(why)


def replay(fills, include_intraday=True, since=None):
    """→ {"trades": [...], "unmatched": [...], "splits": {...}, "dropped": [fill keys], "fill_trade": {fill key: trade key}}"""
    fills = [dict(f) for f in fills]
    fills, dropped = dedupe(fills)
    canonical_symbols(fills)
    if since:
        fills = [f for f in fills if str(f["ts"])[:10] >= str(since)]
    groups = _day_groups(fills)
    splits = find_splits(groups)
    pending = {s: list(v) for s, v in splits.items()}
    trades, unmatched, open_ = [], [], {}
    fill_trade = {}

    for day, sym in sorted(groups):
        fs = groups[(day, sym)]
        while pending.get(sym) and pending[sym][0][0] <= day:          # split / bonus before today's trades
            sday, k = pending[sym].pop(0)
            t = open_.get(sym)
            if t:
                t["open_qty"] *= k
                t["avg_cost"] /= k
                t["max_qty"] *= k
                t["split_factor"] = t.get("split_factor", 1) * k
                _flag(t, f"split/bonus ×{k:g} on {sday} (adjusted)")
        buys = [f for f in fs if f["side"] == "BUY"]
        sells = [f for f in fs if f["side"] == "SELL"]
        B, pb = _vwap(buys)
        S, ps = _vwap(sells)
        Q = min(B, S)
        isin = next((f.get("isin") for f in fs if f.get("isin")), None)
        keys = [f["key"] for f in fs]

        if Q > 1e-9 and include_intraday:                                   # the part that cancels out today
            it = _new_trade(sym, day, "intraday", isin)
            sold_first = fs[0]["side"] == "SELL" and sym not in open_
            it.update(side="short" if sold_first else "long", status="closed", exit_date=day,
                      entry_ts=fs[0]["ts"], qty_bought=Q, buy_value=Q * pb, first_qty=Q, first_price=pb, max_qty=Q,
                      avg_cost=pb, sold_qty=Q, sold_value=Q * ps, pnl=Q * (ps - pb),
                      exits=[{"date": day, "qty": Q, "price": round(ps, 4), "pnl": Q * (ps - pb)}])
            trades.append(it)
            for k_ in keys:
                fill_trade.setdefault(k_, it)

        if B - Q > 1e-9:                                                    # delivery buy: open or add
            q = B - Q
            t = open_.get(sym)
            if t is None:
                t = _new_trade(sym, day, "swing", isin)
                t.update(entry_ts=buys[0]["ts"], first_qty=q, first_price=pb)
                open_[sym] = t
                trades.append(t)
            else:
                t["adds"] += 1
            t["avg_cost"] = (t["avg_cost"] * t["open_qty"] + pb * q) / (t["open_qty"] + q)
            t["open_qty"] += q
            t["qty_bought"] += q
            t["buy_value"] += q * pb
            t["max_qty"] = max(t["max_qty"], t["open_qty"])
            for k_ in keys:
                fill_trade[k_] = t

        elif S - Q > 1e-9:                                                  # delivery sell: reduce / close
            q = S - Q
            t = open_.get(sym)
            if t is None:
                unmatched.append({"symbol": sym, "date": day, "qty": q, "price": round(ps, 4),
                                  "why": "sold with nothing open — bought before the imported history?",
                                  "fill_keys": [f["key"] for f in sells]})
                continue
            take = min(q, t["open_qty"])
            pnl = take * (ps - t["avg_cost"])
            t["exits"].append({"date": day, "qty": take, "price": round(ps, 4), "pnl": pnl})
            t["pnl"] += pnl
            t["sold_qty"] += take
            t["sold_value"] += take * ps
            t["open_qty"] -= take
            for k_ in keys:
                fill_trade[k_] = t
            if t["open_qty"] <= 1e-9:
                t["open_qty"] = 0.0
                t["status"] = "closed"
                t["exit_date"] = day
                del open_[sym]
            if q - take > 1e-9:                                             # cost of these shares is unknown
                _flag(t, f"sold {q - take:g} more than the history holds — check")
                unmatched.append({"symbol": sym, "date": day, "qty": q - take, "price": round(ps, 4),
                                  "why": "sold more than the history holds", "fill_keys": [f["key"] for f in sells]})

    # stable keys: symbol | entry day | kind | n-th such trade
    seq = defaultdict(int)
    for t in trades:
        base = f"{t['symbol']}|{t['entry_date']}|{'I' if t['kind'] == 'intraday' else 'S'}"
        t["key"] = f"{base}|{seq[base]}"
        seq[base] += 1
    for t in trades:
        finish(t)
    return {"trades": trades, "unmatched": unmatched, "splits": splits, "dropped": sorted(dropped),
            "fill_trade": {k: t["key"] for k, t in fill_trade.items()}}


def finish(t):
    """Derived numbers on a trade (no market data needed)."""
    t["avg_exit"] = (t["sold_value"] / t["sold_qty"]) if t["sold_qty"] else None
    cost_sold = t["sold_value"] - t["pnl"]
    t["return_pct"] = (t["pnl"] / cost_sold * 100) if cost_sold else None
    end = _d(t["exit_date"]) if t.get("exit_date") else None
    t["days"] = ((end - _d(t["entry_date"])).days if end else None)
    if t["kind"] == "intraday":
        t["days"] = 0
    if "more than the history holds" in " ".join(t["flags"]):
        t["auto_exclude"] = True
    if t["status"] == "closed" and t["return_pct"] is not None:
        lim = 15 if t["kind"] == "intraday" else 40
        if abs(t["return_pct"]) >= lim:
            _flag(t, f"big move {t['return_pct']:+.0f}% — check")
    return t


def r_multiple(t, stop):
    """R = P&L ÷ the risk taken on the first entry (first-day qty × (first price − initial stop)). Adds don't change
    the denominator — adding to a winner shows up as more R, which is the point."""
    if stop is None or t["kind"] == "intraday":
        return None
    risk = (t["first_price"] - stop) * t["first_qty"]      # entry and stop as planned (before any later split)
    if risk <= 0:
        return None
    return t["pnl"] / risk
