"""SwingDesk engine: fills → trades → stats. Pure Python, no Frappe — so it is fast to test and safe to reuse."""
from .fills import FormatError, parse_zerodha_tradebook, from_kite_trade, new_fills, dedupe, canonical_symbols  # noqa: F401
from .matcher import replay, find_splits, r_multiple  # noqa: F401
from .stats import daily_turnover, daily_charges, summarize, plan  # noqa: F401
