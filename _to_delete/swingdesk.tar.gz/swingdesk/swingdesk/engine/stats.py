"""Charges allocation, period stats and the pre-trade planner. Pure Python."""
from collections import defaultdict
from datetime import date, timedelta

from .matcher import r_multiple


# ── charges ───────────────────────────────────────────────────────────────────
def daily_turnover(fills):
    """₹ bought + sold per day."""
    out = defaultdict(float)
    for f in fills:
        out[str(f["ts"])[:10]] += float(f["qty"]) * float(f["price"])
    return dict(out)


def daily_charges(rows, turnover, est_pct=0.0):
    """Recorded charge spans [{from, to, amount}] spread over their days by turnover (a span with no trades stored:
    by calendar day); traded days with no span: est_pct % of turnover. A boundary day shared by two spans counts once.
    → {day: (amount, estimated: bool)}"""
    out, covered = {}, set()
    days = sorted(turnover)
    for r in sorted(rows or [], key=lambda r: str(r["from"])):
        a, b, amt = str(r["from"])[:10], str(r["to"])[:10], float(r["amount"])
        blk = [d for d in days if a <= d <= b and d not in covered]
        covered |= set(blk)
        tot = sum(turnover[d] for d in blk)
        if tot > 0:
            for d in blk:
                out[d] = (out.get(d, (0.0, False))[0] + amt * turnover[d] / tot, False)
        else:
            d0, d1 = date.fromisoformat(a), date.fromisoformat(b)
            n = (d1 - d0).days + 1
            for i in range(n):
                d = (d0 + timedelta(days=i)).isoformat()
                if d not in covered:
                    out[d] = (out.get(d, (0.0, False))[0] + amt / n, False)
            covered |= {(d0 + timedelta(days=i)).isoformat() for i in range(n)}
    for d in days:
        if d not in covered and est_pct:
            out[d] = (turnover[d] * est_pct / 100, True)
    return out


# ── period ───────────────────────────────────────────────────────────────────
def _in(day, start, end):
    return (start is None or day >= start) and (end is None or day <= end)


def summarize(trades, start=None, end=None, charges=None, excluded=(), included=(), stops=None, today=None):
    """Stats for trades CLOSED in [start, end] (ISO dates, inclusive; None = open-ended), leaving out `excluded` keys
    and auto-excluded ones (unless their key is in `included`). charges = daily_charges() output.
    stops = {trade key: initial stop} for R."""
    today = today or date.today().isoformat()
    stops = stops or {}
    inc = set(included)
    ex = set(excluded) | {t["key"] for t in trades if t.get("auto_exclude") and t["key"] not in inc}
    closed = [t for t in trades if t["status"] == "closed" and _in(t["exit_date"], start, end)]
    use = [t for t in closed if t["key"] not in ex]
    left_out = len(closed) - len(use)
    n = len(use)
    wins = [t for t in use if t["pnl"] > 0]
    losses = [t for t in use if t["pnl"] <= 0]
    gp, gl = sum(t["pnl"] for t in wins), sum(t["pnl"] for t in losses)
    avg_w = gp / len(wins) if wins else 0.0
    avg_l = gl / len(losses) if losses else 0.0
    payoff = (avg_w / abs(avg_l)) if avg_l else None
    net = gp + gl
    ch = [v for d, v in (charges or {}).items() if _in(d, start, end or today)]
    ch_rec = sum(a for a, est in ch if not est)
    ch_est = sum(a for a, est in ch if est)
    kinds = {}
    for k in ("swing", "intraday"):
        ts = [t for t in use if t["kind"] == k]
        kinds[k] = {"n": len(ts), "pnl": sum(t["pnl"] for t in ts),
                    "win_rate": (sum(1 for t in ts if t["pnl"] > 0) / len(ts)) if ts else None}
    # equity curve by exit day, after charges
    by_day = defaultdict(float)
    for t in use:
        by_day[t["exit_date"]] += t["pnl"]
    for d, (a, _) in (charges or {}).items():
        if _in(d, start, end or today):
            by_day[d] -= a
    curve, cum, peak, dd = [], 0.0, 0.0, 0.0
    for d in sorted(by_day):
        cum += by_day[d]
        peak = max(peak, cum)
        dd = min(dd, cum - peak)
        curve.append((d, round(cum, 2)))
    # R
    rs = [(t, r_multiple(t, stops.get(t["key"]))) for t in use if t["kind"] == "swing"]
    rs = [(t, r) for t, r in rs if r is not None]
    swing = [t for t in use if t["kind"] == "swing"]
    return {
        "n": n, "won": len(wins), "lost": len(losses), "left_out": left_out,
        "win_rate": len(wins) / n if n else None,
        "breakeven_win_rate": (1 / (1 + payoff)) if payoff else None,
        "avg_win": avg_w, "avg_loss": avg_l, "payoff": payoff,
        "profit_factor": (gp / abs(gl)) if gl else None,
        "expectancy": net / n if n else None,
        "gross_profit": gp, "gross_loss": gl, "net_realised": net,
        "charges": ch_rec + ch_est, "charges_recorded": ch_rec, "charges_estimated": ch_est,
        "net_after_charges": net - ch_rec - ch_est,
        "max_drawdown": dd, "curve": curve, "by_kind": kinds,
        "avg_days_swing": (sum(t["days"] for t in swing) / len(swing)) if swing else None,
        "largest_win": max((t["pnl"] for t in use), default=None),
        "largest_loss": min((t["pnl"] for t in use), default=None),
        "r": {"n": len(rs), "avg": (sum(r for _, r in rs) / len(rs)) if rs else None,
              "avg_win": _avg([r for _, r in rs if r > 0]), "avg_loss": _avg([r for _, r in rs if r <= 0]),
              "buckets": _r_buckets([r for _, r in rs])},
    }


def _avg(xs):
    return sum(xs) / len(xs) if xs else None


def _r_buckets(rs):
    edges = [(-99, -1, "≤ −1R"), (-1, 0, "−1R to 0"), (0, 1, "0 to 1R"), (1, 2, "1–2R"), (2, 3, "2–3R"), (3, 99, "≥ 3R")]
    return [{"label": lab, "n": sum(1 for r in rs if lo < r <= hi or (lo == -99 and r <= hi))} for lo, hi, lab in edges]


# ── planner ──────────────────────────────────────────────────────────────────
def plan(entry, stop, account, risk_pct, cap_pct=25.0, adr_pct=None, max_stop_pct=5.0, max_stop_adr=0.75,
         ideal_stop_adr=0.5):
    """Size a long trade from entry + stop + the playbook. Everything is driven by ₹ risk."""
    entry, stop = float(entry), float(stop)
    per = entry - stop
    if entry <= 0 or per <= 0:
        return {"ok": False, "message": "Stop must be below entry."}
    risk_rs = float(account) * float(risk_pct) / 100
    shares = int(risk_rs // per)
    capped = False
    cap = float(account) * float(cap_pct) / 100
    if shares * entry > cap:
        shares, capped = int(cap // entry), True
    stop_pct = per / entry * 100
    stop_adr = (stop_pct / adr_pct) if adr_pct else None
    if stop_adr is not None:
        verdict = "tight" if stop_adr <= ideal_stop_adr and stop_pct <= max_stop_pct else \
            "ok" if stop_adr <= max_stop_adr and stop_pct <= max_stop_pct else "wide"
    else:
        verdict = "ok" if stop_pct <= max_stop_pct else "wide"
    plain = None
    if stop_adr is not None:
        frac = stop_adr
        plain = ("about ¼ of a normal day's move" if frac <= 0.3 else "about ⅓ of a normal day's move" if frac <= 0.4
                 else "about ½ a normal day's move" if frac <= 0.6 else "about ¾ of a normal day's move" if frac <= 0.85
                 else "about a full day's move" if frac <= 1.15 else f"{frac:.1f} normal days' moves")
    return {"ok": True, "shares": shares, "risk_rs": round(shares * per, 2), "risk_budget": round(risk_rs, 2),
            "position_rs": round(shares * entry, 2), "position_pct": round(shares * entry / float(account) * 100, 2) if account else None,
            "capped": capped, "stop_pct": round(stop_pct, 3), "stop_adr": round(stop_adr, 3) if stop_adr is not None else None,
            "verdict": verdict, "plain": plain,
            "t2": round(entry + 2 * per, 2), "t3": round(entry + 3 * per, 2)}
