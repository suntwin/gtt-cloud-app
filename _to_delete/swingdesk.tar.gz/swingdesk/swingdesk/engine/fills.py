"""Fills: one execution each, from a broker tradebook CSV or a broker API. Pure Python, no Frappe.

A fill is a dict:
    {"key", "trade_id", "order_id", "exchange", "symbol", "isin", "side" ("BUY"|"SELL"), "qty", "price",
     "ts" ("YYYY-MM-DD HH:MM:SS", exchange time), "source" ("tradebook"|"api")}
"""
import csv
import io
from collections import Counter

# NSE/BSE series suffixes a broker may append to a symbol (XYZ-BE → XYZ)
SERIES = {"EQ", "BE", "BZ", "SM", "ST", "SZ", "IT", "IV", "GB", "GS", "RR", "BL", "IL", "E1", "X1", "P1", "T"}


class FormatError(ValueError):
    pass


def clean_symbol(s):
    s = str(s or "").strip().upper()
    if "-" in s and s.rsplit("-", 1)[1] in SERIES:
        s = s.rsplit("-", 1)[0]
    return s


def trade_key(exchange, symbol, trade_id):
    """Exchange trade numbers are unique per exchange + symbol only (NSE reuses a number on another stock)."""
    return f"{str(exchange or '').upper()}:{symbol}:{str(trade_id).split(':')[-1]}"


def fingerprint(f):
    """The same trade seen by two sources. Date, not time: Kite reports fill time, the tradebook the order time."""
    return (f["symbol"], f["side"], round(float(f["qty"]), 4), round(float(f["price"]), 2), str(f["ts"])[:10])


def _num(x):
    try:
        return float(str(x).replace(",", "").strip())
    except (TypeError, ValueError):
        return 0.0


def parse_zerodha_tradebook(text):
    """Zerodha Console → Reports → Tradebook → Equity → CSV. Returns (fills, info)."""
    rows = list(csv.DictReader(io.StringIO((text or "").lstrip("﻿"))))
    if not rows:
        raise FormatError("The file is empty.")
    cols = {k.strip().lower() for k in rows[0] if k}
    need = {"symbol", "trade_type", "quantity", "price", "trade_id"}
    if not need <= cols:
        raise FormatError("This doesn't look like a Zerodha tradebook (missing: " + ", ".join(sorted(need - cols)) + ").")
    out, skipped = [], 0
    for r in rows:
        r = {k.strip().lower(): (v or "").strip() for k, v in r.items() if k}
        if (r.get("segment") or "EQ").upper() != "EQ":
            skipped += 1
            continue
        side = r.get("trade_type", "").upper()
        qty, price = _num(r.get("quantity")), _num(r.get("price"))
        if side not in ("BUY", "SELL") or qty <= 0 or price <= 0:
            skipped += 1
            continue
        ts = (r.get("order_execution_time") or r.get("trade_date") or "").replace("T", " ")[:19]
        sym = clean_symbol(r.get("symbol"))
        exch = (r.get("exchange") or "NSE").upper()
        out.append({"key": trade_key(exch, sym, r["trade_id"]), "trade_id": r["trade_id"], "order_id": r.get("order_id") or "",
                    "exchange": exch, "symbol": sym, "isin": r.get("isin") or None, "side": side, "qty": qty,
                    "price": price, "ts": ts if len(ts) > 10 else ts + " 00:00:00", "source": "tradebook"})
    if not out:
        raise FormatError("No equity trades found in this file.")
    days = sorted(f["ts"][:10] for f in out)
    return out, {"rows": len(rows), "fills": len(out), "skipped": skipped, "from": days[0], "to": days[-1]}


def from_kite_trade(t):
    """One trade from Kite Connect GET /trades."""
    sym = clean_symbol(t.get("tradingsymbol"))
    exch = str(t.get("exchange") or "NSE").upper()
    ts = str(t.get("fill_timestamp") or t.get("exchange_timestamp") or t.get("order_timestamp") or "")[:19]
    return {"key": trade_key(exch, sym, t["trade_id"]), "trade_id": str(t["trade_id"]), "order_id": str(t.get("order_id") or ""),
            "exchange": exch, "symbol": sym, "isin": None, "side": str(t.get("transaction_type") or "").upper(),
            "qty": float(t.get("quantity") or 0), "price": float(t.get("average_price") or 0), "ts": ts, "source": "api",
            "product": str(t.get("product") or "").upper()}


def new_fills(incoming, existing):
    """Which incoming fills are not stored yet: same key, or the same trade from the other source."""
    seen = {f["key"] for f in existing}
    other = {}
    for f in existing:
        other.setdefault(f.get("source"), Counter())[fingerprint(f)] += 1
    out, mine = [], set()
    for f in incoming:
        if f["key"] in seen or f["key"] in mine:
            continue
        cross = [c for src, c in other.items() if src != f.get("source") and c[fingerprint(f)] > 0]
        if cross:
            cross[0][fingerprint(f)] -= 1
            continue
        mine.add(f["key"])
        out.append(f)
    return out


def dedupe(fills):
    """Copies of one trade from both sources already stored: keep the tradebook one. Returns (kept, dropped keys)."""
    tb = Counter(fingerprint(f) for f in fills if f.get("source") == "tradebook")
    dropped = set()
    for f in fills:
        if f.get("source") == "api" and tb[fingerprint(f)] > 0:
            tb[fingerprint(f)] -= 1
            dropped.add(f["key"])
    return [f for f in fills if f["key"] not in dropped], dropped


def canonical_symbols(fills):
    """Renamed stocks (HBLPOWER → HBLENGINE) and BSE names: one symbol per ISIN, the newest used. In place."""
    latest = {}
    for f in fills:
        if f.get("isin") and str(f["ts"]) >= latest.get(f["isin"], ("", ""))[0]:
            latest[f["isin"]] = (str(f["ts"]), f["symbol"])
    for f in fills:
        if f.get("isin") in latest:
            f["symbol"] = latest[f["isin"]][1]
    return fills
