"""Stats periods → (start, end, label), ISO dates inclusive; None = open-ended."""
from datetime import date, timedelta

PERIODS = ["All", "Today", "This week", "Last week", "This month", "Last month", "Last 30 days", "Last 90 days",
           "This quarter", "Last quarter", "Last 6 months", "This year", "Last year", "Last 12 months",
           "This FY (Apr–Mar)", "Last FY", "Since date", "Custom range"]


def _months_back(d, n):
    y, m = d.year, d.month - n
    while m <= 0:
        m += 12
        y -= 1
    last = [31, 29 if y % 4 == 0 and (y % 100 or y % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1]
    return date(y, m, min(d.day, last))


def period_range(per, date_from=None, date_to=None, today=None):
    t = today or date.today()
    q0 = date(t.year, 3 * ((t.month - 1) // 3) + 1, 1)
    fy0 = date(t.year if t.month >= 4 else t.year - 1, 4, 1)
    wk0 = t - timedelta(days=t.weekday())
    m0 = t.replace(day=1)
    p = lambda x: date.fromisoformat(str(x)[:10]) if x not in (None, "") else None
    rng = {
        "Today": (t, t), "This week": (wk0, t), "Last week": (wk0 - timedelta(days=7), wk0 - timedelta(days=1)),
        "This month": (m0, t), "Last month": ((m0 - timedelta(days=1)).replace(day=1), m0 - timedelta(days=1)),
        "Last 30 days": (t - timedelta(days=29), t), "Last 90 days": (t - timedelta(days=89), t),
        "This quarter": (q0, t), "Last quarter": (_months_back(q0, 3), q0 - timedelta(days=1)),
        "Last 6 months": (_months_back(t, 6) + timedelta(days=1), t), "This year": (date(t.year, 1, 1), t),
        "Last year": (date(t.year - 1, 1, 1), date(t.year - 1, 12, 31)),
        "Last 12 months": (_months_back(t, 12) + timedelta(days=1), t),
        "This FY (Apr–Mar)": (fy0, t), "Last FY": (date(fy0.year - 1, 4, 1), fy0 - timedelta(days=1)),
        "Since date": (p(date_from), None), "Custom range": (p(date_from), p(date_to)),
    }.get(per, (None, None))
    s, e = rng
    f = lambda x: x.strftime("%d %b %Y") if x else ""
    label = "All trades" if s is None and e is None else f"{f(s) or 'start'} → {f(e) if e and e != t else 'today'}"
    return (s.isoformat() if s else None), (e.isoformat() if e else None), label
