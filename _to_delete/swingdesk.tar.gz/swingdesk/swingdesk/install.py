import frappe

ROLE = "SwingDesk User"


def after_install():
    """Idempotent: the app role (no desk access — users live in /swing only)."""
    if not frappe.db.exists("Role", ROLE):
        frappe.get_doc({"doctype": "Role", "role_name": ROLE, "desk_access": 0}).insert(ignore_permissions=True)


def on_user_created(doc, method=None):
    if doc.name in ("Administrator", "Guest"):
        return
    if ROLE not in [r.role for r in doc.get("roles", [])]:
        doc.add_roles(ROLE)
