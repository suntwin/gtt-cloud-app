<template>
  <Sheet :open="!!ui.card" :title="ui.card?.symbol" :layer="80" @close="ui.card = null">
    <template #actions>
      <template v-if="ui.card">
        <button class="rounded-md bg-surface-gray-2 px-2.5 py-1 text-xs font-medium text-ink-gray-8" title="Open in TradingView Desktop (web if the helper isn't running)"
                @click="openTV(ui.card.symbol)">TradingView</button>
        <a :href="tvWeb(ui.card.symbol)" target="_blank" rel="noopener" class="px-1 text-xs text-ink-gray-5 underline" title="Open on tradingview.com">web ↗</a>
      </template>
    </template>
    <template v-if="ui.card">
      <div v-if="first.length" class="mb-3 grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
        <template v-for="[k, v] in first" :key="k">
          <div class="text-ink-gray-5">{{ k }}</div><div class="font-medium" :class="String(v).length > 18 && 'col-span-2 -mt-1 mb-1'">{{ v }}</div>
        </template>
      </div>
      <div v-if="scan" class="text-xs text-ink-gray-5 mb-1">{{ scan.Sector }} · {{ scan.Industry }}</div>
      <Note v-if="!scan" kind="warn">Not in today's scan — no live numbers (only what the table shows).</Note>
      <div v-else class="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
        <div v-for="f in fields" :key="f.label" class="rounded-md px-2 py-1.5" :style="f.style || { background: '#f5f5f5' }">
          <div class="text-[10px] uppercase tracking-wide opacity-70">{{ f.label }}</div>
          <div class="text-sm font-semibold tabular-nums">{{ f.value }}</div>
        </div>
      </div>
      <div v-if="rest.length" class="mt-3 grid grid-cols-2 gap-x-3 gap-y-0.5 text-xs">
        <template v-for="[k, v] in rest" :key="k"><div class="text-ink-gray-5">{{ k }}</div><div class="font-medium">{{ v }}</div></template>
      </div>
    </template>
  </Sheet>
</template>
<script setup>
import { computed } from 'vue'
import Sheet from './Sheet.vue'
import Note from './Note.vue'
import { ui, scanRow, tv, openTV, tvWeb } from '@/lib/store'
import { CARD_FIELDS, cardColour } from '@/lib/colors'

const scan = computed(() => {
  if (!ui.card) return null
  const r = scanRow(ui.card.symbol)
  if (!r) return null
  // derived like gtt_process.add_derived (rel tightness today/prev, ADRs from 10w, vol ratio)
  const adr = r.Adr || null
  return {
    ...r,
    _rel_tightness_today: r._rt_ant ?? (adr ? r._nr4 / adr : null),
    _rel_tightness_prev: r._rt_pb ?? (adr ? r._nr4_previous / adr : null),
  }
})
const fields = computed(() => {
  const r = scan.value
  if (!r) return []
  return CARD_FIELDS.filter(([, c]) => r[c] !== null && r[c] !== undefined && r[c] !== '').map(([label, c, d, kind]) => {
    const v = Number(r[c])
    return { label, value: Number.isFinite(v) ? (kind === 'chg' && v > 0 ? '+' : '') + v.toFixed(d) : r[c],
             style: kind && Number.isFinite(v) ? cardColour[kind](v, r) : null }
  })
})
const SKIP = new Set(['__i', 'Symbol', 'Flag', 'Hide', 'Pick', 'Unflag', 'Keep', 'CONT', 'Hidden', '_lead_rank', 'id'])
const FIRST = ['Leader', 'Score', 'Setup', 'MA hold', 'Entry', 'Flags', 'Status', 'Plan', 'Warnings', 'Label', 'Reason', 'Patterns', 'Tier', 'Note', 'Tags']
const pretty = (v) => (typeof v === 'number' ? Math.round(v * 100) / 100 : v === true ? '✓' : v)
const first = computed(() => {
  const row = ui.card?.row
  if (!row) return []
  return FIRST.filter((k) => row[k] !== null && row[k] !== undefined && row[k] !== '').map((k) => [k === 'Leader' ? '👑' : k, pretty(row[k])])
})
const rest = computed(() => {
  const row = ui.card?.row
  if (!row || scan.value) return []
  return Object.entries(row).filter(([k, v]) => !SKIP.has(k) && !FIRST.includes(k) && !k.startsWith('_') && v !== null && v !== '' && v !== undefined)
    .map(([k, v]) => [k, pretty(v)])
})
</script>
