# tv-bridge

Makes the Scanner's **TradingView** button switch the chart in TradingView Desktop instead of opening a browser tab.

It is a tiny Node program that listens on `127.0.0.1:9333` (your PC only) and does one thing: set the chart symbol in
TradingView Desktop over its debug port — the same connection the TradingView MCP uses. It only accepts requests from
myswingdesk.app, *.frappe.cloud and localhost, and only symbol names.

## Use
1. TradingView Desktop must be running with remote debugging (as it is for the TradingView MCP; default port 9222).
2. Double-click `start-hidden.vbs` (runs with no window). To start it at login: Win+R → `shell:startup` → put a shortcut to `start-hidden.vbs` there.
3. First click of the button: Chrome may ask to let the site access devices on your local network → Allow.

If the helper isn't running, the button opens the web chart as before. The small "web ↗" link always opens the web chart.

Different debug port? Set `TV_CDP_PORT` (e.g. `setx TV_CDP_PORT 9223`). Needs Node 22+. Check: open http://127.0.0.1:9333/ping
