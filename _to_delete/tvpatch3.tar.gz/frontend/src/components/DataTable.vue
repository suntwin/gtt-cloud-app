<template>
  <div ref="root" class="dt rounded-lg border border-outline-gray-2 bg-surface-base" :class="[full && 'dt-full', dense && 'dt-dense', ui.tableId === myId && 'dt-active']"
       @pointerdown="claim">
    <div class="flex items-center gap-1 border-b border-outline-gray-1 px-2 py-1 text-[11px] text-ink-gray-5">
      <span class="flex-1 truncate">{{ sorted.length }} rows<template v-if="ui.tableId === myId && fine"> · ↑↓ to browse in TradingView, Enter for details</template><template v-if="hidden.length"> · {{ hidden.length }} column{{ hidden.length > 1 ? 's' : '' }} hidden</template></span>
      <div class="relative">
        <button type="button" class="dt-tool" :aria-expanded="pick" title="Show / hide columns" @click="pick = !pick"><span class="lucide-columns-3 size-3.5" /> Columns</button>
        <div v-if="pick" class="absolute right-0 top-7 z-40 max-h-80 w-56 overflow-auto rounded-lg border border-outline-gray-2 bg-surface-base p-2 shadow-xl">
          <div class="mb-1 flex gap-2 text-[11px]"><button class="underline" @click="setHidden([])">Show all</button><button class="underline" @click="pick = false">Done</button></div>
          <label v-for="c in hideable" :key="c.key" class="flex items-center gap-2 py-0.5 text-xs text-ink-gray-8">
            <input type="checkbox" :checked="!hidden.includes(c.key)" @change="toggleHidden(c.key)" />{{ c.label || c.key }}
          </label>
        </div>
      </div>
      <button type="button" class="dt-tool" :title="dense ? 'Comfortable rows' : 'Compact rows — more on screen'" @click="toggleDense">
        <span :class="dense ? 'lucide-rows-3' : 'lucide-rows-4'" class="size-3.5" /> {{ dense ? 'Comfortable' : 'Compact' }}</button>
      <button type="button" class="dt-tool" :title="full ? 'Exit full screen (Esc)' : 'Full screen'" @click="full = !full">
        <span :class="full ? 'lucide-minimize-2' : 'lucide-maximize-2'" class="size-3.5" /> {{ full ? 'Exit' : 'Full screen' }}</button>
    </div>
    <div
      ref="scroller"
      class="dt-scroll relative overflow-auto overscroll-contain"
      :style="{ height: boxHeight + 'px' }"
      @scroll.passive="onScroll"
    >
      <div :style="{ width: totalWidth + 'px', minWidth: '100%' }">
        <!-- header -->
        <div class="dt-head sticky top-0 z-20 flex border-b border-outline-gray-2 bg-surface-gray-2">
          <div
            v-for="(c, j) in cols"
            :key="c.key"
            class="dt-hcell select-none"
            :class="[c.pinOffset !== undefined && 'dt-pin', c.sortable !== false && 'cursor-pointer', j === lastPin && 'dt-pin-edge']"
            :style="cellBox(c)"
            :title="c.tip || c.label"
            @click="c.sortable !== false && toggleSort(c)"
          >
            <template v-if="c.key === '__sel'">
              <input type="checkbox" class="dt-check" :checked="allSelected" :indeterminate.prop="someSelected" @click.stop="toggleAll" aria-label="Select all" />
            </template>
            <template v-else>
              <span class="dt-hlabel">{{ c.label }}</span>
              <span v-if="sortKey === c.key" class="ml-0.5 text-ink-gray-5">{{ sortDir > 0 ? '▲' : '▼' }}</span>
            </template>
          </div>
        </div>
        <!-- body -->
        <div class="relative" :style="{ height: sorted.length * rhRef + 'px' }">
          <div
            v-for="(r, k) in windowRows"
            :key="keyOf(r)"
            class="dt-row absolute left-0 flex"
            :class="[(start + k) % 2 && 'dt-alt', isSelected(r) && 'dt-sel', curKey === keyOf(r) && 'dt-cur']"
            :style="{ transform: `translateY(${(start + k) * rhRef}px)`, width: totalWidth + 'px', minWidth: '100%', height: rhRef + 'px' }"
          >
            <div
              v-for="(c, j) in cols"
              :key="c.key"
              class="dt-cell"
              :class="[c.pinOffset !== undefined && 'dt-pin', j === lastPin && 'dt-pin-edge', c.align === 'left' ? 'justify-start' : c.num ? 'justify-end' : 'justify-start', c.wrap && 'dt-wrap']"
              :style="[cellBox(c), cellStyle(r, c)]"
              :title="longText(r, c)"
            >
              <input v-if="c.key === '__sel'" type="checkbox" class="dt-check" :checked="isSelected(r)" @change="toggleRow(r)" :aria-label="`Select ${keyOf(r)}`" />
              <template v-else-if="c.edit === 'bool'">
                <input type="checkbox" class="dt-check" :checked="!!val(r, c)" @change="setEdit(r, c, $event.target.checked)" :aria-label="`${c.label} ${keyOf(r)}`" />
              </template>
              <template v-else-if="c.edit === 'number' || c.edit === 'text' || c.edit === 'date'">
                <input
                  :type="c.edit === 'number' ? 'number' : c.edit === 'date' ? 'date' : 'text'"
                  :inputmode="c.edit === 'number' ? 'decimal' : undefined"
                  step="any"
                  class="dt-input"
                  :class="c.edit === 'number' && 'text-right'"
                  :value="val(r, c) ?? ''"
                  @change="setEdit(r, c, c.edit === 'number' ? ($event.target.value === '' ? null : Number($event.target.value)) : $event.target.value)"
                  :aria-label="`${c.label} ${keyOf(r)}`"
                />
              </template>
              <template v-else-if="c.edit && c.edit.multi">
                <input type="text" class="dt-input" :value="(val(r, c) || []).join(', ')" :title="'Options: ' + c.edit.multi.join(', ')"
                       @change="setEdit(r, c, $event.target.value.toUpperCase().split(/[,\s]+/).filter(Boolean))" :aria-label="`${c.label} ${keyOf(r)}`" />
              </template>
              <template v-else-if="c.edit && c.edit.select">
                <select class="dt-input" :value="val(r, c)" @change="setEdit(r, c, $event.target.value)" :aria-label="`${c.label} ${keyOf(r)}`">
                  <option v-for="o in c.edit.select" :key="o" :value="o">{{ o }}</option>
                </select>
              </template>
              <template v-else-if="c.link">
                <button type="button" class="min-w-0 flex-1 truncate text-left font-semibold underline decoration-ink-gray-3 underline-offset-2 hover:decoration-ink-gray-8"
                        :title="fine ? 'Open in TradingView' : 'Details'" @click="symClick(r, c)">{{ display(r, c) }}</button>
                <button v-if="fine" type="button" class="dt-info" title="Details" :aria-label="`Details for ${val(r, c)}`" @click="details(r)">
                  <span class="lucide-panel-right-open size-3.5" /></button>
              </template>
              <span v-else class="truncate">{{ display(r, c) }}</span>
            </div>
          </div>
        </div>
        <div v-if="!sorted.length" class="p-4 text-center text-sm text-ink-gray-5">{{ empty }}</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, watch, onMounted, onBeforeUnmount, onActivated, onDeactivated, nextTick } from 'vue'
import { cssToStyle } from '@/lib/colors'
import { lsGet, lsSet, ui, openTV } from '@/lib/store'

const props = defineProps({
  columns: { type: Array, required: true },   // {key,label,width,pin,fmt,style,abs,edit,link,num,tip,wrap}
  rows: { type: Array, required: true },
  rowKey: { type: [String, Function], default: 'Symbol' },
  server: { type: Object, default: null },      // {palette, styles} from styled_table
  height: { type: Number, default: 520 },       // max height; shrinks to fit few rows
  rowHeight: { type: Number, default: 30 },
  selectable: { type: Boolean, default: false },
  selected: { type: Array, default: () => [] },
  edits: { type: Object, default: null },        // {key: {col: value}}
  sort: { type: Object, default: null },         // initial {key, dir}
  empty: { type: String, default: 'Nothing to show.' },
  id: { type: String, default: null },            // remembers hidden columns per table
})
const emit = defineEmits(['open', 'update:selected', 'update:edits', 'order', 'sort'])

// ── toolbar: hide columns (remembered per table), compact rows (all tables), full screen ──
const tableId = computed(() => props.id || 't:' + props.columns.map((c) => c.key).slice(0, 12).join('|'))
const hidden = ref(lsGet(`cols:${tableId.value}`, []))
const pick = ref(false), full = ref(false)
const dense = computed(() => ui.dense)
function setHidden(h) { hidden.value = h; lsSet(`cols:${tableId.value}`, h) }
function toggleHidden(k) { setHidden(hidden.value.includes(k) ? hidden.value.filter((x) => x !== k) : [...hidden.value, k]) }
function toggleDense() { ui.dense = !ui.dense; lsSet('dense', ui.dense) }
const hideable = computed(() => props.columns.filter((c) => !c.link && c.key !== '__sel'))
// ── ticker click → TradingView Desktop; details icon → card; ↑/↓ browse, Enter = details ──
const myId = Symbol('dt'), root = ref(null), curKey = ref(null)
const fine = window.matchMedia?.('(pointer: fine)').matches ?? true      // phones/tablets: ticker opens the card as before
const linkCol = computed(() => cols.value.find((c) => c.link))
const claim = () => { ui.tableId = myId }
function details(r) { curKey.value = keyOf(r); claim(); emit('open', r) }
function symClick(r, c) {
  curKey.value = keyOf(r); claim()
  if (fine) openTV(String(val(r, c))); else emit('open', r)
}
let tvTimer = 0
function move(d) {
  const list = sorted.value
  if (!list.length) return
  let i = list.findIndex((r) => keyOf(r) === curKey.value)
  i = i < 0 ? (d > 0 ? 0 : list.length - 1) : Math.min(list.length - 1, Math.max(0, i + d))
  const r = list[i]
  curKey.value = keyOf(r)
  const el = scroller.value
  if (el) {                                            // keep the row in view (below the sticky header)
    const top = i * rhRef.value, head = 40
    if (top < el.scrollTop) el.scrollTop = top
    else if (top + rhRef.value > el.scrollTop + el.clientHeight - head) el.scrollTop = top + rhRef.value - el.clientHeight + head
  }
  if (ui.card) emit('open', r)                         // card open → it follows along
  clearTimeout(tvTimer)
  const c = linkCol.value
  if (c) tvTimer = setTimeout(() => openTV(String(val(r, c)), { fallback: false, focus: false }), 180)
}
function onKey(e) {
  if (e.key === 'Escape' && full.value) { full.value = false; return }
  if (ui.tableId !== myId || !root.value?.offsetParent || e.altKey || e.ctrlKey || e.metaKey) return
  const t = e.target, tag = t?.tagName
  if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' || t?.isContentEditable) return
  if (e.key === 'ArrowDown' || e.key === 'j') { e.preventDefault(); move(1) }
  else if (e.key === 'ArrowUp' || e.key === 'k') { e.preventDefault(); move(-1) }
  else if (e.key === 'Enter' && curKey.value !== null) {
    const r = sorted.value.find((x) => keyOf(x) === curKey.value)
    if (r) { e.preventDefault(); emit('open', r) }
  }
}
onMounted(() => { if (!ui.tableId) claim() })
onActivated(() => { if (!ui.tableId) claim() })
onDeactivated(() => { if (ui.tableId === myId) ui.tableId = null })
onBeforeUnmount(() => { if (ui.tableId === myId) ui.tableId = null })

const rh0 = props.rowHeight
const rhRef = computed(() => (dense.value ? Math.max(22, rh0 - 6) : rh0))
const scroller = ref(null)
const scrollTop = ref(0)
const viewH = ref(props.height)
const sortKey = ref(props.sort?.key ?? null)
const sortDir = ref(props.sort?.dir ?? 1)
watch(() => props.sort, (s) => { if (s) { sortKey.value = s.key; sortDir.value = s.dir } })

const keyOf = (r) => (typeof props.rowKey === 'function' ? props.rowKey(r) : r[props.rowKey])

const cols = computed(() => {
  const list = []
  if (props.selectable) list.push({ key: '__sel', label: '', width: 34, pin: true, sortable: false })
  const hide = new Set(hidden.value)
  const k = dense.value ? 0.86 : 1
  for (const c of props.columns) {
    if (hide.has(c.key) && !c.link) continue
    const w = (c.width ?? 80) + (c.link && fine ? 20 : 0)      // room for the details icon
    list.push({ ...c, width: c.num && !c.edit ? Math.max(44, Math.round(w * k)) : w })
  }
  let off = 0
  for (const c of list) {
    if (c.pin) { c.pinOffset = off; off += c.width }
  }
  return list
})
const lastPin = computed(() => {
  let k = -1
  cols.value.forEach((c, j) => { if (c.pinOffset !== undefined) k = j })
  return k
})
const totalWidth = computed(() => cols.value.reduce((a, c) => a + c.width, 0))

function val(r, c) {
  const e = props.edits?.[keyOf(r)]
  if (e && c.key in e) return e[c.key]
  return r[c.key]
}
function display(r, c) {
  const v = val(r, c)
  if (v === null || v === undefined || v === '' || (typeof v === 'number' && Number.isNaN(v))) return c.blank ?? ''
  if (typeof c.fmt === 'function') return c.fmt(v, r)
  if (typeof v === 'number' && typeof c.fmt === 'number') {
    return c.sign ? (v > 0 ? '+' : '') + v.toFixed(c.fmt) : v.toFixed(c.fmt)
  }
  if (typeof v === 'number') return Math.round(v * 100) / 100
  if (typeof v === 'boolean') return v ? '✓' : ''
  return v
}
function cellBox(c) {
  const s = { width: c.width + 'px', minWidth: c.width + 'px' }
  if (c.pinOffset !== undefined) s.left = c.pinOffset + 'px'
  return s
}
function cellStyle(r, c) {
  if (c.style) return c.style(r[c.key], r) || null
  const srv = props.server
  if (srv && srv.styles && srv.styles[c.key] && r.__i !== undefined) {
    const k = srv.styles[c.key][r.__i]
    return k ? cssToStyle(srv.palette[k]) : null
  }
  return null
}

// ── sorting ──
function cmp(a, b, abs) {
  const na = a === null || a === undefined || a === '' || (typeof a === 'number' && Number.isNaN(a))
  const nb = b === null || b === undefined || b === '' || (typeof b === 'number' && Number.isNaN(b))
  if (na && nb) return 0
  if (na) return 1          // blanks last, both directions
  if (nb) return -1
  if (typeof a === 'number' && typeof b === 'number') {
    const x = abs ? Math.abs(a) : a, y = abs ? Math.abs(b) : b
    return x < y ? -1 : x > y ? 1 : 0
  }
  return String(a).localeCompare(String(b), undefined, { numeric: true })
}
const sorted = computed(() => {
  const rows = props.rows
  if (!sortKey.value) return rows
  const c = cols.value.find((x) => x.key === sortKey.value)
  if (!c) return rows
  const dir = sortDir.value
  const idx = rows.map((r, i) => [r, i])
  idx.sort((p, q) => {
    const a = val(p[0], c), b = val(q[0], c)
    const blankA = a === null || a === undefined || a === '', blankB = b === null || b === undefined || b === ''
    if (blankA !== blankB) return blankA ? 1 : -1
    return dir * cmp(a, b, c.abs) || p[1] - q[1]
  })
  return idx.map((x) => x[0])
})
function toggleSort(c) {
  if (sortKey.value !== c.key) { sortKey.value = c.key; sortDir.value = c.num ? -1 : 1 } else if (sortDir.value === (c.num ? -1 : 1)) sortDir.value = -sortDir.value
  else { sortKey.value = null }
  emit('sort', { key: sortKey.value, dir: sortDir.value })
}
watch(sorted, (s) => emit('order', s.map(keyOf)), { immediate: true })

// ── virtual window ──
const winH = ref(window.innerHeight)
const boxHeight = computed(() => (full.value ? winH.value - 34
  : Math.min(props.height, 42 + Math.max(props.rows.length, 1) * rhRef.value + 14)))
const start = computed(() => Math.max(0, Math.floor(scrollTop.value / rhRef.value) - 8))
const windowRows = computed(() => sorted.value.slice(start.value, start.value + Math.ceil(viewH.value / rhRef.value) + 16))
let raf = 0
function onScroll(e) {
  if (raf) return
  raf = requestAnimationFrame(() => { raf = 0; scrollTop.value = e.target.scrollTop })
}
let ro
const onResize = () => { winH.value = window.innerHeight }
onMounted(() => {
  window.addEventListener('keydown', onKey); window.addEventListener('resize', onResize)
  if (window.ResizeObserver && scroller.value) {
    ro = new ResizeObserver(() => { viewH.value = scroller.value?.clientHeight || props.height })
    ro.observe(scroller.value)
  }
})
onBeforeUnmount(() => { ro?.disconnect(); window.removeEventListener('keydown', onKey); window.removeEventListener('resize', onResize) })
watch(() => props.rows, () => nextTick(() => { if (scroller.value && scroller.value.scrollTop > sorted.value.length * rhRef.value) scroller.value.scrollTop = 0 }))
function longText(r, c) {
  const v = display(r, c)
  return typeof v === 'string' && v.length > c.width / 7 ? v : undefined
}

// ── selection / edits ──
const selSet = computed(() => new Set(props.selected))
const isSelected = (r) => selSet.value.has(keyOf(r))
const allSelected = computed(() => props.rows.length > 0 && props.rows.every((r) => selSet.value.has(keyOf(r))))
const someSelected = computed(() => !allSelected.value && props.rows.some((r) => selSet.value.has(keyOf(r))))
function toggleRow(r) {
  const k = keyOf(r), s = new Set(props.selected)
  s.has(k) ? s.delete(k) : s.add(k)
  emit('update:selected', [...s])
}
function toggleAll() {
  if (allSelected.value) {
    const drop = new Set(props.rows.map(keyOf))
    emit('update:selected', props.selected.filter((k) => !drop.has(k)))
  } else emit('update:selected', [...new Set([...props.selected, ...props.rows.map(keyOf)])])
}
function setEdit(r, c, v) {
  const k = keyOf(r)
  const next = { ...(props.edits || {}) }
  next[k] = { ...(next[k] || {}), [c.key]: v }
  emit('update:edits', next)
}
defineExpose({ order: () => sorted.value.map(keyOf) })
</script>

<style scoped>
.dt-scroll { -webkit-overflow-scrolling: touch; font-variant-numeric: tabular-nums; }
.dt-hcell {
  display: flex; align-items: center; height: 40px; padding: 0 5px; font-size: 10.5px; font-weight: 600; line-height: 12px;
  color: var(--ink-gray-6, #525252); overflow: hidden; background: inherit;
}
.dt-hlabel { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; word-break: break-word; }
.dt-tool { display: inline-flex; align-items: center; gap: 4px; padding: 2px 6px; border-radius: 5px; }
.dt-tool:hover { background: #f0f0f0; color: #171717; }
.dt-full { position: fixed; inset: 0; z-index: 70; border-radius: 0; border: 0; }
.dt-dense .dt-cell { font-size: 11px; padding: 0 4px; }
.dt-dense .dt-hcell { padding: 0 4px; }
.dt-cell {
  display: flex; align-items: center; padding: 0 6px; font-size: 12px; white-space: nowrap; overflow: hidden;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05); color: #171717; background-clip: padding-box;
}
.dt-wrap span { white-space: nowrap; }
.dt-row { background: #fff; }
.dt-alt { background: #fafafa; }
.dt-sel { background: #eef6ff; }
.dt-row.dt-cur { background: #fff4c2; }
.dt-active .dt-row.dt-cur { box-shadow: inset 3px 0 0 #171717; }
.dt-info { flex: none; display: inline-flex; margin-left: 4px; padding: 2px; border-radius: 4px; color: #8f8f8f; }
.dt-info:hover { background: #ececec; color: #171717; }
.dt-pin { position: sticky; z-index: 10; background: inherit; }
.dt-row .dt-pin { background-color: inherit; }
.dt-head .dt-pin { z-index: 30; }
.dt-pin-edge { box-shadow: 2px 0 0 rgba(0, 0, 0, 0.06); }
.dt-check { width: 16px; height: 16px; accent-color: #171717; cursor: pointer; }
.dt-input {
  width: 100%; height: 24px; padding: 0 4px; font-size: 12px; border: 1px solid #e5e5e5; border-radius: 4px; background: #fff;
}
.dt-input:focus { outline: 2px solid #171717; outline-offset: -1px; }
@media (pointer: coarse) {
  .dt-check { width: 20px; height: 20px; }
}
</style>
