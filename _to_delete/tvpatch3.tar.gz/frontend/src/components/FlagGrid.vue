<template>
  <div>
    <DataTable :columns="cols" :rows="visibleRows" :server="server" v-model:edits="edits" :height="height"
               @open="(r) => openCard(r.Symbol, r)" @order="(o) => (order = o)" />
    <div class="mt-1 text-xs text-ink-gray-5">{{ note }} Ticker → TradingView, the panel icon → its card · tick ⚑<template v-if="hide"> or 🙈 (the row vanishes at once)</template>, then Save.</div>
    <div class="mt-2 flex flex-wrap items-center gap-2">
      <Button variant="solid" :loading="busy" :disabled="!dirty" :label="`Save flags${sector ? ` for ${sector}` : ''}`" @click="save" />
      <span v-if="dirty" class="text-xs text-ink-amber-7">{{ dirty }} unsaved change{{ dirty > 1 ? 's' : '' }}</span>
    </div>
    <CopyBox class="mt-2" :label="`${label}: in the table's order`" :text="tvList(order)" />
  </div>
</template>
<script setup>
// One flaggable grid (focus_flow._flag_grid): ⚑ / 🙈 ticks held in the browser until Save, copy box follows the sort.
import { computed, ref, watch } from 'vue'
import { Button, toast } from 'frappe-ui'
import DataTable from './DataTable.vue'
import CopyBox from './CopyBox.vue'
import { state, openCard, tvList } from '@/lib/store'
import { post } from '@/lib/api'

const props = defineProps({ rows: Array, cols: Array, server: Object, hide: Boolean, sector: String, label: String, note: String })
const emit = defineEmits(['saved'])
const edits = ref({}), order = ref([]), busy = ref(false)
watch(() => props.rows, () => { edits.value = {} })
const height = computed(() => Math.min(32 * props.rows.length + 60, 520))
const visibleRows = computed(() => props.rows.filter((r) => !edits.value[r.Symbol]?.Hide))
const dirty = computed(() => props.rows.filter((r) => {
  const e = edits.value[r.Symbol]; if (!e) return false
  return ('Flag' in e && !!e.Flag !== !!r.Flag) || e.Hide
}).length)
async function save() {
  const flag = [], unflag = [], hide = [], sectors = {}
  for (const r of props.rows) {
    const e = edits.value[r.Symbol] || {}
    sectors[r.Symbol] = r.Sector
    if (e.Hide) { hide.push(r.Symbol); continue }       // hiding a flagged stock keeps its flag
    if ('Flag' in e && !!e.Flag !== !!r.Flag) (e.Flag ? flag : unflag).push(r.Symbol)
  }
  busy.value = true
  try {
    const r = await post('focus.save_flags', { market: state.market, flag, unflag, hide, sector: props.sector || '', sectors })
    toast.success(r.message || 'Saved'); edits.value = {}; emit('saved')
  } catch (e) { toast.error(e.message) } finally { busy.value = false }
}
</script>
