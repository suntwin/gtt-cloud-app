<template>
  <div class="mx-auto max-w-[2200px] space-y-3">
    <Gate />

    <!-- actions -->
    <div class="flex flex-wrap items-center gap-2">
      <Button variant="solid" size="md" :loading="running" :disabled="!gateOk" icon-left="lucide-play"
              :label="state.scan ? 'Refresh scan' : 'Generate GTT Trading Plan'" @click="runScan" />
      <div class="flex rounded-lg bg-surface-gray-2 p-0.5" role="tablist" aria-label="Scanner mode">
        <button v-for="m in MODES" :key="m" role="tab" :aria-selected="mode === m"
                class="rounded-md px-3 py-1.5 text-sm" :class="mode === m ? 'bg-surface-base font-semibold shadow-sm' : 'text-ink-gray-6'"
                @click="mode = m">{{ m }}</button>
      </div>
      <span class="text-xs text-ink-gray-5">{{ mode === 'Post Breakout' ? 'Breakouts from tight setups with volume confirmation.' : 'Coiled setups on the 10w EMA — watch for volume to arrive.' }}</span>
    </div>
    <Note v-if="!gateOk" kind="muted">Market first — write today's market note above, then generate the scan.</Note>
    <Note v-for="e in scanErrors" :key="e" kind="warn">{{ e }}</Note>

    <template v-if="state.scan && gateOk">
      <div class="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-ink-gray-6">
        <span><b class="text-ink-gray-9">{{ base.length }}</b> stocks loaded · session {{ state.scan.session }}</span>
        <span>Rows per MarketInOut screen: {{ Object.entries(state.scan.counts).map(([k, v]) => `${k} ${v}`).join(' · ') }}</span>
        <span v-if="state.scan.bands?.date">Circuit %: NSE list of {{ state.scan.bands.date }}<template v-if="state.scan.bands.behind"> · newer list due</template></span>
        <button v-if="state.market === 'NSE'" class="underline" :disabled="bandsBusy" @click="updateBands">{{ bandsBusy ? 'Updating…' : 'Update price bands' }}</button>
        <button class="underline" :disabled="flagsBusy" title="Unflag every ticker in Sector Focus" @click="clearFlags">{{ flagsBusy ? 'Removing…' : 'Remove all flags' }}</button>
      </div>
      <Note v-if="state.scan.status?.open" kind="info">
        <b>{{ state.market }} is open</b> ({{ state.scan.status.now }} {{ state.scan.status.tz }}) — intraday numbers: MarketInOut re-runs the screens live,
        so fewer stocks pass early in the session and the volume ratio is only part of the day. The evening scan records the close.
      </Note>
      <Note v-else-if="state.scan.status?.stale" kind="warn">
        The scan data is still from <b>{{ state.scan.status.data_date }}</b> — MarketInOut hasn't updated for {{ state.scan.status.clock }} yet.
        Anything you save now is recorded under {{ state.scan.status.data_date }}. Refresh in a while.
      </Note>
      <Note v-if="capped.length" kind="warn">
        <b>{{ capped.join(', ') }} screen{{ capped.length > 1 ? 's' : '' }} hit the 1,000-row API limit</b> — stocks beyond row 1,000 are missing.
        Split the screen in MarketInOut (e.g. by price) to fix.
      </Note>

      <!-- filters -->
      <Section id="sc-filters" :title="`⚙️ Filter settings · ${mode}`">
        <div v-if="mode === 'Post Breakout'" class="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
          <Num v-model="s.vol.min_chg" label="Min Chg% (up on day)" step="0.5" />
          <Num v-model="s.vol.min_vol" label="Min Vol Ratio (x avg)" step="0.1" />
          <Num v-model="s.vol.min_wktight" label="Min W_TightCloses" step="1" />
          <Num v-model="s.vol.min_adr" label="Min ADR" step="0.5" />
          <Num v-model="s.vol.max_adr" label="Max ADR" step="0.5" />
          <Num v-model="s.vol.max_rwd" label="Max Rel Wk Dist (ADRs)" step="0.5" />
        </div>
        <div v-else class="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
          <Num v-model="s.coil.min_adr" label="Min ADR" step="0.5" />
          <Num v-model="s.coil.min_wktight" label="Min W_TightCloses" step="1" />
          <Num v-model="s.coil.max_reltight" label="Max Rel Tightness" step="0.1" />
          <Num v-model="s.coil.max_rwd" label="Max Rel Wk Dist" step="0.5" />
          <Num v-model="s.coil.min_chg" label="Min Chg% (not broken out)" step="0.5" />
          <Num v-model="s.coil.max_chg" label="Max Chg%" step="0.5" />
        </div>
        <div class="mt-2 flex flex-wrap items-center gap-2">
          <Button :loading="savingPrefs" label="Save filter settings" @click="savePrefs" />
          <span class="text-xs text-ink-gray-5">{{ mode === 'Anticipation' ? 'These also drive Tomorrow\'s list.' : 'Colours: Vol 1–2.5x light green, 2.5–3.5x green, 3.5x+ dark green bold.' }}</span>
        </div>
        <div class="mt-3 border-t border-outline-gray-1 pt-3">
          <label class="flex items-center gap-2 text-sm"><input v-model="customSort" type="checkbox" class="dt-check" /> Custom multi-level sort</label>
          <div v-if="customSort" class="mt-2 grid gap-2 sm:grid-cols-3">
            <div v-for="(lv, i) in levels" :key="i" class="flex gap-1">
              <select v-model="lv.col" class="h-8 flex-1 rounded-md border border-outline-gray-2 px-1 text-sm" :aria-label="`Sort level ${i + 1}`">
                <option value="">(skip)</option><option v-for="(lab, k) in SORTABLE" :key="k" :value="k">{{ lab }}</option>
              </select>
              <select v-model="lv.asc" class="h-8 rounded-md border border-outline-gray-2 px-1 text-sm" aria-label="Direction">
                <option :value="true">Low→High</option><option :value="false">High→Low</option>
              </select>
            </div>
            <span class="text-xs text-ink-gray-5 sm:col-span-3">For tightness/distance columns, sorting is by |value|.</span>
          </div>
        </div>
      </Section>

      <!-- table -->
      <Section id="sc-table" title="📊 Scanner table — filters, results, copy to TradingView" :badge="shown.length" default-open>
        <div class="mb-2 flex flex-wrap items-center gap-x-4 gap-y-2">
          <label v-if="mode === 'Post Breakout'" class="flex items-center gap-2 text-sm">
            <input v-model="findVol" type="checkbox" class="dt-check" />
            Find Volume Breakouts (Up {{ s.vol.min_chg }}%+, Vol {{ s.vol.min_vol }}x+, WkTight ≥{{ s.vol.min_wktight }})
          </label>
          <label v-else class="flex items-center gap-2 text-sm">
            <input v-model="findCoil" type="checkbox" class="dt-check" />
            Find Coiled Setups (WkTight ≥{{ s.coil.min_wktight }}, RelTight ≤{{ s.coil.max_reltight }}, on 10w EMA)
          </label>
          <label class="flex items-center gap-2 text-sm"><input v-model="advOn" type="checkbox" class="dt-check" /> Advanced filters</label>
          <input v-model="q" class="h-8 w-full rounded-md border border-outline-gray-2 px-2 text-sm sm:w-64" placeholder="Find ticker — e.g. VNCE, or several" aria-label="Find ticker" />
          <button class="text-sm underline" @click="colsOpen = !colsOpen">Columns</button>
        </div>

        <div v-if="advOn" class="mb-2 rounded-lg bg-surface-gray-1 p-2">
          <div class="flex flex-wrap gap-1">
            <button v-for="c in advChoices" :key="c" class="rounded-full border px-2 py-0.5 text-xs"
                    :class="adv.some((f) => f.col === c) ? 'border-outline-gray-8 bg-surface-gray-8 text-ink-base' : 'border-outline-gray-2'"
                    @click="toggleAdv(c)">{{ HEADERS[c] || c }}</button>
          </div>
          <div class="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            <div v-for="f in adv" :key="f.col" class="rounded-md bg-surface-base p-2 text-xs">
              <div class="mb-1 font-semibold">{{ HEADERS[f.col] || f.col }}</div>
              <div v-if="f.kind === 'range'" class="flex items-center gap-1">
                <input v-model.number="f.min" type="number" step="any" class="h-7 w-20 rounded border border-outline-gray-2 px-1" aria-label="min" />
                <span>to</span>
                <input v-model.number="f.max" type="number" step="any" class="h-7 w-20 rounded border border-outline-gray-2 px-1" aria-label="max" />
                <label class="ml-1 flex items-center gap-1"><input v-model="f.keepBlank" type="checkbox" /> keep blank</label>
              </div>
              <div v-else-if="f.kind === 'set'" class="flex flex-wrap gap-1">
                <label v-for="o in f.options" :key="o" class="flex items-center gap-1"><input v-model="f.values" type="checkbox" :value="o" />{{ o }}</label>
              </div>
              <input v-else v-model="f.text" class="h-7 w-full rounded border border-outline-gray-2 px-1" placeholder="substring or regex" />
            </div>
          </div>
        </div>

        <div v-if="colsOpen" class="mb-2 rounded-lg bg-surface-gray-1 p-2">
          <div class="flex flex-wrap gap-1">
            <label v-for="c in COLUMNS_TO_SHOW" :key="c" class="flex items-center gap-1 rounded-full border border-outline-gray-2 bg-surface-base px-2 py-0.5 text-xs">
              <input v-model="visible" type="checkbox" :value="c" :disabled="FORCED_VISIBLE.includes(c)" />{{ HEADERS[c] || c }}
            </label>
          </div>
          <Button class="mt-2" size="sm" label="Save as default" @click="saveCols" />
        </div>

        <Note v-if="found" :kind="found.missing.length && !found.rows.length ? 'warn' : 'info'" class="mb-2">
          <b>{{ found.rows.length }} match{{ found.rows.length !== 1 ? 'es' : '' }}</b> for {{ found.terms.join(', ') }}
          <template v-if="found.hidden.length"> · hidden by your filters: {{ found.hidden.slice(0, 10).join(', ') }}</template>
          <template v-if="found.missing.length"> · not in today's scan: {{ found.missing.join(', ') }}</template>. Clear the box to see the full list.
        </Note>
        <div class="mb-1 text-xs text-ink-gray-5"><b>{{ shown.length }} stocks</b> after filtering · ticker → TradingView, the panel icon → its card · tick rows to save them</div>
        <DataTable :columns="tableCols" :rows="shown" v-model:selected="selected" selectable :height="tableH" :sort="tableSort"
                   @open="(r) => openCard(r.Symbol, r)" @order="(o) => (order = o)" @sort="(x) => (tableSort = x)" />

        <div class="mt-3 grid gap-2" :class="groups.length > 2 ? 'sm:grid-cols-3' : 'sm:grid-cols-2'">
          <CopyBox v-for="gr in groups" :key="gr.label" :label="gr.label" :text="tvList(gr.syms)" />
        </div>
      </Section>

      <Section id="sc-save" title="💾 Save from the scanner — tick rows above or type symbols" :badge="saveSyms.length || null">
        <input v-model="typed" class="mb-2 h-8 w-full rounded-md border border-outline-gray-2 px-2 text-sm" placeholder="Other symbols, comma separated — e.g. HAL, BEL" aria-label="Other symbols" />
        <div class="mb-2 text-sm"><b>{{ saveSyms.length }} to save:</b> {{ saveSyms.join(', ') || '— tick rows above' }}</div>
        <div class="flex flex-wrap gap-2">
          <Button v-for="k in saveOrder" :key="k" :variant="k === primarySave || (!primarySave && k !== 'TOMORROW') ? 'solid' : 'subtle'"
                  :disabled="!saveSyms.length" :loading="saving === k" :label="k === 'TOMORROW' ? 'Add to tomorrow\'s list' : `Save as ${k}`" @click="quickSave(k)" />
        </div>
      </Section>

      <Section v-if="mode === 'Post Breakout'" id="sc-bo" title="🗓 Daily process — tag breakouts (late session, once)">
        <Bridge panel="breakout" />
      </Section>
      <Section v-else id="sc-daily" title="🗓 Daily process — tomorrow's list">
        <p class="text-sm">Tomorrow's list has its own page: <RouterLink to="/scanner/tomorrow" class="font-semibold underline">open Tomorrow's list →</RouterLink></p>
      </Section>

      <Section id="sc-export" title="⬇️ Export scanner data">
        <div class="flex flex-wrap gap-2">
          <Button :label="`Filtered (${shown.length} rows) CSV`" @click="exportCSV(false)" />
          <Button :label="`Full dataset (${base.length} rows) CSV`" @click="exportCSV(true)" />
        </div>
      </Section>
    </template>
    <div v-else-if="gateOk && !running" class="rounded-xl border border-dashed border-outline-gray-3 p-8 text-center text-sm text-ink-gray-5">
      Press <b>Generate GTT Trading Plan</b> to load today's scan.
    </div>
  </div>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { Button, toast } from 'frappe-ui'
import Gate from '@/components/Gate.vue'
import Section from '@/components/Section.vue'
import DataTable from '@/components/DataTable.vue'
import CopyBox from '@/components/CopyBox.vue'
import Note from '@/components/Note.vue'
import Num from '@/components/Num.vue'
import Bridge from '@/components/bridge/Bridge.vue'
import { state, asObjects, openCard, tvList, lsGet, lsSet, invalidate, loadBoot } from '@/lib/store'
import { get, post } from '@/lib/api'
import * as C from '@/lib/colors'
import { MODES, COLUMNS_TO_SHOW, DEFAULT_HIDDEN, FORCED_VISIBLE, HEADERS, SORTABLE, HIGH_FIRST, settingsFrom, withMode, modeFilter,
         advancedFilter, advancedDefault, sortBy, defaultSort, findTickers, toCSV, download } from '@/lib/scanner'

const gateOk = computed(() => !!state.boot?.gate?.ok)
const mode = ref(lsGet('sc:mode', 'Anticipation'))
watch(mode, (m) => { lsSet('sc:mode', m); tableSort.value = null })
const s = reactive(settingsFrom(state.boot?.prefs))
watch(() => state.boot?.prefs, (p) => Object.assign(s, settingsFrom(p)))
const findVol = ref(false), findCoil = ref(false), advOn = ref(false), q = ref(''), colsOpen = ref(false)
const customSort = ref(false)
const levels = reactive([{ col: '', asc: true }, { col: '', asc: true }, { col: '', asc: true }])
const selected = ref([]), typed = ref(''), order = ref([]), tableSort = ref(null)
const running = ref(false), scanErrors = ref([]), savingPrefs = ref(false), saving = ref(null), bandsBusy = ref(false)
const tableH = Math.max(360, Math.min(640, window.innerHeight - 220))

// ── data ──
const base = computed(() => asObjects(state.scan?.table))
const capped = computed(() => Object.entries(state.scan?.counts || {}).filter(([, v]) => v >= 1000).map(([k]) => k))
const moded = computed(() => withMode(base.value, mode.value))
const sortedBase = computed(() => {
  const lv = levels.filter((l) => l.col).map((l) => [l.col, l.asc])
  return customSort.value && lv.length ? sortBy(moded.value, lv, true) : defaultSort(moded.value, mode.value)
})
const filtered = computed(() => {
  let d = sortedBase.value
  if (advOn.value) d = advancedFilter(mode.value === 'Anticipation' ? d.filter((r) => (r.Adr ?? 0) >= s.coil.min_adr) : d, adv.value)
  return modeFilter(d, mode.value, s, { findVol: findVol.value, findCoil: findCoil.value })
})
const found = computed(() => findTickers(moded.value, filtered.value, q.value))
const shown = computed(() => (found.value ? found.value.rows : filtered.value))

// ── advanced filters ──
const advChoices = ['_rel_tightness', '_chg_percentclose', 'Adr', '_avgvol_mln', '_vol_ratio', 'Sector_Percentile', 'Avg_RS', '_nr4', '_nr4_previous',
                    'W_TightCloses_10w', '_rel_wk_dist', 'W_Dist10wMA', '_10madist', '_20madist', 'Ti65', 'off_high_21', 'off_high_252', 'Sector', '_circuit']
const adv = ref([])
watch(advOn, (on) => {
  if (on && !adv.value.length) {
    const d = mode.value === 'Post Breakout' ? ['_rel_tightness', '_chg_percentclose', 'Adr', '_avgvol_mln', '_vol_ratio'] : ['_rel_tightness', 'Sector_Percentile', 'Adr', '_avgvol_mln']
    d.forEach(toggleAdv)
  }
})
function toggleAdv(col) {
  const i = adv.value.findIndex((f) => f.col === col)
  if (i >= 0) { adv.value.splice(i, 1); return }
  const vals = moded.value.map((r) => r[col]).filter((v) => v !== null && v !== undefined)
  const uniq = [...new Set(vals.map(String))]
  if (typeof vals[0] === 'number' && uniq.length >= 10) {
    const lo = Math.min(...vals), hi = Math.max(...vals)
    const d = advancedDefault(col, mode.value, s, lo, hi)
    adv.value.push({ col, kind: 'range', min: d.min, max: d.max, keepBlank: true })
  } else if (uniq.length < 40) {
    const opts = [...uniq.sort(), ...(vals.length < moded.value.length ? ['(blank)'] : [])]
    adv.value.push({ col, kind: 'set', options: opts, values: [...opts] })
  } else adv.value.push({ col, kind: 'text', text: '' })
}

// ── columns ──
const saved = state.boot?.columns
const visible = ref([...new Set([...(saved?.length ? saved.filter((c) => COLUMNS_TO_SHOW.includes(c) || c === '_rel_tightness') : COLUMNS_TO_SHOW.filter((c) => !DEFAULT_HIDDEN.includes(c))), ...FORCED_VISIBLE])])
const liq = computed(() => C.liqFactory(shown.value.map((r) => r._avgvol_mln)))
const chg = computed(() => C.chgFactory(shown.value.map((r) => r._chg_percentclose)))
const rs = computed(() => Object.fromEntries(['Avg_RS', 'RS_6M', 'RS_3M', 'RS_1M'].map((k) => [k, C.rsFactory(shown.value.map((r) => r[k]))])))
const wk = computed(() => C.wkDistFactory(s.wk_neg_cutoff))
const tableCols = computed(() => {
  const vis = new Set(visible.value)
  let keys = COLUMNS_TO_SHOW.filter((c) => vis.has(c) && !['Sector_Rank', 'Sector_Total'].includes(c))
  // Last + Chg % right after the ticker, frozen with it; Vol Ratio pinned first (as the page)
  keys = keys.filter((k) => !['Symbol', 'Last', '_chg_percentclose', '_vol_ratio'].includes(k))
  const front = ['_vol_ratio', 'Symbol', 'Last', '_chg_percentclose'].filter((k) => vis.has(k))
  const isPhone = window.innerWidth < 640
  return [...front, ...keys].map((k) => {
    const c = { key: k, label: HEADERS[k] || k, num: !['Symbol', 'Sector', 'Industry', 'Timestamp'].includes(k), width: 72, fmt: 2 }
    if (k === 'Symbol') Object.assign(c, { width: isPhone ? 96 : 140, pin: true, link: true, num: false, align: 'left',
      fmt: (v, r) => (!isPhone && r.Sector_Rank > 0 ? `${v} (${r.Sector_Rank}/${r.Sector_Total})` : v) })
    if (k === 'Last') Object.assign(c, { pin: !isPhone, width: 70 })
    if (k === '_chg_percentclose') Object.assign(c, { pin: !isPhone, width: 62, style: chg.value })
    if (k === '_vol_ratio') Object.assign(c, { pin: !isPhone, width: 62, style: C.volRatio, abs: true })
    if (k === 'dvol') Object.assign(c, { style: C.dvol, fmt: 1 })
    if (k === '_avgvol_mln') Object.assign(c, { style: liq.value, fmt: 1 })
    if (k === 'W_Dist10wMA') Object.assign(c, { style: wk.value, abs: true, width: 80 })
    if (k === '_rel_wk_dist') Object.assign(c, { style: C.relWk, abs: true })
    if (k === '_rel_tightness') Object.assign(c, { style: C.relTight, abs: true })
    if (rs.value[k]) Object.assign(c, { style: rs.value[k], fmt: 0, width: 56 })
    if (k === '_20madist' || k === '_10madist') Object.assign(c, { style: C.maDist, abs: true })
    if (k === 'W_PctOf10wkHigh') Object.assign(c, { style: C.wkPct, width: 88 })
    if (k === 'off_high_21') Object.assign(c, { style: C.off21, width: 80, fmt: 1 })
    if (k === 'off_high_126' || k === 'off_high_252') Object.assign(c, { style: C.offLong, width: 84, fmt: 1 })
    if (k === 'W_TightCloses_10w' || k === 'W_InsideBars') Object.assign(c, { width: 84, fmt: 0 })
    if (k === 'Sector' || k === 'Industry') Object.assign(c, { width: 140 })
    if (k === 'Sector_Percentile') Object.assign(c, { width: 76, fmt: 1 })
    if (k === 'Timestamp') Object.assign(c, { width: 120 })
    return c
  })
})
async function saveCols() {
  try { await post('scan.save_columns', { market: state.market, table_key: `${state.market.toLowerCase()}_main_table_v2`, cols: visible.value }); toast.success('Saved.') }
  catch (e) { toast.error(e.message) }
}

// ── copy groups ──
const bo = ref({ strong: [], moderate: [], strong_min_vol: 3.5 })
async function loadBO() {
  if (mode.value !== 'Post Breakout' || !state.scan) return
  try { bo.value = await get('scan.breakout_groups', { market: state.market, bo_min_chg: s.vol.min_chg, bo_min_vol: s.vol.min_vol }) } catch {}
}
watch([mode, () => state.scan?.at, () => s.vol.min_chg, () => s.vol.min_vol], loadBO, { immediate: true })
const groups = computed(() => {
  const ord = order.value.length ? order.value : shown.value.map((r) => r.Symbol)
  if (mode.value === 'Post Breakout') {
    return [{ label: `Strong BO (≥${bo.value.strong_min_vol}x vol)`, syms: bo.value.strong },
            { label: `Moderate BO (${s.vol.min_vol}–${bo.value.strong_min_vol}x)`, syms: bo.value.moderate },
            { label: 'All in the table', syms: ord }]
  }
  const tight = shown.value.length > 20 ? sortBy(shown.value, [['_rel_tightness', true]]).slice(0, 20).map((r) => r.Symbol) : ord
  return [{ label: 'Top 20 tightest', syms: tight }, { label: 'All in the table', syms: ord }]
})

// ── actions ──
async function runScan() {
  running.value = true; scanErrors.value = []
  try {
    const r = await post('scan.run_scan', { market: state.market })
    scanErrors.value = r.errors || []
    if (r.scan) {
      state.scan = r.scan
      invalidate()            // everything derived from the scan is stale now
      toast.success(`Loaded ${r.scan.table.rows.length} stocks` + (r.auto_recorded ? ` · recorded ${r.auto_recorded} breakouts` : ''))
      loadBoot()
    }
  } catch (e) { toast.error(e.message) } finally { running.value = false }
}
async function savePrefs() {
  savingPrefs.value = true
  try {
    await post('scan.save_prefs', { market: state.market, prefs: { vol_breakout: { ...s.vol }, coiled: { ...s.coil } } })
    toast.success('Saved!'); invalidate('boot'); loadBoot()
  } catch (e) { toast.error(e.message) } finally { savingPrefs.value = false }
}
const saveSyms = computed(() => [...new Set([...selected.value, ...typed.value.toUpperCase().split(/[,\s]+/).filter(Boolean)])])
const saveOrder = computed(() => (mode.value === 'Anticipation' ? ['TOMORROW', ...(state.boot?.setup_types || [])] : [...(state.boot?.setup_types || []), 'TOMORROW']))
const primarySave = computed(() => (mode.value === 'Anticipation' ? 'TOMORROW' : null))
async function quickSave(kind) {
  saving.value = kind
  try {
    const r = await post('scan.quick_save', { market: state.market, symbols: saveSyms.value, kind, scan_mode: mode.value })
    toast.success(r.message); selected.value = []; typed.value = ''; invalidate('tomorrow'); invalidate('watchlist')
  } catch (e) { toast.error(e.message) } finally { saving.value = null }
}
const flagsBusy = ref(false)
async function clearFlags() {
  if (!confirm(`Remove ALL ${state.market} flags? Notes, picks and ranks on flagged tickers go too.`)) return
  flagsBusy.value = true
  try { const r = await post('focus.clear_flags', { market: state.market }); toast.success(r.message); invalidate('focus') }
  catch (e) { toast.error(e.message) } finally { flagsBusy.value = false }
}
async function updateBands() {
  bandsBusy.value = true
  try { const r = await post('scan.update_bands', { market: 'NSE' }); toast.success(r.message); const g = await get('scan.get_scan', { market: 'NSE' }); if (g.scan) state.scan = g.scan }
  catch (e) { toast.error(e.message) } finally { bandsBusy.value = false }
}
function exportCSV(full) {
  const ts = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '')
  const rows = full ? moded.value : shown.value
  const cols = full ? state.scan.table.columns.concat('_rel_tightness') : tableCols.value.map((c) => c.key)
  download(`gtt_${full ? 'full' : 'filtered'}_${ts}.csv`, toCSV(rows, cols))
}
</script>
