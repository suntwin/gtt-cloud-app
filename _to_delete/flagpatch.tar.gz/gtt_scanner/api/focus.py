"""Sector Focus: sectors → tickers → flagged → 5–6 names. Same data steps as focus_flow._render_sector_focus;
the browser does the per-sector filtering / min score / leaders cut (instant), the server does the scoring."""
import difflib
from datetime import date, timedelta

import frappe
import numpy as np
import pandas as pd

from gtt_scanner import engine
from gtt_scanner.api import core
from gtt_scanner.api.core import clean, mcfg_for, parse, sb
from gtt_scanner.api.scan import base_df, load_scan
from gtt_scanner.api.styled import styled_table

import gtt_process as gp
import focus_flow as ff

PREP_TTL = 60 * 30


def _prepared(mkt):
    """focus_flow._prepared, cached in Redis per scan (hist, sector table, universe, tiers, breakouts)."""
    m = mcfg_for(mkt)
    saved = load_scan(mkt)
    if saved is None:
        frappe.throw("Generate the scan first (GTT Scanner tab).")
    key = f"gtt:focusprep:{mkt}"
    memo = frappe.cache().get_value(key)
    if memo and memo.get("at") == saved["at"]:
        return memo
    bd, c = saved["base"], sb()
    cfg = ff.cfg_for(m)
    sd, _, _ = gp.effective_session(bd, m, c)
    try:
        hist = gp.load_breakout_history(c, m)
    except Exception:
        hist = pd.DataFrame()
    try:
        watch = gp.load_active_watchlist(c, m)
    except Exception:
        watch = []
    t, _ = gp.sector_leadership(hist, bd, "Sector")
    u = ff._universe(c, bd, m, hist, watch)
    tiers, bos = {}, {}
    if not u.empty:
        tl = gp.adr_tier(u["Adr"], gp.TIER_DEFAULTS.get(mkt, {"tier1_adr": 7.0, "tier2_adr": 5.0}))
        tiers = {s: t_ for s, t_, d_ in zip(u["Symbol"], tl, u["Data"]) if t_ and d_ == "today"}
        bos = ff._breakouts(u, hist, sd, cfg)
    memo = {"at": saved["at"], "sd": sd, "t": t, "u": u, "tiers": tiers, "bos": bos}
    frappe.cache().set_value(key, memo, expires_in_sec=PREP_TTL)
    return memo


def _view(mkt, focus, lead_win="Avg RS", lead_low=False):
    """The scored frame `v` exactly as _render_sector_focus builds it (stale rows blanked, Flag, Hidden, leaders)."""
    m = mcfg_for(mkt)
    cfg = ff.cfg_for(m)
    memo = _prepared(mkt)
    u = memo["u"]
    c = sb()
    flags = ff.load_flags(c, m)
    if u.empty:
        return memo, cfg, flags, {}, False, pd.DataFrame()
    v = ff.commentary(ff.score(u, cfg, focus, memo["bos"], memo["tiers"]), cfg, mkt)
    v["Flag"] = v["Symbol"].isin(flags)
    stale = v["Data"] != "today"
    if stale.any():
        keep = {"Symbol", "Sector", "Industry", "Flag", "Data"} | {r for r, _ in ff.RULES}
        blank = [c_ for c_ in v.columns if c_ not in keep]
        v[blank] = v[blank].astype(object)
        v.loc[stale, blank] = np.nan
        for c_ in ff.NUMERIC + ["Pivot", "To pivot %", "Stop guide", "Last", "off_high_21"]:
            if c_ in v.columns:
                v[c_] = pd.to_numeric(v[c_], errors="coerce")
        v.loc[stale, [r for r, _ in ff.RULES]] = "·"
        v.loc[stale, "Setup"] = "Dropped out of the scan"
        v.loc[stale, "Entry"] = "No longer passes the screens — check the chart; unflag unless you hold it"
        v.loc[stale, "Flags"] = "Not in today's scan"
        v.loc[stale, "Data"] = "dropped out"
    try:
        hidden = ff.load_hidden(c, m)
        hide_ok = True
    except Exception:
        hidden, hide_ok = {}, False
    v["Hidden"] = v["Symbol"].isin(hidden)
    v = ff.add_leaders(v, lead_win, 0.0 if lead_low else float(cfg["min_adr"]), exclude=hidden)
    return memo, cfg, flags, hidden, hide_ok, v


def _grid_frame(v, mkt, cols=None):
    """focus_flow._flag_grid's columns: SHOW (+ the 4 extra % columns), Circuit % only on NSE, plus Sector/Hidden/
    _lead_rank/Data which the browser needs for filtering."""
    g_ = lambda c: pd.to_numeric(v[c], errors="coerce") if c in v.columns else np.nan
    part = v.assign(**{"NR4 %": g_("_nr4"), "10MA %": g_("_10madist"), "20MA %": g_("_20madist"), "Off 1M %": g_("off_high_21")})
    cols = [c for c in (cols or ff.SHOW) if c in part.columns and (c != "Circuit %" or mkt == "NSE")]
    return part.reset_index(drop=True), cols


@frappe.whitelist()
def view(market="NSE", focus=None, lead_win="Avg RS", lead_low=0):
    core.require_user()
    mkt = market.upper()
    focus = parse(focus, None)
    memo0 = _prepared(mkt)
    t = memo0["t"]
    suggested = []
    if not t.empty:
        healthy = t[(t["Trend"] != "↓") & (pd.to_numeric(t["Holding %"], errors="coerce").fillna(0) >= 60)]
        suggested = list(healthy["Sector"].head(3))
    if focus is None:
        focus = suggested
    memo, cfg, flags, hidden, hide_ok, v = _view(mkt, focus, lead_win, bool(int(lead_low or 0)))
    m = mcfg_for(mkt)
    out = {"session": str(memo["sd"]), "focus": focus, "suggested": suggested,
           "sectors": styled_table(t.head(30), gp.style_leadership(t.head(30))) if not t.empty else None,
           "all_sectors": list(t["Sector"]) if not t.empty else [],
           "cfg": clean(cfg), "rules": [{"id": r, "name": n, "help": ff.RULE_HELP[r].format(**cfg)} for r, n in ff.RULES],
           "tips": ff._tips(cfg), "labels": ff.LABELS, "card_first": ff.CARD_FIRST, "setup_order": ff.SETUP_ORDER,
           "lead": {"wins": list(ff.LEAD_WIN), "pcts": ff.LEAD_PCT, "min_show": ff.LEAD_SHOW, "badge": ff.LEAD_BADGE},
           "hide_ok": hide_ok,
           "hidden": [{"Symbol": s, "Sector": r.get("sector") or "", "Hidden on": str(r.get("hidden_at") or "")[:10],
                       "Reason": r.get("reason") or ""} for s, r in sorted(hidden.items())],
           "grid": None, "flagged": None}
    if v.empty:
        return out
    part, cols = _grid_frame(v, mkt)
    meta = ["Sector", "Hidden", "_lead_rank", "Data", "Flag"]
    gv = part[cols].copy()
    gv["Flag"] = gv["Flag"].astype(bool)
    sty = ff.style(gv, cfg["min_liq"])
    full = part[cols + [c for c in meta if c not in cols]]
    out["grid"] = styled_table(full, sty, labels=ff.LABELS)      # the card reads the rest from the scan table
    out["cols"] = cols
    out["flagged"] = _flagged(mkt, m, cfg, v, flags)
    return out


def _flagged(mkt, m, cfg, v, flags):
    """render_flagged's table (fading old flags, EP-scan fill, Pick/Rank/Note)."""
    if not flags:
        return {"table": None, "n": 0, "picked": 0, "target": cfg["target"], "faded": []}
    c = sb()
    cutoff = date.today() - timedelta(days=cfg["flag_days"])
    fl = pd.DataFrame(flags.values())
    fl["flagged_at"] = pd.to_datetime(fl["flagged_at"]).dt.date
    if "build_range" not in fl.columns:
        fl["build_range"] = False
    old = fl[(fl["flagged_at"] < cutoff) & (~fl["build_range"].fillna(False).astype(bool))]
    faded = []
    if not old.empty:
        ff.remove_flags(c, m, old["symbol"])
        faded = list(old["symbol"])
        fl = fl[~fl["symbol"].isin(old["symbol"])]
    if fl.empty:
        return {"table": None, "n": 0, "picked": 0, "target": cfg["target"], "faded": faded}
    for col in ("rank", "note"):
        if col not in fl.columns:
            fl[col] = None
    d = fl.merge(v.drop(columns=["Flag"]), left_on="symbol", right_on="Symbol", how="left")
    d["Symbol"] = d["symbol"]
    d["Sector"] = d["Sector"].fillna(d["sector"]) if "sector" in d.columns else d["Sector"]
    d = ff._fill_from_ep(engine.NullSt("st"), mkt, d)
    d["Flagged"] = pd.to_datetime(d["flagged_at"]).dt.strftime("%d-%b")
    d["Pick"] = d["build_range"].fillna(False).astype(bool)
    d["Rank"] = pd.to_numeric(d["rank"], errors="coerce")
    d["Note"] = d["note"].fillna("")
    d["Unflag"] = False
    d = d.sort_values(["Pick", "Rank", "Score"], ascending=[False, True, False], na_position="last")
    show = ["Pick", "Rank", "Symbol", "Leader", "Setup", "MA hold", "Entry", "Pivot", "To pivot %", "Stop guide", "Trigger", "Stop",
            "Stop %", "Stop fit", "Flags", "Sector", "Score"] + ff.HIGHLIGHT + [r for r, _ in ff.RULES] + \
           ["BO", "BO vol x", "Off 1M (ADR)", "Off 52W %", "10MA (ADR)", "Avg vol", "Day vol", "Last", "Chg %", "Vol x"] + \
           (["Circuit %"] if mkt == "NSE" else []) + ["Data", "Flagged", "Note", "Unflag"]
    show = [c_ for c_ in show if c_ in d.columns]
    dv = d.reset_index(drop=True)
    gv = dv[show].copy()
    for c_ in ("Pick", "Unflag"):
        gv[c_] = gv[c_].fillna(False).astype(bool)
    n_pick = int(d["Pick"].sum())
    return {"table": styled_table(gv, ff.style(gv, cfg["min_liq"]), labels={**ff.LABELS, "Entry": "Entry plan"},
                                  ),
            "n": len(d), "picked": n_pick, "target": cfg["target"], "faded": faded}


# ── writes ──────────────────────────────────────────────────────────────────
@frappe.whitelist(methods=["POST"])
def save_flags(market="NSE", flag=None, unflag=None, hide=None, sector=None, sectors=None):
    """One grid's Save: flag / unflag / hide lists (the browser works out what changed, like _flag_grid)."""
    core.require_user()
    m = mcfg_for(market)
    c = sb()
    flag, unflag, hide = parse(flag, []) or [], parse(unflag, []) or [], parse(hide, []) or []
    secmap = parse(sectors, {}) or {}
    if hide:
        ff.hide_symbols(c, m, sorted(hide), sectors=secmap)
    if flag:
        ff.add_flags(c, m, sorted(flag), sector=sector or None, source=sector or "other sectors",
                     sectors=None if sector else secmap)
    if unflag:
        ff.remove_flags(c, m, unflag)
    return {"message": " · ".join(x for x in (
        f"Flagged {len(flag)}, unflagged {len(unflag)}" if (flag or unflag) else "",
        f"Hidden: {', '.join(sorted(hide))} (unhide under 🙈 Hidden)" if hide else "") if x)}


@frappe.whitelist(methods=["POST"])
def clear_flags(market="NSE"):
    """Remove every ⚑ flag for this market (fresh start for the week)."""
    core.require_user()
    m, c = mcfg_for(market), sb()
    syms = list(ff.load_flags(c, m))
    ff.remove_flags(c, m, syms)
    return {"message": f"Removed {len(syms)} flag{'' if len(syms) == 1 else 's'}." if syms else "No flags to remove.", "n": len(syms)}


@frappe.whitelist(methods=["POST"])
def unhide(market="NSE", symbols=None):
    core.require_user()
    syms = parse(symbols, []) or []
    if syms:
        ff.unhide_symbols(sb(), mcfg_for(market), syms)
    return {"message": f"Unhid {', '.join(syms)}."}


@frappe.whitelist(methods=["POST"])
def flag_manual(market="NSE", text=""):
    """⚑ Flag tickers by hand — typo check against the symbol list, suggestions for unknown ones."""
    core.require_user()
    mkt = market.upper()
    m = mcfg_for(mkt)
    syms = list(dict.fromkeys(s.strip().upper().split(":")[-1] for s in (text or "").replace("\n", ",").split(",") if s.strip()))
    uni = ff._symbol_universe(mkt)
    bd = base_df(mkt)
    vsyms, vsec = set(), {}
    if bd is not None:
        vsyms = set(bd["Symbol"].astype(str))
        vsec = dict(zip(bd["Symbol"], bd.get("Sector", pd.Series(index=bd.index, dtype=object))))
    known = vsyms | set(uni)
    good = [s for s in syms if not uni or s in known]
    bad = [s for s in syms if s not in good]
    if good:
        ff.add_flags(sb(), m, good, source="manual", sectors={**uni, **vsec})
    tips = []
    for s in bad:
        mm = difflib.get_close_matches(s, sorted(known), n=2, cutoff=0.7)
        tips.append(f"{s}" + (f" → did you mean {' / '.join(mm)}?" if mm else " (unknown symbol)"))
    return {"message": f"Flagged {len(good)}." + (f" {len(bad)} not recognised." if bad else ""),
            "warning": ("Not flagged — " + " · ".join(tips)) if tips else None}


@frappe.whitelist(methods=["POST"])
def save_shortlist(market="NSE", changes=None):
    """Flagged table's Save shortlist: [{Symbol, Pick, Rank, Note, Unflag}] for rows that changed."""
    core.require_user()
    m = mcfg_for(market)
    c = sb()
    n = 0
    for r in parse(changes, []) or []:
        s = r["Symbol"]
        if r.get("Unflag"):
            ff.remove_flags(c, m, [s]); n += 1; continue
        ch = {}
        if "Pick" in r:
            ch["build_range"] = bool(r["Pick"])
        if "Rank" in r:
            rk = ff._num(r.get("Rank"))
            ch["rank"] = int(rk) if np.isfinite(rk) else None
        if "Note" in r:
            ch["note"] = str(r.get("Note") or "")
        if ch:
            ff.update_flag(c, m, s, **ch); n += 1
    return {"message": f"Saved {n} change{'s' if n != 1 else ''}."}


def price_band(mkt, sym, card=None):
    """NSE price band (circuit) for any listed stock — from the stored nse_price_bands table, not the scan. With a price
    from the scan, also the circuit limits (band applies to the previous close)."""
    if mkt != "NSE" or not sym:
        return None
    try:
        import nse_bands as nb
        rows = sb().table("nse_price_bands").select("symbol,series,band,band_text,file_date").eq("symbol", sym).execute().data or []
    except Exception as e:
        return {"error": f"Price bands unavailable ({e})"}
    if not rows:
        return {"missing": True, "text": "Not in NSE's price-band list — check the symbol (or update price bands)"}
    order = {s_: i for i, s_ in enumerate(nb.SERIES_ORDER)}
    r = sorted(rows, key=lambda x: order.get(x.get("series"), 99))[0]
    no_band = "no band" in str(r.get("band_text") or "").lower()
    pct = None if no_band else (float(r["band"]) if r.get("band") not in (None, "") else None)
    out = {"series": r.get("series"), "pct": pct, "no_band": no_band, "date": r.get("file_date"),
           "text": "No band (F&O — moves freely)" if no_band else (f"{pct:g}% band" if pct is not None else str(r.get("band_text") or "?")),
           "other_series": sorted({x["series"] for x in rows} - {r.get("series")})}
    try:                                                        # circuit prices, when the scan has today's numbers
        cols, vals = (card or {}).get("columns") or [], ((card or {}).get("rows") or [[]])[0]
        d = dict(zip(cols, vals))
        last, chg = float(d.get("Last")), float(d.get("_chg_percentclose") or d.get("Chg %") or 0)
        prev = last / (1 + chg / 100)
        if pct:
            out.update(prev_close=round(prev, 2), upper=round(prev * (1 + pct / 100), 2), lower=round(prev * (1 - pct / 100), 2),
                       room_up_pct=round((prev * (1 + pct / 100) / last - 1) * 100, 2))
    except Exception:
        pass
    return out


@frappe.whitelist()
def check_ticker(market="NSE", symbol="", focus=None, lead_win="Avg RS", lead_low=0):
    """🔍 Check ticker: its row (rules, score, setup, leader) + every scan attribute for the card."""
    core.require_user()
    mkt = market.upper()
    q = (symbol or "").strip().upper().split(":")[-1]
    focus = parse(focus, []) or []
    memo, cfg, flags, hidden, hide_ok, v = _view(mkt, focus, lead_win, bool(int(lead_low or 0)))
    row = v[v["Symbol"] == q] if not v.empty else pd.DataFrame()
    bd = base_df(mkt)
    card = None
    if bd is not None:
        b = gp.add_derived(bd[bd["Symbol"].astype(str).str.upper() == q]) if q in set(bd["Symbol"].astype(str).str.upper()) else None
        card = core.table(b) if b is not None else None
    band = price_band(mkt, q, card)
    if row.empty:
        return {"found": False, "message": f"{q} isn't in today's scan, recent breakouts or your watchlist.", "card": card,
                "band": band, "symbol": q}
    cols = [c_ for c_ in ["Symbol", "Sector", "Leader", "Score", "Setup", "MA hold"] + ff.HIGHLIGHT +
            [r for r, _ in ff.RULES] + ["Flags", "Entry", "Data", "_lead_rank", "Flag"] if c_ in row.columns]
    r0 = row.iloc[0]
    return {"found": True, "row": clean(r0[cols].to_dict()), "card": card, "band": band, "symbol": q,
            "sector_n": int(((v["Sector"] == r0.get("Sector")) & v["_lead_rank"].notna()).sum())}
