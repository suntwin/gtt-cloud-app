<template>
  <div class="mx-auto max-w-[2200px] space-y-3">
    <div class="flex flex-wrap items-center gap-2">
      <h1 class="text-xl font-semibold">Sector Focus</h1>
      <span class="text-sm text-ink-gray-5">sector → tickers → flagged → 5–6 names</span>
      <div class="flex-1" />
      <Button size="sm" icon-left="lucide-refresh-cw" :loading="loading" label="Reload" @click="load(true)" />
    </div>
    <Note v-if="err" kind="error">{{ err }}</Note>
    <div v-if="loading && !d" class="grid place-items-center p-10"><LoadingIndicator class="size-6" /></div>

    <template v-if="d">
      <!-- 1 -->
      <Section id="sf-1" title="1 · Pick your focus sectors" :badge="focus.length">
        <template v-if="d.sectors">
          <p class="mb-2 text-xs text-ink-gray-5">Leading = most breakouts recently, trend ↑ or →, Holding % ≥ 60. Last 5/10/20 count breakouts, Stocks counts different names.</p>
          <DataTable :columns="sectorCols" :rows="asObjects(d.sectors)" :server="d.sectors" row-key="Sector" :height="380" />
          <div class="mt-3 text-xs font-medium text-ink-gray-6">Focus sectors (2–3) · suggested: {{ d.suggested.join(', ') || 'none clearly leading — be very selective' }}</div>
          <div class="mt-1 flex flex-wrap gap-1.5">
            <button v-for="sct in d.all_sectors" :key="sct" class="rounded-full border px-2.5 py-1 text-xs"
                    :class="focus.includes(sct) ? 'border-outline-gray-8 bg-surface-gray-8 text-ink-base' : 'border-outline-gray-2 bg-surface-base'"
                    :aria-pressed="focus.includes(sct)" @click="toggleFocus(sct)">{{ sct }}</button>
          </div>
          <Note v-if="focus.length > 3" kind="warn" class="mt-2">More than 3 sectors dilutes the focus.</Note>
        </template>
        <Note v-else kind="muted">No breakouts recorded yet — sectors appear after a few evening scans.</Note>
      </Section>

      <!-- 2 -->
      <Section id="sf-2" title="2 · Go through each sector and flag the best few" default-open>
        <Note v-if="!focus.length" kind="muted">Pick at least one focus sector above.</Note>
        <template v-else>
          <div class="mb-2 flex flex-wrap items-center gap-1.5">
            <button v-for="sct in focus" :key="sct" class="rounded-lg border px-3 py-1.5 text-sm"
                    :class="sector === sct ? 'border-outline-gray-8 bg-surface-gray-8 text-ink-base' : 'border-outline-gray-2 bg-surface-base'"
                    @click="sector = sct">{{ sct }} <span class="opacity-70">{{ live.filter((r) => r.Sector === sct).length }} · ⚑{{ all.filter((r) => r.Sector === sct && r.Flag).length }}</span></button>
          </div>
          <div class="mb-2 flex flex-wrap items-center gap-3 text-sm">
            <label class="flex items-center gap-2">Min score
              <input v-model.number="minScore" type="range" min="0" max="8" step="0.5" class="w-32" aria-label="Min score" /><b>{{ minScore }}</b></label>
            <span class="text-xs text-ink-gray-5">
              <span v-for="r in d.rules" :key="r.id" :title="r.help" class="mr-1.5"><b>{{ r.id }}</b> {{ r.name }}</span>
              · ✓ pass · ½ half · ✗ fail · · no data
            </span>
          </div>

          <!-- leaders -->
          <Section :id="`sf-lead`" :title="`👑 Sector leaders — strongest by RS, whatever their score`" class="mb-3">
            <div class="mb-2 flex flex-wrap items-center gap-3 text-sm">
              <div class="flex rounded-lg bg-surface-gray-2 p-0.5">
                <button v-for="w in d.lead.wins" :key="w" class="rounded-md px-2.5 py-1 text-xs" :class="leadWin === w ? 'bg-surface-base font-semibold shadow-sm' : ''" @click="leadWin = w">{{ w }}</button>
              </div>
              <div class="flex rounded-lg bg-surface-gray-2 p-0.5">
                <button v-for="(v, p) in d.lead.pcts" :key="p" class="rounded-md px-2 py-1 text-xs" :class="leadPct === p ? 'bg-surface-base font-semibold shadow-sm' : ''" @click="leadPct = p">{{ p }}</button>
              </div>
              <label class="flex items-center gap-1.5 text-xs"><input v-model="leadLow" type="checkbox" class="dt-check" /> Include low-ADR (&lt; {{ d.cfg.min_adr }}%)</label>
            </div>
            <p class="mb-2 text-xs text-ink-gray-5">Showing <b>{{ leaders.length }} of {{ leadAll.length }}</b> in {{ sector }} · ranked by {{ leadWin }}, ties → most explosive (ADR × Ti65).
              Strength ≠ readiness: a leader with a low score is one to <b>watch for its next tight setup</b>.</p>
            <FlagGrid :rows="leaders" :cols="gridCols(true)" :server="d.grid" hide :sector="sector" :label="`Leaders in ${sector}`" @saved="load(true)" />
          </Section>

          <div class="mb-1 text-sm font-semibold">All of {{ sector }}</div>
          <p v-if="gone.length" class="mb-1 text-xs text-ink-gray-5">Not shown — dropped out of today's scan: {{ gone.join(', ') }}</p>
          <Note v-if="!part.length" kind="muted">Nothing in this sector at that score.</Note>
          <FlagGrid v-else :rows="part" :cols="gridCols(true)" :server="d.grid" hide :sector="sector" :label="sector"
                    :note="`${part.length} of ${live.filter((r) => r.Sector === sector).length} shown (score ≥ ${minScore}), tightest first.`" @saved="load(true)" />

          <Section v-if="d.hidden.length" id="sf-hidden" :title="`🙈 Hidden (${d.hidden.length}) — not shown in step 2, left out of 👑 ranks`" class="mt-3">
            <div class="space-y-1">
              <label v-for="h in d.hidden" :key="h.Symbol" class="flex items-center gap-2 text-sm">
                <input v-model="unhide" type="checkbox" :value="h.Symbol" class="dt-check" />
                <b>{{ h.Symbol }}</b><span class="text-ink-gray-5">{{ h.Sector }} · {{ h['Hidden on'] }}</span>
              </label>
            </div>
            <Button class="mt-2" :disabled="!unhide.length" label="Unhide ticked" @click="doUnhide" />
          </Section>
        </template>
      </Section>

      <!-- 3 -->
      <Section id="sf-3" title="3 · Last stop — best setups outside your focus sectors">
        <p class="mb-2 text-xs text-ink-gray-5">Only when the focus sectors give you nothing. R3 fails here by definition, so 7 is the top score.</p>
        <div class="mb-2 flex flex-wrap items-center gap-3 text-sm">
          <label class="flex items-center gap-2">Min score <input v-model.number="oMin" type="range" min="0" max="8" step="0.5" class="w-28" /><b>{{ oMin }}</b></label>
          <label class="flex items-center gap-2">Show top <input v-model.number="oTop" type="number" min="5" max="100" step="5" class="h-8 w-16 rounded-md border border-outline-gray-2 px-1" /></label>
        </div>
        <div class="mb-2 flex flex-wrap gap-1">
          <label v-for="st in d.setup_order" :key="st" class="flex items-center gap-1 rounded-full border border-outline-gray-2 px-2 py-0.5 text-xs">
            <input v-model="oSetups" type="checkbox" :value="st" />{{ st }}</label>
        </div>
        <div v-if="others.length" class="mb-1 text-xs text-ink-gray-5">By sector: {{ othersBy }}</div>
        <Note v-if="!others.length" kind="muted">Nothing outside your focus sectors at that score / setup.</Note>
        <FlagGrid v-else :rows="others" :cols="gridCols(false, true)" :server="d.grid" label="Other sectors" @saved="load(true)" />
      </Section>

      <!-- 4 -->
      <Section id="sf-4" title="4 · Flagged — pick your 5–6" :badge="d.flagged?.n || 0" default-open>
        <form class="mb-3 flex gap-2" @submit.prevent="flagManual">
          <input v-model="manual" class="h-8 flex-1 rounded-md border border-outline-gray-2 px-2 text-sm uppercase" placeholder="⚑ Flag by hand — e.g. SUNTV, NSE:TIPSMUSIC" aria-label="Flag tickers by hand" />
          <Button type="submit" label="Flag them" />
        </form>
        <Note v-if="manualWarn" kind="warn" class="mb-2">{{ manualWarn }}</Note>
        <Note v-if="d.flagged?.faded?.length" kind="muted" class="mb-2">Unflagged {{ d.flagged.faded.length }} older than {{ d.cfg.flag_days }} days that weren't picked: {{ d.flagged.faded.join(', ') }}.</Note>
        <template v-if="d.flagged?.table">
          <p class="mb-1 text-xs text-ink-gray-5"><b>{{ d.flagged.n }} flagged · {{ d.flagged.picked }} picked</b> (aim for {{ d.flagged.target }}).
            Tick <b>Pick</b> = draw the range and set the alert. Rank 1 = best.</p>
          <Note v-if="d.flagged.picked > d.flagged.target" kind="warn" class="mb-2">{{ d.flagged.picked }} picked — cut to {{ d.flagged.target }} or fewer.</Note>
          <DataTable :columns="flagCols" :rows="flagRows" :server="d.flagged.table" v-model:edits="fEdits" :height="460"
                     @open="(r) => openCard(r.Symbol, r)" @order="(o) => (fOrder = o)" />
          <div class="mt-2 flex flex-wrap gap-2">
            <Button variant="solid" :loading="fSaving" :disabled="!Object.keys(fEdits).length" label="Save shortlist" @click="saveShortlist" />
            <Button label="Export CSV" @click="exportFlagged" />
            <Button theme="red" :loading="clearing" label="Unflag all" @click="clearFlags" />
          </div>
          <div class="mt-2 grid gap-2 sm:grid-cols-2">
            <CopyBox :label="`Picked — draw ranges and set alerts`" :text="tvList(picks)" />
            <CopyBox :label="`All flagged, in the table's order`" :text="tvList(fOrder)" />
          </div>
        </template>
        <Note v-else kind="muted">Nothing flagged yet.</Note>
      </Section>
      <!-- 5 -->
      <Section id="sf-5" title="5 · Review — learning loop (today's breakouts vs what you flagged)">
        <Bridge panel="review" :opts="{ focus, lead_win: leadWin, lead_low: leadLow }" />
      </Section>
    </template>
  </div>
</template>

<script setup>
import { computed, ref, watch, onActivated } from 'vue'
import { Button, LoadingIndicator, toast } from 'frappe-ui'
import DataTable from '@/components/DataTable.vue'
import FlagGrid from '@/components/FlagGrid.vue'
import CopyBox from '@/components/CopyBox.vue'
import Note from '@/components/Note.vue'
import Section from '@/components/Section.vue'
import Bridge from '@/components/bridge/Bridge.vue'
import { state, swr, asObjects, openCard, tvList, lsGet, lsSet, invalidate } from '@/lib/store'
import { get, post } from '@/lib/api'
import { toCSV, download } from '@/lib/scanner'

const d = ref(null), err = ref(''), loading = ref(false)
const focus = ref(lsGet(`focus:${state.market}`, null))
const sector = ref(lsGet('sf:sector', null))
const minScore = ref(lsGet('sf:min', 4)), oMin = ref(6), oTop = ref(25), oSetups = ref([])
const leadWin = ref(lsGet('sf:lwin', 'Avg RS')), leadPct = ref(lsGet('sf:lpct', '10%')), leadLow = ref(lsGet('sf:llow', false))
const unhide = ref([]), manual = ref(''), manualWarn = ref('')
const fEdits = ref({}), fOrder = ref([]), fSaving = ref(false)

async function load(force = false) {
  if (!state.scan) { err.value = 'Generate the scan first (Scanner tab).'; return }
  loading.value = true; err.value = ''
  if (force) invalidate('focus')
  const args = { market: state.market, focus: focus.value ?? undefined, lead_win: leadWin.value, lead_low: leadLow.value ? 1 : 0 }
  try {
    await swr(`focus:${JSON.stringify([focus.value, leadWin.value, leadLow.value])}`, () => get('focus.view', args), (x) => {
      d.value = x
      if (focus.value === null) focus.value = x.focus
      if (!sector.value || !focus.value.includes(sector.value)) sector.value = focus.value[0] || null
      if (!oSetups.value.length) oSetups.value = x.setup_order.slice(0, 4)
      fEdits.value = {}
    }, { persist: false })
  } catch (e) { err.value = e.message } finally { loading.value = false }
}
onActivated(() => load())
watch(() => state.scan?.at, () => load())
watch(focus, (f) => { lsSet(`focus:${state.market}`, f); load() }, { deep: true })
watch([leadWin, leadLow], () => { lsSet('sf:lwin', leadWin.value); lsSet('sf:llow', leadLow.value); load() })
watch(leadPct, (p) => lsSet('sf:lpct', p))
watch(sector, (s) => lsSet('sf:sector', s))
watch(minScore, (m) => lsSet('sf:min', m))
function toggleFocus(s) {
  const f = [...(focus.value || [])]
  const i = f.indexOf(s); i >= 0 ? f.splice(i, 1) : f.push(s)
  focus.value = f
}

const all = computed(() => asObjects(d.value?.grid))
const live = computed(() => all.value.filter((r) => r.Data === 'today' && !r.Hidden))
const byTight = (rows) => [...rows].sort((a, b) => (a['Rel tight'] ?? 1e9) - (b['Rel tight'] ?? 1e9))
const part = computed(() => byTight(live.value.filter((r) => r.Sector === sector.value && ((r.Score ?? 0) >= minScore.value || r.Flag))))
const gone = computed(() => all.value.filter((r) => r.Data !== 'today' && r.Sector === sector.value).map((r) => r.Symbol))
const leadAll = computed(() => live.value.filter((r) => r.Sector === sector.value && r._lead_rank !== null && r._lead_rank !== undefined))
const leaders = computed(() => {
  const n = leadAll.value.length
  const top = Math.min(n, Math.max(d.value.lead.min_show, Math.ceil((d.value.lead.pcts[leadPct.value] ?? 0.1) * n)))
  return byTight([...leadAll.value].sort((a, b) => a._lead_rank - b._lead_rank).slice(0, top))
})
const others = computed(() => {
  const so = Object.fromEntries((d.value?.setup_order || []).map((x, i) => [x, i]))
  const o = live.value.filter((r) => !focus.value.includes(r.Sector))
  const op = o.filter((r) => ((r.Score ?? 0) >= oMin.value && (!oSetups.value.length || oSetups.value.includes(r.Setup))) || r.Flag)
  op.sort((a, b) => (b.Flag - a.Flag) || ((b.Score ?? -1) - (a.Score ?? -1)) || ((so[a.Setup] ?? 99) - (so[b.Setup] ?? 99)) || ((a['Rel tight'] ?? 1e9) - (b['Rel tight'] ?? 1e9)))
  return op.slice(0, oTop.value + op.filter((r) => r.Flag).length)
})
const othersBy = computed(() => {
  const m = {}
  for (const r of others.value) m[r.Sector] = (m[r.Sector] || 0) + 1
  return Object.entries(m).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${k} ${n}`).join(' · ')
})

const NUM1 = new Set(['Score', 'BO vol x', 'ADR', 'Off 1M (ADR)', 'Off 52W %', '10MA (ADR)', 'ADRs from 10w', 'Vol x', 'Explosive', 'To pivot %', '10MA %', '20MA %', 'Off 1M %', 'Chg %'])
const NUM0 = new Set(['Avg vol', 'Day vol', 'Circuit %', 'Avg RS', 'RS 1M', 'RS 3M', 'RS 6M', 'Rank'])
const WIDE = { Last: 74, Trigger: 70, Stop: 66, Pivot: 70, 'Stop guide': 70, Setup: 150, Sector: 130, Flags: 170, Source: 96, 'MA hold': 104, Entry: 260, Leader: 56, Data: 76, BO: 64, 'Stop fit': 70, Note: 140, Flagged: 60 }
function colDef(k, labels) {
  const isPhone = window.innerWidth < 640
  const c = { key: k, label: labels[k] || k, width: WIDE[k] || (/^R\d$/.test(k) ? 34 : 60), num: true, fmt: NUM1.has(k) ? 1 : NUM0.has(k) ? 0 : 2 }
  if (['Setup', 'Sector', 'Flags', 'Source', 'MA hold', 'Entry', 'Leader', 'Data', 'BO', 'Stop fit', 'Note', 'Flagged'].includes(k) || /^R\d$/.test(k)) c.num = false
  if (k === 'Chg %') c.sign = true
  if (k === 'Symbol') Object.assign(c, { pin: true, link: true, width: isPhone ? 88 : 100, num: false })
  if (k === 'Last' || k === 'Chg %') c.pin = !isPhone
  return c
}
function gridCols(hide = false, showSector = false) {
  let keys = [...(d.value?.cols || [])]
  // Last + Chg % right after the ticker (frozen with it), like card_grid
  keys = keys.filter((k) => k !== 'Last' && k !== 'Chg %')
  const si = keys.indexOf('Symbol') + 1
  keys.splice(si, 0, ...['Last', 'Chg %'].filter((k) => d.value.cols.includes(k)))
  if (hide) keys.splice(keys.indexOf('Flag') + 1, 0, 'Hide')
  if (showSector && keys.includes('Setup')) keys.splice(keys.indexOf('Setup') + 1, 0, 'Sector')
  return keys.map((k) => {
    const c = colDef(k, d.value.labels)
    if (k === 'Flag' || k === 'Hide') Object.assign(c, { edit: 'bool', pin: true, width: 40, num: false, label: k === 'Flag' ? '⚑' : '🙈', tip: d.value.tips[k] })
    else c.tip = d.value.tips[k]
    return c
  })
}
const sectorCols = computed(() => (d.value?.sectors?.columns || []).filter((c) => c !== '__i').map((k) => ({
  key: k, label: k, width: k === 'Sector' ? 170 : 74, num: k !== 'Sector' && k !== 'Trend', pin: k === 'Sector', fmt: k === 'Per 100 in scan' ? 1 : 0,
})))

// ── flagged ──
const flagRows = computed(() => asObjects(d.value?.flagged?.table))
const flagCols = computed(() => {
  const keys = (d.value?.flagged?.table?.columns || []).filter((c) => c !== '__i')
  return keys.map((k) => {
    const c = colDef(k, { ...d.value.labels, Entry: 'Entry plan' })
    if (k === 'Pick' || k === 'Unflag') Object.assign(c, { edit: 'bool', width: k === 'Pick' ? 44 : 54, num: false, pin: k === 'Pick' })
    if (k === 'Rank') Object.assign(c, { edit: 'number', width: 56, pin: true })
    if (k === 'Note') Object.assign(c, { edit: 'text', width: 160 })
    return c
  })
})
const picks = computed(() => flagRows.value.filter((r) => (fEdits.value[r.Symbol]?.Pick ?? r.Pick)).sort((a, b) => ((fEdits.value[a.Symbol]?.Rank ?? a.Rank ?? 99) - (fEdits.value[b.Symbol]?.Rank ?? b.Rank ?? 99))).map((r) => r.Symbol))
async function saveShortlist() {
  fSaving.value = true
  try {
    const changes = Object.entries(fEdits.value).map(([Symbol, e]) => ({ Symbol, ...e }))
    const r = await post('focus.save_shortlist', { market: state.market, changes })
    toast.success(r.message); await load(true)
  } catch (e) { toast.error(e.message) } finally { fSaving.value = false }
}
async function flagManual() {
  if (!manual.value.trim()) return
  try {
    const r = await post('focus.flag_manual', { market: state.market, text: manual.value })
    toast.success(r.message); manualWarn.value = r.warning || ''; manual.value = ''; load(true)
  } catch (e) { toast.error(e.message) }
}
async function doUnhide() {
  try { const r = await post('focus.unhide', { market: state.market, symbols: unhide.value }); toast.success(r.message); unhide.value = []; load(true) }
  catch (e) { toast.error(e.message) }
}
const clearing = ref(false)
async function clearFlags() {
  if (!confirm(`Unflag all ${d.value?.flagged?.n || ''} ${state.market} tickers? Picks, ranks and notes on them go too.`)) return
  clearing.value = true
  try { const r = await post('focus.clear_flags', { market: state.market }); toast.success(r.message); fEdits.value = {}; load(true) }
  catch (e) { toast.error(e.message) } finally { clearing.value = false }
}
function exportFlagged() {
  const cols = flagCols.value.map((c) => c.key).filter((k) => k !== 'Unflag')
  const ord = new Map(fOrder.value.map((s, i) => [s, i]))
  const rows = [...flagRows.value].sort((a, b) => (ord.get(a.Symbol) ?? 0) - (ord.get(b.Symbol) ?? 0))
  download(`flagged_${state.market}_${new Date().toISOString().slice(0, 10)}.csv`, toCSV(rows, cols))
}
</script>
